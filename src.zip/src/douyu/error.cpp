#include <QString>
#include <QList>
#define ICNN_MAX_DATA_LEN 100

class MDataType
{
	public:
		int datatype;
		QString name;
		int msgType;
		int ucType;
		int interruptTime;
		int priority;
};

typedef QList<MDataType> MDataTypes;

MDataTypes st_datas;

typedef struct _ST_Time
{
	unsigned short usyear;
	unsigned short usMonth;
}ST_Time;

typedef struct _ZM_MsgHead
{
	unsigned int uiMissioncode;
	unsigned short uiobjcode;
	int uiMsgType;
}ZM_MsgHead;

typedef struct _ST_TMSOURCECODE
{
	ZM_MsgHead stMsgHead;
	unsigned int uiStationCode;
	unsigned char ucDCType;
	unsigned char ucZT;
	ST_Time stStationTime;
	ST_Time stCraftTime;
	unsigned int uiPId;
	unsigned int uiTMMode;
	unsigned int uiVCId;
	unsigned int uiVCCount;
	unsigned int uiFrameCount;
	unsigned int uiDataSize;
	unsigned char ucPri;
	char szData[ICNN_MAX_DATA_LEN];
	_ST_TMSOURCECODE()
	{
		memset(&stMsgHead, 0, sizeof(stMsgHead));
		uiStationCode = 0;
		ucDCType = 0;
		ucZT = 0;
		memset(&stStationTime, 0, sizeof(stStationTime));
		memset(&stCraftTime, 0, sizeof(stCraftTime));
		uiPId = 0;
		uiTMMode = 0;
		uiVCId = 0;
		uiVCCount = 0;
		uiFrameCount = 0;
		uiDataSize = 0;
		ucPri = 0;
		memset(szData, 0, sizeof(szData));
	}
}ST_TMSOURCECODE;


int getStationMask(const ST_TMSOURCECODE &tmSourceCode)
{
	int ret;
	int datatype = 0;
	foreach(MDataType st_data, st_datas)
	{
		if(st_data.msgType == tmSourceCode.stMsgHead.uiMsgType)
		{
			datatype = st_data.datatype;
			break;
		}
	}
	return ret;
}