#ifndef JSONPARSE_H
#define JSONPARSE_H
#include <QtCore>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QDebug>

/**
 * @brief The JSONParse class
 * JSON�ļ�������
 */
class JSONParse
{
public:
    JSONParse();
    /**
     * @brief init ��ʼ��json���
     * @param json
     */
    bool init(QString &json);

    /**
     * @brief getJsonValue ͨ����ֵ��ȡJsonValue
     * @param key
     * @return
     */
    QString getJsonValue(const QStringList &key);

private:
    QVariant jsonDocVar;

    /**
     * @brief jsonValueFind ����jsonֵ
     * @param key
     * @return
     */
    QString jsonValueFind(QVariantMap jsonMap,const QStringList &key);

};

#endif // JSONPARSE_H
