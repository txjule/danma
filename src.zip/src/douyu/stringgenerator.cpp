#include "stringgenerator.h"

/**
 * @brief StringGenerator::StringGenerator
 * html�ַ�������
 */
StringGenerator::StringGenerator()
{

}

QString StringGenerator::getDashedLine()
{
    return TE(QString("#787775"),QString("consolas"),QString("----------------------------"));
}

QString StringGenerator::getString(QMap<QString, QString> &messageMap)
{
    QString str = "";
    QString font_color_blue = "#3B91C5";
    QString font_color_red = "#E34945";
    QString font_color_black = "#454545";
    QString font_MS = "Microsoft YaHei";
    QString font_Con = "consolas";

    if(messageMap["type"] == "chatmsg") //����
    {
        str = QString("%1 %2 %3 %4").arg(TE(font_color_blue,font_MS,messageMap["nn"]))
                .arg(TE(font_color_red,font_Con,"[lv."+messageMap["level"]+"]"))
                .arg(TE(font_color_blue,font_MS,":"))
                .arg(TE(font_color_black,font_MS,messageMap["txt"]));
     }

    else if(messageMap["type"] == "onlinegift") //��ȡ���豩��
    {
        str = QString("");
    }
    else if(messageMap["type"] == "dgb") //��������
    {
        /*-----------------------------------------------------------------------------------
         * gfid    |  50   |     53        |  57       |  52     |  54         |     59     |
         * ---------------------------------------------------------------------------------
         * ��ʾ����| 100����|�Ұ���(520����)|��(0.1���)|666(6���)|�ɻ�(100���)|���(500���)|
         * ----------------------------------------------------------------------------------
         *
         */

        int gfid = messageMap["gfid"].toInt();
        QString gfid_str = "";
        switch (gfid) {
        case 50:
            gfid_str = "100����";
            break;
        case 52:
            gfid_str = "6���(666)";
            break;
        case 53:
            gfid_str = "520����(�Ұ���)";
            break;
        case 54:
            gfid_str = "100���(�ɻ�)";
            break;
        case 57:
            gfid_str = "0.1���(��)";
            break;
        case 59:
            gfid_str = "500���(���)";
            break;
        default:
            gfid_str = "ʲô��?(����)";
            break;
        }
        str = QString("%1 %2 %3").arg(TE(font_color_blue,font_MS,messageMap["nn"]))
                .arg(TE(font_color_black,font_MS,"���͸�����"))
                .arg(TE(font_color_red,font_Con+","+font_MS,gfid_str));
    }
    else if(messageMap["type"] == "uenter") //���������û����뷿��
    {
    }
    else if(messageMap["type"] == "bc_buy_deserve") //�û����ͳ���֪ͨ��Ϣ
    {
        str = QString("%1 %2 %3 %4").arg(TE(font_color_black,font_MS,"��������:"))
                .arg(TE(font_color_red,font_MS,"��������:"+messageMap["cnt"]))
                .arg(TE(font_color_blue,font_MS,"���ڵȼ�:"+messageMap["lev"]))
                .arg(TE(font_color_black,font_MS,"�û���Ϣ:"+messageMap["sui"]));
    }
    else if(messageMap["type"] == "connectstate")
    {
        str = QString("%1 %2 %3").arg(TE(font_color_red,font_Con,"["+messageMap["time"]+"]"))
                .arg(TE(font_color_blue,font_MS,"�����:"+messageMap["roomid"]))
                .arg(TE(font_color_black,font_MS,messageMap["state"]));
    }
    else
    {
        str = "";
    }
    return str;
}


QString StringGenerator::TE(QString color, QString font_family,QString txt)
{
    return QString("<font style=\"font-family:%1;color:%2\">%3</font>").arg(font_family)
            .arg(color).arg(txt);
}
