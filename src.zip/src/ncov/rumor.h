#ifndef RUMOR_H
#define RUMOR_H

#include <QDialog>

#include <QFile>
//�������ͷ�ļ�
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkConfigurationManager>
#include <QDesktopServices>


//JSON���ͷ�ļ�
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

#include "rumor_info.h"

namespace Ui {
class rumor;
}

class rumor : public QDialog
{
    Q_OBJECT

public:
    explicit rumor(QWidget *parent = 0);
    ~rumor();
    void getRumorNews(uint8_t page);
    void parseRumor(QString filename);
    void disRumorNews(QJsonArray content_arr);

private slots:
    void anchorClickedSlot(const QUrl& url);
    void httpReadyRead();   //�п�������
    void httpFinished();  //�������

private:
    Ui::rumor *ui;
//    QString rumorApi = "https://vp.fact.qq.com/loadmore?page=0&_=1581341095686";
    QString rumorApi = "https://vp.fact.qq.com/loadmore?page=";
    QString rumorUrl = "https://vp.fact.qq.com/article?id=";
    uint8_t rumorPage = 0;

    QString bgmClr_true = "42a163";
    QString bgmClr_fake = "c41f20";
    QString bgmClr_doubt = "484848";

    QString rumorHtmlFileName = "html_rumor.txt";

    QNetworkAccessManager *manager;
    QNetworkReply *reply;
    QUrl url;
    QFile *file;
    QString filename;
//    QString html;
    rumor_info info;
};

#endif // RUMOR_H
