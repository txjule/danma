/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <qcustomplot.h>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QHBoxLayout *horizontalLayout_12;
    QVBoxLayout *verticalLayout_10;
    QLabel *lbe_pic;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_8;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_9;
    QLabel *lbe_update_time;
    QSpacerItem *horizontalSpacer;
    QFrame *line;
    QHBoxLayout *horizontalLayout_7;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_8;
    QLabel *lbe_add_confirm;
    QLabel *lbe_total_confirm;
    QLabel *lbe_confirm;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_7;
    QLabel *lbe_add_heal;
    QLabel *lbe_total_heal;
    QLabel *lbe_heal;
    QWidget *widget2;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QLabel *lbe_add_dead;
    QLabel *lbe_total_dead;
    QLabel *lbe_dead;
    QHBoxLayout *horizontalLayout_13;
    QWidget *widget3;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_10;
    QLabel *lbe_add_nowConfirm;
    QLabel *lbe_total_nowConfirm;
    QLabel *lbe_confirm_2;
    QWidget *widget4;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_6;
    QLabel *lbe_add_suspect;
    QLabel *lbe_total_suspect;
    QLabel *lbe_suspect;
    QWidget *widget5;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_12;
    QLabel *lbe_add_nowSevere;
    QLabel *lbe_total_nowSevere;
    QLabel *lbe_heal_2;
    QFrame *line_2;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_31;
    QLabel *label_33;
    QSpacerItem *horizontalSpacer_2;
    QTreeWidget *tree;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_32;
    QLabel *lbe_countryTotal;
    QSpacerItem *horizontalSpacer_3;
    QTreeWidget *tree_2;
    QVBoxLayout *verticalLayout_9;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_21;
    QLabel *lbe_chart_name;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_22;
    QHBoxLayout *horizontalLayout_23;
    QLabel *lbe_chart_line1_clr;
    QLabel *lbe_chart_line1_name;
    QHBoxLayout *horizontalLayout_24;
    QLabel *lbe_chart_line2_clr;
    QLabel *lbe_chart_line2_name;
    QCustomPlot *widget_chart;
    QHBoxLayout *horizontalLayout;
    QPushButton *btn_line_0;
    QPushButton *btn_line_1;
    QPushButton *btn_line_2;
    QPushButton *btn_line_3;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_30;
    QSpacerItem *horizontalSpacer_6;
    QTextBrowser *tb_news;
    QHBoxLayout *horizontalLayout_14;
    QPushButton *btn_rumor;
    QPushButton *btn_update;
    QPushButton *btn_about;
    QPushButton *btn_chkUpdate;
    QButtonGroup *btn_group;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(1130, 731);
        Dialog->setMinimumSize(QSize(1130, 731));
        Dialog->setMaximumSize(QSize(1130, 731));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(14);
        Dialog->setFont(font);
        Dialog->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        horizontalLayout_12 = new QHBoxLayout(Dialog);
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        lbe_pic = new QLabel(Dialog);
        lbe_pic->setObjectName(QString::fromUtf8("lbe_pic"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lbe_pic->sizePolicy().hasHeightForWidth());
        lbe_pic->setSizePolicy(sizePolicy);
        lbe_pic->setMinimumSize(QSize(0, 118));
        lbe_pic->setStyleSheet(QString::fromUtf8("image: url(:/new_top.jpg);"));
        lbe_pic->setScaledContents(true);
        lbe_pic->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lbe_pic->setOpenExternalLinks(true);

        verticalLayout_10->addWidget(lbe_pic);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_9 = new QLabel(Dialog);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(12);
        label_9->setFont(font1);
        label_9->setStyleSheet(QString::fromUtf8("color: rgb(91, 79, 65);"));

        horizontalLayout_2->addWidget(label_9);

        lbe_update_time = new QLabel(Dialog);
        lbe_update_time->setObjectName(QString::fromUtf8("lbe_update_time"));
        lbe_update_time->setFont(font1);

        horizontalLayout_2->addWidget(lbe_update_time);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        horizontalLayout_8->addLayout(horizontalLayout_2);


        verticalLayout_5->addLayout(horizontalLayout_8);

        line = new QFrame(Dialog);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_5->addWidget(line);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(5);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        widget = new QWidget(Dialog);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(253,241,241);\n"
"border-top-left-radius:10px;"));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font1);
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(79, 79, 79);"));
        label_8->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(label_8);

        lbe_add_confirm = new QLabel(widget);
        lbe_add_confirm->setObjectName(QString::fromUtf8("lbe_add_confirm"));
        lbe_add_confirm->setFont(font1);
        lbe_add_confirm->setStyleSheet(QString::fromUtf8("color: rgb(204,30,30);"));

        horizontalLayout_3->addWidget(lbe_add_confirm);


        verticalLayout->addLayout(horizontalLayout_3);

        lbe_total_confirm = new QLabel(widget);
        lbe_total_confirm->setObjectName(QString::fromUtf8("lbe_total_confirm"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font2.setPointSize(30);
        font2.setBold(true);
        font2.setWeight(75);
        font2.setStyleStrategy(QFont::PreferDefault);
        lbe_total_confirm->setFont(font2);
        lbe_total_confirm->setLayoutDirection(Qt::LeftToRight);
        lbe_total_confirm->setStyleSheet(QString::fromUtf8("color: rgb(204,30,30);"));
        lbe_total_confirm->setLineWidth(1);
        lbe_total_confirm->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(lbe_total_confirm);

        lbe_confirm = new QLabel(widget);
        lbe_confirm->setObjectName(QString::fromUtf8("lbe_confirm"));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font3.setPointSize(15);
        lbe_confirm->setFont(font3);
        lbe_confirm->setStyleSheet(QString::fromUtf8(""));
        lbe_confirm->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(lbe_confirm);


        horizontalLayout_7->addWidget(widget);

        widget1 = new QWidget(Dialog);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setStyleSheet(QString::fromUtf8("background-color: rgb(241, 248, 244);"));
        verticalLayout_4 = new QVBoxLayout(widget1);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_7 = new QLabel(widget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font1);
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(79, 79, 79);"));
        label_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_6->addWidget(label_7);

        lbe_add_heal = new QLabel(widget1);
        lbe_add_heal->setObjectName(QString::fromUtf8("lbe_add_heal"));
        lbe_add_heal->setFont(font1);
        lbe_add_heal->setStyleSheet(QString::fromUtf8("color: rgb(23, 139, 80);"));

        horizontalLayout_6->addWidget(lbe_add_heal);


        verticalLayout_4->addLayout(horizontalLayout_6);

        lbe_total_heal = new QLabel(widget1);
        lbe_total_heal->setObjectName(QString::fromUtf8("lbe_total_heal"));
        QFont font4;
        font4.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font4.setPointSize(30);
        font4.setBold(true);
        font4.setWeight(75);
        lbe_total_heal->setFont(font4);
        lbe_total_heal->setStyleSheet(QString::fromUtf8("color: rgb(23, 139, 80);"));
        lbe_total_heal->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(lbe_total_heal);

        lbe_heal = new QLabel(widget1);
        lbe_heal->setObjectName(QString::fromUtf8("lbe_heal"));
        lbe_heal->setFont(font3);
        lbe_heal->setStyleSheet(QString::fromUtf8(""));
        lbe_heal->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(lbe_heal);


        horizontalLayout_7->addWidget(widget1);

        widget2 = new QWidget(Dialog);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        widget2->setStyleSheet(QString::fromUtf8("background-color: rgb(243, 246, 248);\n"
"border-top-right-radius:10px;"));
        verticalLayout_3 = new QVBoxLayout(widget2);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_5 = new QLabel(widget2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(79, 79, 79);"));
        label_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_5->addWidget(label_5);

        lbe_add_dead = new QLabel(widget2);
        lbe_add_dead->setObjectName(QString::fromUtf8("lbe_add_dead"));
        lbe_add_dead->setFont(font1);
        lbe_add_dead->setStyleSheet(QString::fromUtf8("color: rgb(102, 102, 108);"));

        horizontalLayout_5->addWidget(lbe_add_dead);


        verticalLayout_3->addLayout(horizontalLayout_5);

        lbe_total_dead = new QLabel(widget2);
        lbe_total_dead->setObjectName(QString::fromUtf8("lbe_total_dead"));
        lbe_total_dead->setFont(font4);
        lbe_total_dead->setStyleSheet(QString::fromUtf8("color: rgb(102, 102, 108);"));
        lbe_total_dead->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(lbe_total_dead);

        lbe_dead = new QLabel(widget2);
        lbe_dead->setObjectName(QString::fromUtf8("lbe_dead"));
        lbe_dead->setFont(font3);
        lbe_dead->setStyleSheet(QString::fromUtf8(""));
        lbe_dead->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(lbe_dead);


        horizontalLayout_7->addWidget(widget2);


        verticalLayout_5->addLayout(horizontalLayout_7);

        verticalLayout_5->setStretch(0, 4);

        verticalLayout_10->addLayout(verticalLayout_5);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(5);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        widget3 = new QWidget(Dialog);
        widget3->setObjectName(QString::fromUtf8("widget3"));
        widget3->setStyleSheet(QString::fromUtf8("background-color: rgb(253, 241, 241);\n"
"border-bottom-left-radius:10px"));
        verticalLayout_11 = new QVBoxLayout(widget3);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        label_10 = new QLabel(widget3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setFont(font1);
        label_10->setStyleSheet(QString::fromUtf8("color: rgb(79, 79, 79);"));
        label_10->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_15->addWidget(label_10);

        lbe_add_nowConfirm = new QLabel(widget3);
        lbe_add_nowConfirm->setObjectName(QString::fromUtf8("lbe_add_nowConfirm"));
        lbe_add_nowConfirm->setFont(font1);
        lbe_add_nowConfirm->setStyleSheet(QString::fromUtf8("color: rgb(245, 82, 83);"));

        horizontalLayout_15->addWidget(lbe_add_nowConfirm);


        verticalLayout_11->addLayout(horizontalLayout_15);

        lbe_total_nowConfirm = new QLabel(widget3);
        lbe_total_nowConfirm->setObjectName(QString::fromUtf8("lbe_total_nowConfirm"));
        lbe_total_nowConfirm->setFont(font4);
        lbe_total_nowConfirm->setLayoutDirection(Qt::LeftToRight);
        lbe_total_nowConfirm->setStyleSheet(QString::fromUtf8("color: rgb(245, 82, 83);"));
        lbe_total_nowConfirm->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(lbe_total_nowConfirm);

        lbe_confirm_2 = new QLabel(widget3);
        lbe_confirm_2->setObjectName(QString::fromUtf8("lbe_confirm_2"));
        lbe_confirm_2->setFont(font3);
        lbe_confirm_2->setStyleSheet(QString::fromUtf8(""));
        lbe_confirm_2->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(lbe_confirm_2);


        horizontalLayout_13->addWidget(widget3);

        widget4 = new QWidget(Dialog);
        widget4->setObjectName(QString::fromUtf8("widget4"));
        widget4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 245, 233);"));
        verticalLayout_2 = new QVBoxLayout(widget4);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_6 = new QLabel(widget4);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font1);
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(79, 79, 79);"));
        label_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_4->addWidget(label_6);

        lbe_add_suspect = new QLabel(widget4);
        lbe_add_suspect->setObjectName(QString::fromUtf8("lbe_add_suspect"));
        lbe_add_suspect->setFont(font1);
        lbe_add_suspect->setStyleSheet(QString::fromUtf8("color: rgb(255, 150, 30);"));

        horizontalLayout_4->addWidget(lbe_add_suspect);


        verticalLayout_2->addLayout(horizontalLayout_4);

        lbe_total_suspect = new QLabel(widget4);
        lbe_total_suspect->setObjectName(QString::fromUtf8("lbe_total_suspect"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lbe_total_suspect->sizePolicy().hasHeightForWidth());
        lbe_total_suspect->setSizePolicy(sizePolicy1);
        lbe_total_suspect->setFont(font4);
        lbe_total_suspect->setStyleSheet(QString::fromUtf8("color: rgb(255, 150, 30);\n"
""));
        lbe_total_suspect->setTextFormat(Qt::AutoText);
        lbe_total_suspect->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(lbe_total_suspect);

        lbe_suspect = new QLabel(widget4);
        lbe_suspect->setObjectName(QString::fromUtf8("lbe_suspect"));
        lbe_suspect->setFont(font3);
        lbe_suspect->setStyleSheet(QString::fromUtf8(""));
        lbe_suspect->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(lbe_suspect);


        horizontalLayout_13->addWidget(widget4);

        widget5 = new QWidget(Dialog);
        widget5->setObjectName(QString::fromUtf8("widget5"));
        widget5->setStyleSheet(QString::fromUtf8("background-color: rgb(250, 242, 246);\n"
"border-bottom-right-radius:10px"));
        verticalLayout_13 = new QVBoxLayout(widget5);
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setContentsMargins(11, 11, 11, 11);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        label_12 = new QLabel(widget5);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setFont(font1);
        label_12->setStyleSheet(QString::fromUtf8("color: rgb(79, 79, 79);"));
        label_12->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_17->addWidget(label_12);

        lbe_add_nowSevere = new QLabel(widget5);
        lbe_add_nowSevere->setObjectName(QString::fromUtf8("lbe_add_nowSevere"));
        lbe_add_nowSevere->setFont(font1);
        lbe_add_nowSevere->setStyleSheet(QString::fromUtf8("color: rgb(202,63,129);"));

        horizontalLayout_17->addWidget(lbe_add_nowSevere);


        verticalLayout_13->addLayout(horizontalLayout_17);

        lbe_total_nowSevere = new QLabel(widget5);
        lbe_total_nowSevere->setObjectName(QString::fromUtf8("lbe_total_nowSevere"));
        lbe_total_nowSevere->setFont(font4);
        lbe_total_nowSevere->setStyleSheet(QString::fromUtf8("color: rgb(202,63,129);"));
        lbe_total_nowSevere->setAlignment(Qt::AlignCenter);

        verticalLayout_13->addWidget(lbe_total_nowSevere);

        lbe_heal_2 = new QLabel(widget5);
        lbe_heal_2->setObjectName(QString::fromUtf8("lbe_heal_2"));
        lbe_heal_2->setFont(font3);
        lbe_heal_2->setStyleSheet(QString::fromUtf8(""));
        lbe_heal_2->setAlignment(Qt::AlignCenter);

        verticalLayout_13->addWidget(lbe_heal_2);


        horizontalLayout_13->addWidget(widget5);


        verticalLayout_10->addLayout(horizontalLayout_13);

        line_2 = new QFrame(Dialog);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_10->addWidget(line_2);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        label_31 = new QLabel(Dialog);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        QFont font5;
        font5.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font5.setPointSize(13);
        label_31->setFont(font5);
        label_31->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 127);"));

        horizontalLayout_10->addWidget(label_31);

        label_33 = new QLabel(Dialog);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        QFont font6;
        font6.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font6.setPointSize(10);
        label_33->setFont(font6);
        label_33->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_10->addWidget(label_33);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_2);


        verticalLayout_6->addLayout(horizontalLayout_10);

        tree = new QTreeWidget(Dialog);
        QFont font7;
        font7.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font7.setPointSize(12);
        font7.setBold(true);
        font7.setWeight(75);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setFont(4, font7);
        __qtreewidgetitem->setFont(3, font7);
        __qtreewidgetitem->setFont(2, font7);
        __qtreewidgetitem->setFont(1, font7);
        __qtreewidgetitem->setFont(0, font7);
        tree->setHeaderItem(__qtreewidgetitem);
        tree->setObjectName(QString::fromUtf8("tree"));
        tree->setFont(font1);
        tree->setStyleSheet(QString::fromUtf8(""));
        tree->setLineWidth(2);
        tree->setSortingEnabled(true);
        tree->header()->setVisible(true);
        tree->header()->setCascadingSectionResizes(false);
        tree->header()->setHighlightSections(false);
        tree->header()->setProperty("showSortIndicator", QVariant(true));

        verticalLayout_6->addWidget(tree);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_32 = new QLabel(Dialog);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setFont(font5);
        label_32->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 127);"));

        horizontalLayout_9->addWidget(label_32);

        lbe_countryTotal = new QLabel(Dialog);
        lbe_countryTotal->setObjectName(QString::fromUtf8("lbe_countryTotal"));
        lbe_countryTotal->setFont(font6);
        lbe_countryTotal->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_9->addWidget(lbe_countryTotal);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_3);


        verticalLayout_6->addLayout(horizontalLayout_9);

        tree_2 = new QTreeWidget(Dialog);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem();
        __qtreewidgetitem1->setFont(3, font7);
        __qtreewidgetitem1->setFont(2, font7);
        __qtreewidgetitem1->setFont(1, font7);
        __qtreewidgetitem1->setFont(0, font7);
        tree_2->setHeaderItem(__qtreewidgetitem1);
        tree_2->setObjectName(QString::fromUtf8("tree_2"));
        tree_2->setFont(font1);
        tree_2->setStyleSheet(QString::fromUtf8(""));
        tree_2->setLineWidth(2);
        tree_2->setSortingEnabled(true);
        tree_2->header()->setVisible(true);
        tree_2->header()->setCascadingSectionResizes(true);
        tree_2->header()->setHighlightSections(true);
        tree_2->header()->setProperty("showSortIndicator", QVariant(true));

        verticalLayout_6->addWidget(tree_2);

        verticalLayout_6->setStretch(0, 1);
        verticalLayout_6->setStretch(1, 8);
        verticalLayout_6->setStretch(2, 1);
        verticalLayout_6->setStretch(3, 8);

        verticalLayout_10->addLayout(verticalLayout_6);

        verticalLayout_10->setStretch(0, 1);
        verticalLayout_10->setStretch(1, 60);
        verticalLayout_10->setStretch(4, 100);

        horizontalLayout_12->addLayout(verticalLayout_10);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        lbe_chart_name = new QLabel(Dialog);
        lbe_chart_name->setObjectName(QString::fromUtf8("lbe_chart_name"));
        lbe_chart_name->setFont(font5);
        lbe_chart_name->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 127);"));

        horizontalLayout_21->addWidget(lbe_chart_name);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_5);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        lbe_chart_line1_clr = new QLabel(Dialog);
        lbe_chart_line1_clr->setObjectName(QString::fromUtf8("lbe_chart_line1_clr"));
        lbe_chart_line1_clr->setMinimumSize(QSize(17, 17));
        lbe_chart_line1_clr->setMaximumSize(QSize(17, 17));
        lbe_chart_line1_clr->setStyleSheet(QString::fromUtf8("background-color: rgb(33,144,5);"));

        horizontalLayout_23->addWidget(lbe_chart_line1_clr);

        lbe_chart_line1_name = new QLabel(Dialog);
        lbe_chart_line1_name->setObjectName(QString::fromUtf8("lbe_chart_line1_name"));
        lbe_chart_line1_name->setFont(font6);

        horizontalLayout_23->addWidget(lbe_chart_line1_name);


        horizontalLayout_22->addLayout(horizontalLayout_23);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        lbe_chart_line2_clr = new QLabel(Dialog);
        lbe_chart_line2_clr->setObjectName(QString::fromUtf8("lbe_chart_line2_clr"));
        lbe_chart_line2_clr->setMinimumSize(QSize(17, 17));
        lbe_chart_line2_clr->setMaximumSize(QSize(17, 17));
        lbe_chart_line2_clr->setStyleSheet(QString::fromUtf8("background-color: rgb(135, 135, 139);"));

        horizontalLayout_24->addWidget(lbe_chart_line2_clr);

        lbe_chart_line2_name = new QLabel(Dialog);
        lbe_chart_line2_name->setObjectName(QString::fromUtf8("lbe_chart_line2_name"));
        lbe_chart_line2_name->setFont(font6);

        horizontalLayout_24->addWidget(lbe_chart_line2_name);


        horizontalLayout_22->addLayout(horizontalLayout_24);


        horizontalLayout_21->addLayout(horizontalLayout_22);


        verticalLayout_7->addLayout(horizontalLayout_21);

        widget_chart = new QCustomPlot(Dialog);
        widget_chart->setObjectName(QString::fromUtf8("widget_chart"));
        widget_chart->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 127);"));

        verticalLayout_7->addWidget(widget_chart);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        btn_line_0 = new QPushButton(Dialog);
        btn_group = new QButtonGroup(Dialog);
        btn_group->setObjectName(QString::fromUtf8("btn_group"));
        btn_group->addButton(btn_line_0);
        btn_line_0->setObjectName(QString::fromUtf8("btn_line_0"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(btn_line_0->sizePolicy().hasHeightForWidth());
        btn_line_0->setSizePolicy(sizePolicy2);
        btn_line_0->setMinimumSize(QSize(130, 60));
        btn_line_0->setMaximumSize(QSize(130, 60));
        btn_line_0->setFont(font1);
        btn_line_0->setStyleSheet(QString::fromUtf8("border:2px groove rgb(126, 126, 126);\n"
"border-radius:8px;\n"
"background-color: rgb(243, 246, 248);"));

        horizontalLayout->addWidget(btn_line_0);

        btn_line_1 = new QPushButton(Dialog);
        btn_group->addButton(btn_line_1);
        btn_line_1->setObjectName(QString::fromUtf8("btn_line_1"));
        sizePolicy2.setHeightForWidth(btn_line_1->sizePolicy().hasHeightForWidth());
        btn_line_1->setSizePolicy(sizePolicy2);
        btn_line_1->setMinimumSize(QSize(130, 60));
        btn_line_1->setMaximumSize(QSize(130, 60));
        btn_line_1->setFont(font1);
        btn_line_1->setStyleSheet(QString::fromUtf8("border:2px groove rgb(126, 126, 126);\n"
"border-radius:8px;\n"
"background-color: rgb(243, 246, 248);"));

        horizontalLayout->addWidget(btn_line_1);

        btn_line_2 = new QPushButton(Dialog);
        btn_group->addButton(btn_line_2);
        btn_line_2->setObjectName(QString::fromUtf8("btn_line_2"));
        sizePolicy2.setHeightForWidth(btn_line_2->sizePolicy().hasHeightForWidth());
        btn_line_2->setSizePolicy(sizePolicy2);
        btn_line_2->setMinimumSize(QSize(130, 60));
        btn_line_2->setMaximumSize(QSize(130, 60));
        btn_line_2->setFont(font1);
        btn_line_2->setStyleSheet(QString::fromUtf8("border:2px groove rgb(126, 126, 126);\n"
"border-radius:8px;\n"
"background-color: rgb(243, 246, 248);"));

        horizontalLayout->addWidget(btn_line_2);

        btn_line_3 = new QPushButton(Dialog);
        btn_group->addButton(btn_line_3);
        btn_line_3->setObjectName(QString::fromUtf8("btn_line_3"));
        sizePolicy2.setHeightForWidth(btn_line_3->sizePolicy().hasHeightForWidth());
        btn_line_3->setSizePolicy(sizePolicy2);
        btn_line_3->setMinimumSize(QSize(130, 60));
        btn_line_3->setMaximumSize(QSize(130, 60));
        btn_line_3->setFont(font1);
        btn_line_3->setStyleSheet(QString::fromUtf8("border:2px groove rgb(126, 126, 126);\n"
"border-radius:8px;\n"
"background-color: rgb(243, 246, 248);"));

        horizontalLayout->addWidget(btn_line_3);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 1);
        horizontalLayout->setStretch(2, 1);
        horizontalLayout->setStretch(3, 1);

        verticalLayout_7->addLayout(horizontalLayout);

        verticalLayout_7->setStretch(0, 1);
        verticalLayout_7->setStretch(1, 10);
        verticalLayout_7->setStretch(2, 1);

        verticalLayout_9->addLayout(verticalLayout_7);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        label_30 = new QLabel(Dialog);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setFont(font5);
        label_30->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 127);"));

        horizontalLayout_11->addWidget(label_30);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_6);


        verticalLayout_8->addLayout(horizontalLayout_11);

        tb_news = new QTextBrowser(Dialog);
        tb_news->setObjectName(QString::fromUtf8("tb_news"));
        QFont font8;
        font8.setFamily(QString::fromUtf8("Microsoft YaHei"));
        font8.setPointSize(12);
        tb_news->setFont(font8);
        tb_news->setStyleSheet(QString::fromUtf8(""));

        verticalLayout_8->addWidget(tb_news);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        btn_rumor = new QPushButton(Dialog);
        btn_rumor->setObjectName(QString::fromUtf8("btn_rumor"));
        btn_rumor->setFont(font1);

        horizontalLayout_14->addWidget(btn_rumor);

        btn_update = new QPushButton(Dialog);
        btn_update->setObjectName(QString::fromUtf8("btn_update"));
        btn_update->setFont(font1);
        btn_update->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_14->addWidget(btn_update);

        btn_about = new QPushButton(Dialog);
        btn_about->setObjectName(QString::fromUtf8("btn_about"));
        btn_about->setFont(font1);

        horizontalLayout_14->addWidget(btn_about);

        btn_chkUpdate = new QPushButton(Dialog);
        btn_chkUpdate->setObjectName(QString::fromUtf8("btn_chkUpdate"));
        btn_chkUpdate->setFont(font1);
        btn_chkUpdate->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_14->addWidget(btn_chkUpdate);


        verticalLayout_8->addLayout(horizontalLayout_14);


        verticalLayout_9->addLayout(verticalLayout_8);

        verticalLayout_9->setStretch(0, 10);
        verticalLayout_9->setStretch(1, 12);

        horizontalLayout_12->addLayout(verticalLayout_9);

        horizontalLayout_12->setStretch(0, 2);
        horizontalLayout_12->setStretch(1, 1);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        lbe_pic->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><a href=\"http://www.cnblog.com/fron_csl\"><span style=\" text-decoration: underline; color:#0000ff;\"/></a></p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("Dialog", "\347\273\237\350\256\241\346\210\252\346\255\242\344\272\216", nullptr));
        lbe_update_time->setText(QCoreApplication::translate("Dialog", "2020-02-05 16:56:23", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog", "\350\276\203\344\270\212\346\227\245", nullptr));
        lbe_add_confirm->setText(QCoreApplication::translate("Dialog", "+123", nullptr));
        lbe_total_confirm->setText(QCoreApplication::translate("Dialog", "74280", nullptr));
        lbe_confirm->setText(QCoreApplication::translate("Dialog", "\347\264\257\350\256\241\347\241\256\350\257\212", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog", "\350\276\203\344\270\212\346\227\245", nullptr));
        lbe_add_heal->setText(QCoreApplication::translate("Dialog", "---", nullptr));
        lbe_total_heal->setText(QCoreApplication::translate("Dialog", "-----", nullptr));
        lbe_heal->setText(QCoreApplication::translate("Dialog", "\347\264\257\350\256\241\346\262\273\346\204\210", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog", "\350\276\203\344\270\212\346\227\245", nullptr));
        lbe_add_dead->setText(QCoreApplication::translate("Dialog", "---", nullptr));
        lbe_total_dead->setText(QCoreApplication::translate("Dialog", "-----", nullptr));
        lbe_dead->setText(QCoreApplication::translate("Dialog", "\347\264\257\350\256\241\346\255\273\344\272\241", nullptr));
        label_10->setText(QCoreApplication::translate("Dialog", "\350\276\203\344\270\212\346\227\245", nullptr));
        lbe_add_nowConfirm->setText(QCoreApplication::translate("Dialog", "---", nullptr));
        lbe_total_nowConfirm->setText(QCoreApplication::translate("Dialog", "-----", nullptr));
        lbe_confirm_2->setText(QCoreApplication::translate("Dialog", "\347\216\260\346\234\211\347\241\256\350\257\212", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog", "\344\273\212\346\227\245\346\226\260\345\242\236", nullptr));
        lbe_add_suspect->setText(QCoreApplication::translate("Dialog", "---", nullptr));
        lbe_total_suspect->setText(QCoreApplication::translate("Dialog", "-----", nullptr));
        lbe_suspect->setText(QCoreApplication::translate("Dialog", "\347\216\260\346\234\211\347\226\221\344\274\274", nullptr));
        label_12->setText(QCoreApplication::translate("Dialog", "\350\276\203\344\270\212\346\227\245", nullptr));
        lbe_add_nowSevere->setText(QCoreApplication::translate("Dialog", "---", nullptr));
        lbe_total_nowSevere->setText(QCoreApplication::translate("Dialog", "-----", nullptr));
        lbe_heal_2->setText(QCoreApplication::translate("Dialog", "\347\216\260\346\234\211\351\207\215\347\227\207", nullptr));
        label_31->setText(QCoreApplication::translate("Dialog", "\344\270\255\345\233\275\347\226\253\346\203\205", nullptr));
        label_33->setText(QCoreApplication::translate("Dialog", "(7:00-10:00\344\270\272\346\233\264\346\226\260\351\253\230\345\263\260,\346\225\260\346\215\256\345\246\202\346\234\211\346\273\236\345\220\216\350\257\267\350\260\205\350\247\243)", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = tree->headerItem();
        ___qtreewidgetitem->setText(4, QCoreApplication::translate("Dialog", "\346\255\273\344\272\241", nullptr));
        ___qtreewidgetitem->setText(3, QCoreApplication::translate("Dialog", "\346\262\273\346\204\210", nullptr));
        ___qtreewidgetitem->setText(2, QCoreApplication::translate("Dialog", "\347\264\257\350\256\241\347\241\256\350\257\212", nullptr));
        ___qtreewidgetitem->setText(1, QCoreApplication::translate("Dialog", "\346\226\260\345\242\236\347\241\256\350\257\212", nullptr));
        ___qtreewidgetitem->setText(0, QCoreApplication::translate("Dialog", "\347\234\201\345\270\202", nullptr));
        label_32->setText(QCoreApplication::translate("Dialog", "\346\265\267\345\244\226\347\226\253\346\203\205", nullptr));
        lbe_countryTotal->setText(QCoreApplication::translate("Dialog", "\347\241\256\350\257\212234\344\276\213,\346\255\273\344\272\24110\344\276\213", nullptr));
        QTreeWidgetItem *___qtreewidgetitem1 = tree_2->headerItem();
        ___qtreewidgetitem1->setText(3, QCoreApplication::translate("Dialog", "\346\255\273\344\272\241", nullptr));
        ___qtreewidgetitem1->setText(2, QCoreApplication::translate("Dialog", "\346\262\273\346\204\210", nullptr));
        ___qtreewidgetitem1->setText(1, QCoreApplication::translate("Dialog", "\347\241\256\350\257\212", nullptr));
        ___qtreewidgetitem1->setText(0, QCoreApplication::translate("Dialog", "\345\233\275\345\256\266", nullptr));
        lbe_chart_name->setText(QCoreApplication::translate("Dialog", "\345\233\276\345\220\215\347\247\260", nullptr));
        lbe_chart_line1_clr->setText(QString());
        lbe_chart_line1_name->setText(QCoreApplication::translate("Dialog", "\346\233\262\347\272\2771", nullptr));
        lbe_chart_line2_clr->setText(QString());
        lbe_chart_line2_name->setText(QCoreApplication::translate("Dialog", "\346\233\262\347\272\2772", nullptr));
        btn_line_0->setText(QCoreApplication::translate("Dialog", "\345\205\250\345\233\275\347\226\253\346\203\205\n"
"\346\226\260\345\242\236\350\266\213\345\212\277", nullptr));
        btn_line_1->setText(QCoreApplication::translate("Dialog", "\345\205\250\345\233\275\347\264\257\350\256\241\n"
"\347\241\256\350\257\212/\347\226\221\344\274\274", nullptr));
        btn_line_2->setText(QCoreApplication::translate("Dialog", "\345\205\250\345\233\275\347\264\257\350\256\241\n"
"\346\262\273\346\204\210/\346\255\273\344\272\241", nullptr));
        btn_line_3->setText(QCoreApplication::translate("Dialog", "\346\262\273\346\204\210\347\216\207\n"
"\347\227\205\346\255\273\347\216\207", nullptr));
        label_30->setText(QCoreApplication::translate("Dialog", "\346\234\200\346\226\260\345\212\250\346\200\201", nullptr));
        tb_news->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        btn_rumor->setText(QCoreApplication::translate("Dialog", "\350\276\237\350\260\243\344\277\241\346\201\257", nullptr));
        btn_update->setText(QCoreApplication::translate("Dialog", "\346\233\264\346\226\260", nullptr));
        btn_about->setText(QCoreApplication::translate("Dialog", "\345\205\263\344\272\216", nullptr));
        btn_chkUpdate->setText(QCoreApplication::translate("Dialog", "\346\243\200\346\237\245\346\233\264\346\226\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
