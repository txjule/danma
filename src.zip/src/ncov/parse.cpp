#include "dialog.h"
#include "ui_dialog.h"

//JSON���ݽ���
int Dialog::dataParse(QByteArray str)
{
    QJsonParseError err_rpt;
    QJsonDocument root_Doc = QJsonDocument::fromJson(str, &err_rpt);
//    qDebug() << "ok ";
    if(err_rpt.error != QJsonParseError::NoError)
    {
        file->remove();
        emit on_btn_update_clicked();
        qDebug() << "JSON��ʽ����";
//        return -1;
    }
//    qDebug() << "JSON��ʽ��ȷ";
    if(root_Doc.isObject())
    {
        QJsonObject root_obj = root_Doc.object();   //����JSON���󣬲����ַ���
        if(root_obj.contains("data"))
        {
//            qDebug() << root_obj.value("ret").toString();

            QString data_str = root_obj.value("data").toString();
            QJsonObject data_obj = QJsonDocument::fromJson(data_str.toUtf8(),&err_rpt).object();
            if(selAPI == 1)
            {
                //��ȡ��ʾ����
                QJsonObject AddSwitch = data_obj.value("showAddSwitch").toObject();
                parseAddSwitch(AddSwitch);

                QJsonObject chinaTotal = data_obj.value("chinaTotal").toObject();
                QJsonObject chinaAdd = data_obj.value("chinaAdd").toObject();
                //��ȡ�ۼ����ݺ��������ݣ�����ʾ
                getTotalAddData(chinaTotal, chinaAdd);  //ȫ���ۼƺ�����������ʾ
                QString lastUpdateTime = data_obj.value("lastUpdateTime").toString();
                ui->lbe_update_time->setText(lastUpdateTime);

                QJsonArray areaTree_obj = data_obj.value("areaTree").toArray();
                QJsonObject chinaTree_obj = areaTree_obj.at(0).toObject();     //��0�����й�
                chinaTreeParse(chinaTree_obj);
                countryTreeParse(areaTree_obj);
            }
            /*����������api2*/
            else if(selAPI == 2)
            {
                QJsonArray chinaDayListObj = data_obj.value("chinaDayList").toArray();
                chinaDayListParse(chinaDayListObj);

                QJsonArray chinaDayAddListObj = data_obj.value("chinaDayAddList").toArray();
                chinaDayAddListParse(chinaDayAddListObj);

                QJsonArray articleArr = data_obj.value("articleList").toArray();
                articleParse(articleArr);
                connect(ui->widget_chart, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(widget_chart_event(QMouseEvent*)));
                connect(ui->btn_group, SIGNAL(buttonClicked(int)), this, SLOT(drawCharts(int)));
                //Ĭ�ϻ���
                setSelectStyle(0);
                clickId = 0;     //�޸�����������ʰ�ť֮���ٸ��°�ť����ʱtip��λ����%��BUG
                widgetDrawLine(ui->widget_chart, "��������/ȷ������", "����ȷ��", "��������",
                    clr1_1, clr1_2, AddDate, AddConfirmDub, AddSuspectDub);
            }
        }
        qDebug() << "�������ݸ��³ɹ�";
//        ui->btn_update->setEnabled(true);
        if(selAPI == 2)
            emit on_btn_update_clicked();
    }
    else
        qDebug() << "����ʧ��";
    return 0;
}

//�ۼ�ȷ��/����/����/����
void Dialog::chinaDayListParse(QJsonArray chinaDayListObj)
{
    //�ۼ�������1.13��ʼͳ��
//    size = getDay("20200113");

    uint16_t arraySize = chinaDayListObj.size();
//    qDebug() << arraySize;
    //size���ñ������clear֮ǰ����ʡ��
    TotalDate.clear();
    TotalConfirmDub.clear();
    TotalSuspectDub.clear();
    TotalDeadDub.clear();
    TotalHealDub.clear();

    RateDate.clear();
    chinaDayListHealRate.clear();       //�ۼ������ʣ���1.20��ʼ
    chinaDayListDeadRate.clear();       //�ۼ������ʣ���1.20��ʼ
    for(int i = 0; i < arraySize; i++)
    {
        QJsonObject chinaDay = chinaDayListObj.at(i).toObject();

        QString date = chinaDay.value("date").toString();
        double deadRate = chinaDay.value("deadRate").toString().toDouble();
        double healRate = chinaDay.value("healRate").toString().toDouble();

        TotalDate << date;

        if(i >= 7)  //��1.20��ʼ���
        {
            chinaDayListHealRate << healRate;
            chinaDayListDeadRate << deadRate;
            RateDate << date;
//            qDebug() << deadRate << healRate;
        }

        double confirm = chinaDay.value("confirm").toDouble();
        double suspect = chinaDay.value("suspect").toDouble();
        double dead = chinaDay.value("dead").toDouble();
        double heal = chinaDay.value("heal").toDouble();

        TotalConfirmDub << confirm;
        TotalSuspectDub << suspect;
        TotalDeadDub << dead;
        TotalHealDub << heal;
    }
}

//����ȷ��/����/����/����
void Dialog::chinaDayAddListParse(QJsonArray chinaDayAddListObj)
{
    uint16_t arraySize = chinaDayAddListObj.size();
//    qDebug() << arraySize;
    //size���ñ������clear֮ǰ����ʡ��
    AddDate.clear();
    AddConfirmDub.clear();
    AddSuspectDub.clear();
    AddDeadDub.clear();
    AddHealDub.clear();

    for(int i = 0; i < arraySize; i++)
    {
        QJsonObject chinaDay = chinaDayAddListObj.at(i).toObject();
        QString date = chinaDay.value("date").toString();
        AddDate << date;

        double confirm = chinaDay.value("confirm").toDouble();
        double suspect = chinaDay.value("suspect").toDouble();
        double dead = chinaDay.value("dead").toDouble();
        double heal = chinaDay.value("heal").toDouble();

        AddConfirmDub << confirm;
        AddSuspectDub << suspect;
        AddDeadDub << dead;
        AddHealDub << heal;

        if(i == arraySize - 1)  //��������ȡ���µ���ʷ����
            ui->lbe_add_suspect->setText("+" + QString::number(AddSuspectDub[arraySize-1]));
    }
}
//�й��������ݽ���
void Dialog::chinaTreeParse(QJsonObject chinaTree)
{
    QJsonObject chinaTotal_obj = chinaTree.value("total").toObject();
//    QString chinaName = chinaTree.value("name").toString();
//    QString chinaTotalConfirm = QString::number(chinaTotal_obj.value("confirm").toInt());    //28130;
//    QString chinaTotalSuspect = QString::number(chinaTotal_obj.value("suspect").toInt());    //0;
//    QString chinaTotalDead    = QString::number(chinaTotal_obj.value("dead").toInt());        //564
//    QString chinaTotalHeal    = QString::number(chinaTotal_obj.value("heal").toInt());        //1301

    QJsonArray provinces_obj = chinaTree.value("children").toArray();    //�������е�ʡ��

    uint16_t provinceSize = provinces_obj.size();
//    qDebug() << provinceSize;       //ʡ�ݸ���34
    ui->tree->clear();
    ui->tree->sortByColumn(2, Qt::DescendingOrder);      //�ۼ�ȷ������

    for(int i = 0; i < provinceSize; i++)   //0-33
    {
        QJsonObject province_obj = provinces_obj.at(i).toObject();      //0:����ʡ
        dataAddTree(province_obj);
        // 0       1        2        3       4
        //ʡ��  ����ȷ��  �ۼ�ȷ��  �ۼ�����  �ۼ�����
    }
}
//�й�����������״��ʾ
void Dialog::dataAddTree(QJsonObject province_obj)
{
    QString provinceName = province_obj.value("name").toString();   //"����"
    //ʡ������
    uint16_t provinceAddConfirm   = province_obj.value("today").toObject().value("confirm").toDouble();
    QJsonObject provinceTotal_obj = province_obj.value("total").toObject();
    //ʡ���ۼ�
    uint16_t provinceTotalConfirm = provinceTotal_obj.value("confirm").toDouble();
    uint16_t provinceTotalHeal    = provinceTotal_obj.value("heal").toDouble();
    uint16_t provinceTotalDead    = provinceTotal_obj.value("dead").toDouble();

//    qDebug() << provinceName << provinceAddConfirm << provinceTotalConfirm << provinceTotalHeal << provinceTotalDead << citySize;       //ʡ��������ٸ���
    // 0       1        2        3       4
    //ʡ��  ����ȷ��  �ۼ�ȷ��  �ۼ�����  �ۼ�����
    QTreeWidgetItem *province = new QTreeWidgetItem(ui->tree);

    province->setData(0, Qt::DisplayRole, provinceName);
    province->setData(1, Qt::DisplayRole, provinceAddConfirm);
    province->setData(2, Qt::DisplayRole, provinceTotalConfirm);
    province->setData(3, Qt::DisplayRole, provinceTotalHeal);
    province->setData(4, Qt::DisplayRole, provinceTotalDead);

    QJsonArray citys_obj = province_obj.value("children").toArray();    //������ǰʡ��������
    uint16_t citySize = citys_obj.size();        //���еĸ���

    for(int j = 0; j < citySize; j++)
    {
        QJsonObject city_obj = citys_obj.at(j).toObject();

        QString cityName = city_obj.value("name").toString();
        uint16_t cityAddConfirm   = city_obj.value("today").toObject().value("confirm").toInt();

        QJsonObject cityTotal_obj = city_obj.value("total").toObject();
        uint16_t cityTotalConfirm = cityTotal_obj.value("confirm").toInt();
        uint16_t cityTotalHeal    = cityTotal_obj.value("heal").toInt();
        uint16_t cityTotalDead    = cityTotal_obj.value("dead").toInt();

        QTreeWidgetItem *citys = new QTreeWidgetItem(province);

        citys->setData(0, Qt::DisplayRole, cityName);
        citys->setData(1, Qt::DisplayRole, cityAddConfirm);
        citys->setData(2, Qt::DisplayRole, cityTotalConfirm);
        citys->setData(3, Qt::DisplayRole, cityTotalHeal);
        citys->setData(4, Qt::DisplayRole, cityTotalDead);
    }
}
//�����������ݽ�������ʾ
void Dialog::countryTreeParse(QJsonArray areaTree_obj)
{
    ui->tree_2->clear();
    ui->tree_2->sortByColumn(1, Qt::DescendingOrder);      //�ۼ�ȷ������
    uint16_t TotalConfirm = 0;
    uint16_t TotalDead = 0;
    for(int i = 1; i < areaTree_obj.size(); i++)
    {
        QJsonObject obj = areaTree_obj.at(i).toObject();
        QString countryName = obj.value("name").toString(); //�ձ�
        QJsonObject countryTotal_obj = obj.value("total").toObject();
        uint16_t countryTotalConfirm = countryTotal_obj.value("confirm").toDouble();
        uint16_t countryTotalHeal    = countryTotal_obj.value("heal").toDouble();
        uint16_t countryTotalDead    = countryTotal_obj.value("dead").toDouble();
        //0      3    2     0
        //����  ȷ��  ����  ����
        QTreeWidgetItem *country = new QTreeWidgetItem(ui->tree_2);
        country->setData(0, Qt::DisplayRole, countryName);
        country->setData(1, Qt::DisplayRole, countryTotalConfirm);
        country->setData(2, Qt::DisplayRole, countryTotalHeal);
        country->setData(3, Qt::DisplayRole, countryTotalDead);

        TotalConfirm += countryTotalConfirm;
        TotalDead += countryTotalDead;
    //    qDebug() << countryName << countryTotalConfirm << countryTotalHeal <<countryTotalDead << countryTotalSucpect ;
    }
    QString text = "ȷ��" + QString::number(TotalConfirm) + "��,����" + QString::number(TotalDead) + "��";
    ui->lbe_countryTotal->setText(text);
}

int Dialog::getTotalAddData(QJsonObject chinaTotal, QJsonObject chinaAdd)
{
    if(!chinaTotal.isEmpty() && !chinaAdd.isEmpty())
    {
        int chinaTotal_confirm, chinaTotal_suspect, chinaTotal_dead, chinaTotal_heal;
        int chinaAdd_confirm, chinaAdd_suspect, chinaAdd_dead, chinaAdd_heal;

        getNum(chinaAdd, &chinaAdd_confirm, &chinaAdd_suspect, &chinaAdd_dead, &chinaAdd_heal);
        getNum(chinaTotal, &chinaTotal_confirm, &chinaTotal_suspect, &chinaTotal_dead, &chinaTotal_heal);
        //��ʾ�ۼ�����
        ui->lbe_total_confirm->setText(QString::number(chinaTotal_confirm));
        ui->lbe_total_suspect->setText(QString::number(chinaTotal_suspect));
        ui->lbe_total_dead->setText(QString::number(chinaTotal_dead));
        ui->lbe_total_heal->setText(QString::number(chinaTotal_heal));

        int total_nowConfirm = chinaTotal.value("nowConfirm").toDouble();     //����ȷ��
        int total_nowSevere = chinaTotal.value("nowSevere").toDouble();       //������֢

        ui->lbe_total_nowConfirm->setText(QString::number(total_nowConfirm));
        ui->lbe_total_nowSevere->setText(QString::number(total_nowSevere));

        //��ʾ����
        int chinaAdd_nowConfirm = chinaAdd.value("nowConfirm").toDouble();
        int chinaAdd_nowServere = chinaAdd.value("nowSevere").toDouble();

        showAddData("confirm", chinaAdd_confirm, ui->lbe_add_confirm);
//        showAddData("suspect", chinaAdd_suspect, ui->lbe_add_suspect);
        showAddData("dead", chinaAdd_dead, ui->lbe_add_dead);
        showAddData("heal", chinaAdd_heal, ui->lbe_add_heal);
        showAddData("nowConfirm", chinaAdd_nowConfirm, ui->lbe_add_nowConfirm);
        showAddData("nowServere", chinaAdd_nowServere, ui->lbe_add_nowSevere);

        QString tip = "�����չ�������ί�������������Ʋ�����" + QString::number(chinaAdd_suspect);

        ui->lbe_suspect->setToolTip(tip);

        return 0;
    }
    else
        return -1;
}

void Dialog::articleParse(QJsonArray arr)
{
    uint16_t arrSize = arr.size();
//    qDebug() << "�� " << arrSize << " ������";
//    qDebug() << QCoreApplication::applicationDirPath();
//    qDebug() << QCoreApplication::applicationFilePath();
//    qDebug() << QCoreApplication::applicationName();

//    QString tmp = newsHtmlFileName;
    QString tmp = QCoreApplication::applicationDirPath() + "/" + newsHtmlFileName;
    QFile file(tmp);

    if(!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "�ļ���ʧ��";
    }
//    qDebug() << "file open ok";
    QByteArray allData = file.readAll();
    file.close();
    QList<QByteArray> ba;

//    ba = allData.split("");
    ba = allData.split('*');
//    qDebug() << ba.size();
    QString html;
    for(int i = 0; i < arrSize; i++)
    {
        QJsonObject article_obj = arr.at(i).toObject();//ÿһƪ�ļ���Ϣ
//        QString cmsId = article_obj.value("cmsId").toString();
        QString media = article_obj.value("media").toString();
        QString publish_time = article_obj.value("publish_time").toString();
        QString desc = article_obj.value("desc").toString();
        QString url = article_obj.value("url").toString();
        QString title = article_obj.value("title").toString();
        QString str = ba[0] + title + ba[1] + desc + ba[2] + url + ba[3] + media + ba[4] + publish_time + ba[5];
        html.append(str);
//        if(i == 0)
//        qDebug() << html;

//        qDebug() << publish_time << media << title << url;
    }
    html.append(ba[6]);
//    qDebug() << html;
    ui->tb_news->clear();
    ui->tb_news->setHtml(html);
//    qDebug() << "set Html ok";
}
//��ȡ����
int Dialog::getNum(QJsonObject obj, int *num_confirm, int *num_suspect, int *num_dead, int *num_heal)
{
    if(!obj.isEmpty())
    {
        *num_confirm = obj.value("confirm").toDouble();
        *num_suspect = obj.value("suspect").toDouble();
        *num_dead = obj.value("dead").toDouble();
        *num_heal = obj.value("heal").toDouble();

        return 0;
    }
    else
        return -1;
}
//������ת��:QStringת��Ϊdouble
QVector<double> Dialog::QStringToDouble(QVector<QString> str, uint16_t len)
{
    QVector<double> dub(len);

    for(int i = 0; i < str.size(); i++)
    {
        dub[i] = str[i].toDouble();
    }
    return dub;
}

//��ʾ��������
void Dialog::showAddData(QString key, int num, QLabel *lbe)
{
    QString str_num;
    if(num > 0)
        str_num = "+" + QString::number(num);
    else
        str_num = QString::number(num);

    bool sw = AddSwitchMap.value(key);

    QString str = (sw) ? str_num : "������";

    lbe->setText(str);
}

void Dialog::parseAddSwitch(QJsonObject sw_obj)
{
    bool sw_all        = sw_obj.value("all").toBool();
    bool sw_confirm    = sw_obj.value("confirm").toBool();
    bool sw_suspect    = sw_obj.value("suspect").toBool();
    bool sw_dead       = sw_obj.value("dead").toBool();
    bool sw_heal       = sw_obj.value("heal").toBool();
    bool sw_nowConfirm = sw_obj.value("nowConfirm").toBool();
    bool sw_nowSevere  = sw_obj.value("nowSevere").toBool();

    AddSwitchMap.clear();
    AddSwitchMap.insert("all", sw_all);
    AddSwitchMap.insert("confirm", sw_confirm);
    AddSwitchMap.insert("suspect", sw_suspect);
    AddSwitchMap.insert("dead", sw_dead);
    AddSwitchMap.insert("heal", sw_heal);
    AddSwitchMap.insert("nowConfirm", sw_nowConfirm);
    AddSwitchMap.insert("nowServere", sw_nowSevere);

//    AddSwitchMap["all"] = false;        //���ڸ�ֵ
//    if(AddSwitchMap.contains("all"));    //���ڲ�ѯ���Ƿ����
//        bool val = AddSwitchMap.value("all");                //���ڻ�ȡֵ

}
