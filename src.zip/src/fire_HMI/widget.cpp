#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    initParameter();
    setFilePath();
    initMainWindows();
    initDiaplayLabel();
    initStackedWidget();
    initSqlLink();
    initConnectUdpsocket();
    initSecurityUdpsocket();

    //���main�߳�
    QString LogInfo;
    LogInfo.sprintf("%p", QThread::currentThread());
    writeLog("MainthreadID --- "+LogInfo);

    //log
    connect(&RefreshThread,SIGNAL(cThreadWriteLog(QString)),this,SLOT(writeLog(QString)));

    //ˢ�½����߳�
    RefreshThread.Owner     = this;
    RefreshThread.OwnerType = C_THREAD::RefreshSocket;
    RefreshThread.start();//��ʼ�����߳�

    //�������߳�
    MonitorErrorThread.Owner = this;
    MonitorErrorThread.OwnerType = C_THREAD::MonitorSocket;

    //main UI show
    mainNavigationMainInterfaceButtonClicked();
}

Widget::~Widget()
{
    delete ui;
}

//init Parameter
void Widget::initParameter()
{

    //lable time
    dateYear                        =       "";
    dateMonthDay                    =       "";
    timeHoursMinite                 =       "";
    timeSecond                      =       "";

    //temperature
    temperature                     =       "";
    temperatureUnit                 =       "";

    //car
    carName                         =       "";
    carNumber                       =       "";
    carSpeed                        =       "";
    carSpeedUnit                    =       "";

    //log file
    pathLogFile                     =       "";

    //config file
    pathSysConfig                   =       "";
    pathConfig                      =       "";

    //mainpage
    mainTableHeader.clear();
    mainPageButtonStyle             =       "";

    //alarmRecordPage
    alarmRecordTableHeader.clear();
    alarmRecordPageButtonStyle      =       "";

    //rotateAllPage
    rotateAllTableHeader.clear();
    rotateAllTableColunm.clear();
    currentRotateCoache             =       0;
    rotateAllButtonStyle            =       "";
    rotateAllButtonClickedStyle     =       "";
    rotateCoacheClickedStatue       =       false;

    //rotateSignlePage
    rotateSignleTableHeader.clear();
    rotateAlxeboxTableColunm.clear();
    rotateGearboxTableColunm.clear();
    rotateMotorTableColunm.clear();

    //navigation Button Style
    navigationButtonStyle           =       "";
    navigationButtonClickedStyle    =       "";

    //udpSocket
    udpSocket                       =       new UdpSocket(this);

    //sqlLink
    sqlLink                         =       new C_Sqlite(this);

    //FireWork
    currentFireWorkCoache           =       0;
    fireWorkCoacheClickedStatue     =       false;
    fireWorkTableHeader.clear();
    fireWorkCoache1.clear();
    fireWorkCoache2.clear();
    fireWorkCoache3.clear();
    fireWorkCoache4.clear();
    fireWorkCoache5.clear();
    fireWorkCoache6.clear();
    fireWorkCoache7.clear();
    fireWorkCoache8.clear();

    //balanceInstability
    balanceInstabilityTableHeader.clear();
    balanceInstabilityColumn.clear();

    //fireLinkage
    fireLinkageTableHeader.clear();
    fireLinkageColumn.clear();

    //temperature
    temperatureAlxeboxTableHeader.clear();
    temperatureGearboxTableHeader.clear();
    temperatureMotorTableHeader.clear();
    temperatureMotorAndDiningTableHeader.clear();
    temperatureAlxeboxTableColunm.clear();
    temperatureGearboxTableColunm.clear();
    temperatureMotorTableColunm.clear();
    temperatureMotorAndDiningTableColunm.clear();

    //sysSettingStyle
    sysSettingStyle                 =           "";
    brightValue                     =           0;

    //Have data
    bHavedata                       = false;
    iCount                          =   0;

    //current Page Count
    currentPageCount                =   1;
    recordCurrentPageCount          =   1;
}
//initSecurityUdpsocket
void Widget::initSecurityUdpsocket()
{
    udpSocket->initCoacheInformation(5000);
    udpSocket->initUdpsocket(HOSTIP);
}
//initConnectUdpsocket
void Widget::initConnectUdpsocket()
{
    connect(udpSocket,SIGNAL(udpWriteLog(QString)),this,SLOT(writeLog(QString)));

    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache1Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache2Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache3Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache4Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache5Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache6Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache7Sheet(int)));
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayRotateAllCoache8Sheet(int)));

    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayBalanceSheet(int)));

    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayFireLinkageSheet(int)));

    //systemTiming
    connect(udpSocket,SIGNAL(systemTiming(int,int,int,int,int,int)),this,SLOT(systemTimingSlot(int,int,int,int,int,int)));

    //insert sqllite
    connect(udpSocket,SIGNAL(ErrorMessage(int,int,int,int,QString,QString)),this,SLOT(insetSqlData(int,int,int,int,QString,QString)));

    //clean CoacheNum DataSlot
    connect(udpSocket,SIGNAL(cleanCoacheNumData(int)),this,SLOT(cleanCoacheNumDataSlot(int)));

    //true message
    connect(udpSocket,SIGNAL(TrueMessage(int,int,int,int)),this,SLOT(resetTrueMessage(int,int,int,int)));

    //initOffLineSignal
    connect(this,SIGNAL(initOffLineSignal()),udpSocket,SLOT(reveiceInitOffLineSignal()));
}
//init SqlLink
void Widget::initSqlLink()
{
    connect(sqlLink,SIGNAL(cSqliteWriteLog(QString)),this,SLOT(writeLog(QString)));
    connect(sqlLink,SIGNAL(updateFaultHistory(int,int,int,int,QString)),this,SLOT(updateFaultHistorySlot(int,int,int,int,QString)));
    connect(sqlLink,SIGNAL(updateFault(int,int,int,int,QString)),this,SLOT(updateFaultSlot(int,int,int,int,QString)));
    sqlLink->OpenSQL();
    sqlLink->Reset_GZAll();
    sqlLink->Clean_Check();
}
//inset SqlData
void Widget::insetSqlData(int iError,int Sersor,int Device,int NumCar,QString Time,QString Message)
{
//    ()<<"--------insetSqlData--------";
    /***************���ݿ����******************/
    /******�ṹ�帳ֵ******/
    M_SQLLinkData sqldata;
    sqldata.ErrorType   = iError;//�𾯱������
    sqldata.SensorType  = Sersor;//̽������
    sqldata.deviceType  = Device;//�豸��
    sqldata.CarNo       = NumCar;//����
    sqldata.StarTime    = Time;//��ʼʱ��
    sqldata.Message     = Message;//��Ϣ
    sqldata.Reset       = false;//�Ƿ�λ
    sqldata.EndTime     = "";//����ʱ��

    /****�Ƿ��ظ�����������*****/
    //�ж��Ƿ��Ѿ�������ͬ�ı������߹�����Ϣ����
    if(sqlLink->DoHaveBJ_Again(NumCar,Device,Sersor,iError)){
        return;
    }
    /******�����¹��ϡ�����****/
    if(sqlLink->insert_Error(sqldata)){
    }
    /***************���ݿ����******************/
}
//�Զ���λ
void Widget::resetTrueMessage(int iError, int Sersor, int device, int NumCar)
{
    //�ж��Ƿ��иù��ϴ���
    if(!sqlLink->DoHaveBJ_Again(NumCar,device,Sersor,iError))
        return;
    //�����Զ���λ
    if(sqlLink->Auto_Reset_Data(NumCar,device,Sersor,iError)){

    }
}
//updateFaultHistorySlot
void Widget::updateFaultHistorySlot(int CarNun, int DeviceNum, int SersorNum, int ErrorNum, QString endTime)
{
    QString IDNum   =   "";
    int     i_IDNum =   0;
    R_SQLData Rdata;

    Rdata = sqlLink->updateHistoryTable(CarNun,DeviceNum,SersorNum,ErrorNum,endTime);

    if(alarmRecordTable->item(0,0) == nullptr){
        i_IDNum =   1;
    }else{
        IDNum   =   alarmRecordTable->item(0,0)->text();

        i_IDNum =   IDNum.toInt()+1;
    }

    recordPageSumItem->setText("��������"+QString::number(i_IDNum,10));

    alarmRecordTable->insertRow(0);
    alarmRecordTable->setItem(0,0,new QTableWidgetItem(QString::number(i_IDNum,10)));
    alarmRecordTable->setItem(0,1,new QTableWidgetItem("400"));
    alarmRecordTable->setItem(0,2,new QTableWidgetItem(QString::number(Rdata.CarNo,10)));
    alarmRecordTable->setItem(0,3,new QTableWidgetItem(Rdata.deviceType+" "+Rdata.SensorType+" "+Rdata.ErrorType));
    alarmRecordTable->setItem(0,4,new QTableWidgetItem(QString::number(Rdata.i_ErrorNo,10)));
    alarmRecordTable->setItem(0,5,new QTableWidgetItem(Rdata.StarTime));
    alarmRecordTable->setItem(0,6,new QTableWidgetItem(Rdata.EndTime));
    alarmRecordTable->item(0,0)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,0)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,0)->setFlags(Qt::NoItemFlags);
    alarmRecordTable->item(0,1)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,1)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,1)->setFlags(Qt::NoItemFlags);
    alarmRecordTable->item(0,2)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,2)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,2)->setFlags(Qt::NoItemFlags);
    alarmRecordTable->item(0,3)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,3)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,3)->setFlags(Qt::NoItemFlags);
    alarmRecordTable->item(0,4)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,4)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,4)->setFlags(Qt::NoItemFlags);
    alarmRecordTable->item(0,5)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,5)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,5)->setFlags(Qt::NoItemFlags);
    alarmRecordTable->item(0,6)->setBackgroundColor(QColor(255,170,0));
    alarmRecordTable->item(0,6)->setTextAlignment(Qt::AlignCenter);
    alarmRecordTable->item(0,6)->setFlags(Qt::NoItemFlags);

     writeLog(QString("Resetting Warn : ") + "��ǰ����: #����"+ QString::number(Rdata.CarNo,10) +" "+Rdata.deviceType+" "+Rdata.SensorType+" "+Rdata.ErrorType);

    QString sumpage = getRecordSumPage();
    recordPageSumPage->setText("�� "+sumpage+" ҳ");

    mainUIMutex.lock();
    for(int i = 0;i<mainTable->rowCount();i++){
        if((mainTable->item(i,2)->text() == QString::number(Rdata.CarNo,10)) &&
                (mainTable->item(i,3)->text() == Rdata.deviceType+" "+Rdata.SensorType+" "+Rdata.ErrorType) &&
                (mainTable->item(i,4)->text() == QString::number(Rdata.i_ErrorNo,10)) &&
                (mainTable->item(i,5)->text() == Rdata.StarTime)){

            mainTable->removeRow(i);

        }
    }

    int rowCount = mainTable->rowCount();
    for(int i = 0;i<mainTable->rowCount();i++){
        mainTable->setItem(i,0,new QTableWidgetItem(QString::number(rowCount,10)));
        mainTable->item(i,0)->setBackgroundColor(QColor(255,170,0));
        mainTable->item(i,0)->setTextAlignment(Qt::AlignCenter);
        mainTable->item(i,0)->setFlags(Qt::NoItemFlags);
        rowCount--;
    }

    if(mainTable->item(0,0) != nullptr){
        labelCurrentAlarm->setText("��ǰ���� #����:"+ mainTable->item(0,2)->text() + " " + mainTable->item(0,3)->text());
    }else{
        labelCurrentAlarm->setText("��ǰ����:");
    }

    mainPageSumItem->setText("��������"+QString::number(mainTable->rowCount(),10));

    QString sumMainPage = getSumPage();
    mainPageSumPage->setText("�� "+sumMainPage+" ҳ");

    if(mainTable->item(0,0) != nullptr){
        warnButton->show();
    }else{
        warnButton->hide();
    }

    mainUIMutex.unlock();
}
//update Fault Slot
void Widget::updateFaultSlot(int CarNun, int DeviceNum, int SersorNum, int ErrorNum, QString startTime)
{

    QString IDNum   =   "";
    int     i_IDNum =   0;
    R_SQLData Rdata;

    Rdata = sqlLink->updateFaultTable(CarNun,DeviceNum,SersorNum,ErrorNum,startTime);

    mainUIMutex.lock();

    if(mainTable->item(0,0) == nullptr){
        i_IDNum =   1;
    }else{
        IDNum   =   mainTable->item(0,0)->text();

        i_IDNum =   IDNum.toInt()+1;
    }

    mainPageSumItem->setText("��������"+QString::number(i_IDNum,10));

    mainTable->insertRow(0);
    mainTable->setItem(0,0,new QTableWidgetItem(QString::number(i_IDNum,10)));
    mainTable->setItem(0,1,new QTableWidgetItem("400"));
    mainTable->setItem(0,2,new QTableWidgetItem(QString::number(Rdata.CarNo,10)));
    mainTable->setItem(0,3,new QTableWidgetItem(Rdata.deviceType+" "+Rdata.SensorType+" "+Rdata.ErrorType));
    mainTable->setItem(0,4,new QTableWidgetItem(QString::number(Rdata.i_ErrorNo,10)));
    mainTable->setItem(0,5,new QTableWidgetItem(Rdata.StarTime));
    mainTable->setItem(0,6,new QTableWidgetItem(Rdata.EndTime));
    mainTable->item(0,0)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,0)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,0)->setFlags(Qt::NoItemFlags);
    mainTable->item(0,1)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,1)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,1)->setFlags(Qt::NoItemFlags);
    mainTable->item(0,2)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,2)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,2)->setFlags(Qt::NoItemFlags);
    mainTable->item(0,3)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,3)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,3)->setFlags(Qt::NoItemFlags);
    mainTable->item(0,4)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,4)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,4)->setFlags(Qt::NoItemFlags);
    mainTable->item(0,5)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,5)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,5)->setFlags(Qt::NoItemFlags);
    mainTable->item(0,6)->setBackgroundColor(QColor(255,170,0));
    mainTable->item(0,6)->setTextAlignment(Qt::AlignCenter);
    mainTable->item(0,6)->setFlags(Qt::NoItemFlags);

    labelCurrentAlarm->setText("��ǰ����: #����"+ QString::number(Rdata.CarNo,10) +" "+Rdata.deviceType+" "+Rdata.SensorType+" "+Rdata.ErrorType);

    writeLog(QString("Occurring Warn : ") + "��ǰ����: #����"+ QString::number(Rdata.CarNo,10) +" "+Rdata.deviceType+" "+Rdata.SensorType+" "+Rdata.ErrorType);

    QString sumpage = getSumPage();
    mainPageSumPage->setText("�� "+sumpage+" ҳ");

    if(mainTable->item(0,0) != nullptr){
        warnButton->show();
    }else{
        warnButton->hide();
    }
    mainUIMutex.unlock();
}
//refresh Time
void Widget::refreshTimeout()
{
    QString LogInfo;
    LogInfo.sprintf("%p", QThread::currentThread());
    writeLog("RefreshTimethreadID --- "+LogInfo);

#ifdef Debug
            qDebug()<<"RefreshTimethreadID --- "+LogInfo;
#endif

    mainPageDisplayFaultAndAlarm(FaultHistory);

}
//set mainwindows
void Widget::initMainWindows()
{
    this->setMinimumSize(1024, 768);
    this->setMaximumSize(1024, 768);
    this->setWindowFlags(Qt::FramelessWindowHint);
}
//set label
void Widget::initDiaplayLabel()
{
    //time
    curTime         =   QDateTime::currentDateTime();
    dateYear        =   curTime.toString("yyyy��");
    dateMonthDay    =   curTime.toString("MM��dd��");
    timeHoursMinite =   curTime.toString("hh:mm");
    timeSecond      =   curTime.toString("ss");
    //QFont
    ft.setPointSize(25);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,Qt::white);

    labelDateYear = new QLabel(this);
    labelDateYear->setGeometry(250,15,260,40);
    labelDateYear->setText(dateYear);
    labelDateYear->setFont(ft);
    labelDateYear->setPalette(pa);

    labelDateMonthDay = new QLabel(this);
    labelDateMonthDay->setGeometry(360,15,260,40);
    labelDateMonthDay->setText(dateMonthDay);
    labelDateMonthDay->setFont(ft);
    labelDateMonthDay->setPalette(pa);

    ft.setPointSize(25);
    ft.setFamily("����");
    labelHoursMiniter = new QLabel(this);
    labelHoursMiniter->setGeometry(20,15,90,40);
    labelHoursMiniter->setText(timeHoursMinite);
    labelHoursMiniter->setFont(ft);
    labelHoursMiniter->setPalette(pa);

    ft.setPointSize(18);
    ft.setFamily("����");
    labelSecond = new QLabel(this);
    labelSecond->setGeometry(130,25,70,30);
    labelSecond->setText(timeSecond);
    labelSecond->setFont(ft);
    labelSecond->setPalette(pa);
    doTime1();

    //temperature
//    ft.setPointSize(40);
//    ft.setFamily("����");
//    labelTemperature = new QLabel(this);
//    labelTemperature->setGeometry(310,10,60,50);
//    labelTemperature->setText(temperature);
//    labelTemperature->setFont(ft);
//    labelTemperature->setPalette(pa);

//    ft.setPointSize(13);
//    labelTemperatureUnit = new QLabel(this);
//    labelTemperatureUnit->setGeometry(370,30,70,20);
//    labelTemperatureUnit->setText(temperatureUnit);
//    labelTemperatureUnit->setFont(ft);
//    labelTemperatureUnit->setPalette(pa);

    //car
    ft.setPointSize(25);
    ft.setFamily("����");
    labelCarName = new QLabel(this);
    labelCarName->setGeometry(600,15,260,40);
    labelCarName->setText(carName);
    labelCarName->setFont(ft);
    labelCarName->setPalette(pa);

//    ft.setPointSize(30);
//    ft.setFamily("����");
//    labelCarNumber = new QLabel(this);
//    labelCarNumber->setGeometry(720,10,150,50);
//    labelCarNumber->setText(carNumber);
//    labelCarNumber->setFont(ft);
//    labelCarNumber->setPalette(pa);

//    ft.setPointSize(30);
//    ft.setFamily("����");
//    labelSpeed = new QLabel(this);
//    labelSpeed->setGeometry(890,10,60,50);
//    labelSpeed->setText(carSpeed);
//    labelSpeed->setFont(ft);
//    labelSpeed->setPalette(pa);

//    ft.setPointSize(13);
//    ft.setFamily("����");
//    labelSpeedUnit = new QLabel(this);
//    labelSpeedUnit->setGeometry(960,30,120,20);
//    labelSpeedUnit->setText(carSpeedUnit);
//    labelSpeedUnit->setFont(ft);
//    labelSpeedUnit->setPalette(pa);

    warnButton  = new QPushButton(this);
    warnButton->setGeometry(950,5,60,60);
    warnButton->setStyleSheet("QPushButton{border-image: url(:/image/debug/1.jpg);}");
    warnButton->hide();
    connect(warnButton,SIGNAL(clicked()),this,SLOT(mainNavigationMainInterfaceButtonClicked()));
}
//init Stacked
void Widget::initStackedWidget()
{
    //stackedWidget of sheet
    stackedWidget = new QStackedWidget(this);
    stackedWidget->setGeometry(25,75,975,580);
    initWidget();
    stackedWidget->addWidget(mainPage);
    stackedWidget->addWidget(rotateAllPage);
    stackedWidget->addWidget(rotateSinglePage);
    stackedWidget->addWidget(fireWorkPage);
    stackedWidget->addWidget(balanceInstabilityPage);
    stackedWidget->addWidget(fireLinkagePage);
    stackedWidget->addWidget(temperaturePage);
    stackedWidget->addWidget(alarmRecordPage);
    stackedWidget->addWidget(sysSettingPage);
    stackedWidget->hide();

    //stackedWidget of navigation
    stackedWidgetNavigation = new QStackedWidget(this);
    stackedWidgetNavigation->setGeometry(25,665,975,90);
    initWidgetNacigation();
    stackedWidgetNavigation->addWidget(mainNavigationPage);
    stackedWidgetNavigation->addWidget(rotateNavigationPage);
    stackedWidgetNavigation->addWidget(fireworkNavigationPage);
    stackedWidgetNavigation->addWidget(temperatureNavigationPage);
    stackedWidgetNavigation->setCurrentIndex(0);
}
//init Widget Nacigation
void Widget::initWidgetNacigation()
{
    //mainNavigation Page
    mainNavigationPage = new QWidget;
    mainNavigationPage->setGeometry(0,0,975,90);

    navigationButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 14pt ;font-family: ����;}";
    navigationButtonClickedStyle = "QPushButton{border:3px solid green;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 14pt ;font-family: ����;}";
    mainNavigationMainInterfaceButton = new QPushButton(mainNavigationPage);
    mainNavigationMainInterfaceButton->setGeometry(30,5,80,80);
    mainNavigationMainInterfaceButton->setStyleSheet(navigationButtonStyle);
    mainNavigationMainInterfaceButton->setText("������");
    mainNavigationMainInterfaceButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationMainInterfaceButton,SIGNAL(clicked()),this,SLOT(mainNavigationMainInterfaceButtonClicked()));

    mainNavigationRotateButton = new QPushButton(mainNavigationPage);
    mainNavigationRotateButton->setGeometry(210,5,80,80);
    mainNavigationRotateButton->setStyleSheet(navigationButtonStyle);
    mainNavigationRotateButton->setText("��ת\r\n����");
    mainNavigationRotateButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationRotateButton,SIGNAL(clicked()),this,SLOT(mainNavigationRotateButtonClicked()));

    mainNavigationFireworksButton = new QPushButton(mainNavigationPage);
    mainNavigationFireworksButton->setGeometry(300,5,160,80);
    mainNavigationFireworksButton->setStyleSheet(navigationButtonStyle);
    mainNavigationFireworksButton->setText("�̻�̽\r\nͷ���");
    mainNavigationFireworksButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationFireworksButton,SIGNAL(clicked()),this,SLOT(mainNavigationFireworksButtonClicked()));

    mainNavigationBalanceButton = new QPushButton(mainNavigationPage);
    mainNavigationBalanceButton->setGeometry(470,5,80,80);
    mainNavigationBalanceButton->setStyleSheet(navigationButtonStyle);
    mainNavigationBalanceButton->setText("ʧ��\r\nƽ��");
    mainNavigationBalanceButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationBalanceButton,SIGNAL(clicked()),this,SLOT(mainNavigationBalanceButtonClicked()));

    mainNavigationFireLinkageButton = new QPushButton(mainNavigationPage);
    mainNavigationFireLinkageButton->setGeometry(560,5,80,80);
    mainNavigationFireLinkageButton->setStyleSheet(navigationButtonStyle);
    mainNavigationFireLinkageButton->setText("����\r\n����");
    mainNavigationFireLinkageButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationFireLinkageButton,SIGNAL(clicked()),this,SLOT(mainNavigationFireLinkageButtonClicked()));

    mainNavigationTemperatureButton = new QPushButton(mainNavigationPage);
    mainNavigationTemperatureButton->setGeometry(690,5,80,80);
    mainNavigationTemperatureButton->setStyleSheet(navigationButtonStyle);
    mainNavigationTemperatureButton->setText("�¶�\r\n���");
    mainNavigationTemperatureButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationTemperatureButton,SIGNAL(clicked()),this,SLOT(mainNavigationTemperatureButtonClicked()));

    mainNavigationAlarmRecordButton = new QPushButton(mainNavigationPage);
    mainNavigationAlarmRecordButton->setGeometry(780,5,80,80);
    mainNavigationAlarmRecordButton->setStyleSheet(navigationButtonStyle);
    mainNavigationAlarmRecordButton->setText("����\r\n��¼");
    mainNavigationAlarmRecordButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationAlarmRecordButton,SIGNAL(clicked()),this,SLOT(mainNavigationAlarmRecordButtonClicked()));

    mainNavigationSystemSetButton = new QPushButton(mainNavigationPage);
    mainNavigationSystemSetButton->setGeometry(870,5,80,80);
    mainNavigationSystemSetButton->setStyleSheet(navigationButtonStyle);
    mainNavigationSystemSetButton->setText("ϵͳ\r\n����");
    mainNavigationSystemSetButton->setFocusPolicy(Qt::NoFocus);
    connect(mainNavigationSystemSetButton,SIGNAL(clicked()),this,SLOT(mainNavigationSystemSetButtonClicked()));

    //rotateNavigation Page
    rotateNavigationPage = new QWidget;
    rotateNavigationPage->setGeometry(0,0,975,90);

    rotateNavigationAllCoacheButton = new QPushButton(rotateNavigationPage);
    rotateNavigationAllCoacheButton->setGeometry(30,5,80,80);
    rotateNavigationAllCoacheButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationAllCoacheButton->setText("ȫ��");
    rotateNavigationAllCoacheButton->setFocusPolicy(Qt::NoFocus);
    connect(rotateNavigationAllCoacheButton,SIGNAL(clicked()),this,SLOT(rotateNavigationAllCoacheButtonClicked()));

    rotateNavigationAlxeboxButton = new QPushButton(rotateNavigationPage);
    rotateNavigationAlxeboxButton->setGeometry(120,5,80,80);
    rotateNavigationAlxeboxButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationAlxeboxButton->setText("����");
    rotateNavigationAlxeboxButton->setFocusPolicy(Qt::NoFocus);
    connect(rotateNavigationAlxeboxButton,SIGNAL(clicked()),this,SLOT(rotateNavigationAlxeboxButtonClicked()));

    rotateNavigationGearboxButton = new QPushButton(rotateNavigationPage);
    rotateNavigationGearboxButton->setGeometry(210,5,80,80);
    rotateNavigationGearboxButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationGearboxButton->setText("������");
    rotateNavigationGearboxButton->setFocusPolicy(Qt::NoFocus);
    connect(rotateNavigationGearboxButton,SIGNAL(clicked()),this,SLOT(rotateNavigationGearboxButtonClicked()));

    rotateNavigationMotorButton = new QPushButton(rotateNavigationPage);
    rotateNavigationMotorButton->setGeometry(300,5,80,80);
    rotateNavigationMotorButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationMotorButton->setText("���");
    rotateNavigationMotorButton->setFocusPolicy(Qt::NoFocus);
    connect(rotateNavigationMotorButton,SIGNAL(clicked()),this,SLOT(rotateNavigationMotorButtonClicked()));

    rotateNavigationReturnButton = new QPushButton(rotateNavigationPage);
    rotateNavigationReturnButton->setGeometry(800,5,130,80);
    rotateNavigationReturnButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationReturnButton->setText("<-\r\n����");
    rotateNavigationReturnButton->setFocusPolicy(Qt::NoFocus);
    connect(rotateNavigationReturnButton,SIGNAL(clicked()),this,SLOT(rotateNavigationReturnButtonClicked()));

    //fireworkNavigation Page
    fireworkNavigationPage  =   new QWidget;
    fireworkNavigationPage->setGeometry(0,0,975,90);

    fireWorkCoacheSelectQLabel = new QLabel(fireworkNavigationPage);
    fireWorkCoacheSelectQLabel->setGeometry(30,5,70,80);
    fireWorkCoacheSelectQLabel->setText("����\r\nѡ��");
    fireWorkCoacheSelectQLabel->setAutoFillBackground(true);
    fireWorkCoacheSelectQLabel->setStyleSheet("QLabel{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 14pt ;font-family: ����;}");

    fireWorkButton1 = new QPushButton(fireworkNavigationPage);
    fireWorkButton1->setGeometry(100,5,40,80);
    fireWorkButton1->setStyleSheet(navigationButtonStyle);
    fireWorkButton1->setText("01");
    fireWorkButton1->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton1,SIGNAL(clicked()),this,SLOT(fireWorkCoache1PushButtonClicked()));

    fireWorkButton2 = new QPushButton(fireworkNavigationPage);
    fireWorkButton2->setGeometry(140,5,40,80);
    fireWorkButton2->setStyleSheet(navigationButtonStyle);
    fireWorkButton2->setText("02");
    fireWorkButton2->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton2,SIGNAL(clicked()),this,SLOT(fireWorkCoache2PushButtonClicked()));

    fireWorkButton3 = new QPushButton(fireworkNavigationPage);
    fireWorkButton3->setGeometry(180,5,40,80);
    fireWorkButton3->setStyleSheet(navigationButtonStyle);
    fireWorkButton3->setText("03");
    fireWorkButton3->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton3,SIGNAL(clicked()),this,SLOT(fireWorkCoache3PushButtonClicked()));

    fireWorkButton4 = new QPushButton(fireworkNavigationPage);
    fireWorkButton4->setGeometry(220,5,40,80);
    fireWorkButton4->setStyleSheet(navigationButtonStyle);
    fireWorkButton4->setText("04");
    fireWorkButton4->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton4,SIGNAL(clicked()),this,SLOT(fireWorkCoache4PushButtonClicked()));

    fireWorkButton5 = new QPushButton(fireworkNavigationPage);
    fireWorkButton5->setGeometry(260,5,40,80);
    fireWorkButton5->setStyleSheet(navigationButtonStyle);
    fireWorkButton5->setText("05");
    fireWorkButton5->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton5,SIGNAL(clicked()),this,SLOT(fireWorkCoache5PushButtonClicked()));

    fireWorkButton6 = new QPushButton(fireworkNavigationPage);
    fireWorkButton6->setGeometry(300,5,40,80);
    fireWorkButton6->setStyleSheet(navigationButtonStyle);
    fireWorkButton6->setText("06");
    fireWorkButton6->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton6,SIGNAL(clicked()),this,SLOT(fireWorkCoache6PushButtonClicked()));

    fireWorkButton7 = new QPushButton(fireworkNavigationPage);
    fireWorkButton7->setGeometry(340,5,40,80);
    fireWorkButton7->setStyleSheet(navigationButtonStyle);
    fireWorkButton7->setText("07");
    fireWorkButton7->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton7,SIGNAL(clicked()),this,SLOT(fireWorkCoache7PushButtonClicked()));

    fireWorkButton8 = new QPushButton(fireworkNavigationPage);
    fireWorkButton8->setGeometry(380,5,40,80);
    fireWorkButton8->setStyleSheet(navigationButtonStyle);
    fireWorkButton8->setText("08");
    fireWorkButton8->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkButton8,SIGNAL(clicked()),this,SLOT(fireWorkCoache8PushButtonClicked()));

    fireWorkCurrentCoache = new QLabel(fireworkNavigationPage);
    fireWorkCurrentCoache->setGeometry(510,5,70,80);
    fireWorkCurrentCoache->setText("��ǰ\r\n����");
    fireWorkCurrentCoache->setAutoFillBackground(true);
    fireWorkCurrentCoache->setStyleSheet("QLabel{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 14pt ;font-family: ����;}");

    fireWorkCurrentCoacheNum = new QLabel(fireworkNavigationPage);
    fireWorkCurrentCoacheNum->setGeometry(580,5,70,80);
    fireWorkCurrentCoacheNum->setText("00");
    fireWorkCurrentCoacheNum->setAutoFillBackground(true);
    fireWorkCurrentCoacheNum->setStyleSheet("QLabel{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 14pt ;font-family: ����;}");

    fireWorkReturn  =   new QPushButton(fireworkNavigationPage);
    fireWorkReturn->setGeometry(800,5,130,80);
    fireWorkReturn->setStyleSheet(navigationButtonStyle);
    fireWorkReturn->setText("<-\r\n����");
    fireWorkReturn->setFocusPolicy(Qt::NoFocus);
    connect(fireWorkReturn,SIGNAL(clicked()),this,SLOT(fireWorkReturnPushButtonClicked()));

    //temperature Navigation Page
    temperatureNavigationPage = new QWidget;
    temperatureNavigationPage->setGeometry(0,0,975,90);

    temperatureNavigationAlxeboxButton = new QPushButton(temperatureNavigationPage);
    temperatureNavigationAlxeboxButton->setGeometry(30,5,80,80);
    temperatureNavigationAlxeboxButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationAlxeboxButton->setText("����");
    temperatureNavigationAlxeboxButton->setFocusPolicy(Qt::NoFocus);
    connect(temperatureNavigationAlxeboxButton,SIGNAL(clicked()),this,SLOT(temperatureNavigationAlxeboxButtonClicked()));

    temperatureNavigationGearboxButton = new QPushButton(temperatureNavigationPage);
    temperatureNavigationGearboxButton->setGeometry(120,5,80,80);
    temperatureNavigationGearboxButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationGearboxButton->setText("������");
    temperatureNavigationGearboxButton->setFocusPolicy(Qt::NoFocus);
    connect(temperatureNavigationGearboxButton,SIGNAL(clicked()),this,SLOT(temperatureNavigationGearboxButtonClicked()));

    temperatureNavigationMotorButton = new QPushButton(temperatureNavigationPage);
    temperatureNavigationMotorButton->setGeometry(210,5,80,80);
    temperatureNavigationMotorButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationMotorButton->setText("���");
    temperatureNavigationMotorButton->setFocusPolicy(Qt::NoFocus);
    connect(temperatureNavigationMotorButton,SIGNAL(clicked()),this,SLOT(temperatureNavigationMotorButtonClicked()));

    temperatureNavigationMotorAndDiningCoacheButton = new QPushButton(temperatureNavigationPage);
    temperatureNavigationMotorAndDiningCoacheButton->setGeometry(300,5,80,80);
    temperatureNavigationMotorAndDiningCoacheButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationMotorAndDiningCoacheButton->setText("����\r\n�ͳ�");
    temperatureNavigationMotorAndDiningCoacheButton->setFocusPolicy(Qt::NoFocus);
    connect(temperatureNavigationMotorAndDiningCoacheButton,SIGNAL(clicked()),this,SLOT(temperatureNavigationMotorAndDiningCoacheButtonClicked()));

    temperatureNavigationReturnButton = new QPushButton(temperatureNavigationPage);
    temperatureNavigationReturnButton->setGeometry(800,5,130,80);
    temperatureNavigationReturnButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationReturnButton->setText("<-\r\n����");
    temperatureNavigationReturnButton->setFocusPolicy(Qt::NoFocus);
    connect(temperatureNavigationReturnButton,SIGNAL(clicked()),this,SLOT(temperatureNavigationReturnButtonClicked()));
}
//init widget
void Widget::initWidget()
{
    //main page
    mainPage = new QWidget;
    mainPage->setGeometry(0,0,975,580);

    ft.setPointSize(14);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 0, 0));
    pa.setColor(QPalette::Background, QColor(255, 255, 0));
    labelCurrentAlarm = new QLabel(mainPage);
    labelCurrentAlarm->setGeometry(5,55,966,35);
    labelCurrentAlarm->setText("��ǰ����:");
    labelCurrentAlarm->setAutoFillBackground(true);
    labelCurrentAlarm->setFont(ft);
    labelCurrentAlarm->setPalette(pa);

    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    pa.setColor(QPalette::Background, QColor(0, 0, 0));
    mainPageSumItem = new QLabel(mainPage);
    mainPageSumItem->setGeometry(5,530,150,35);
    mainPageSumItem->setText("��������0");
    mainPageSumItem->setAutoFillBackground(true);
    mainPageSumItem->setFont(ft);
    mainPageSumItem->setPalette(pa);

    mainPageCurrentPage = new QLabel(mainPage);
    mainPageCurrentPage->setGeometry(185,530,150,35);
    mainPageCurrentPage->setText("��ǰ�� 1 ҳ");
    mainPageCurrentPage->setAutoFillBackground(true);
    mainPageCurrentPage->setFont(ft);
    mainPageCurrentPage->setPalette(pa);

    mainPageSumPage = new QLabel(mainPage);
    mainPageSumPage->setGeometry(365,530,150,35);
    mainPageSumPage->setText("�� 1 ҳ");
    mainPageSumPage->setAutoFillBackground(true);
    mainPageSumPage->setFont(ft);
    mainPageSumPage->setPalette(pa);

    mainTable = new QTableWidget(mainPage);
    mainTable->setGeometry(5,95,965,400);
    mainTable->setColumnCount(mainTableHeader.length());
    mainTable->setHorizontalHeaderLabels(mainTableHeader);
    mainTable->verticalHeader()->setVisible(false);
    mainTable->horizontalHeader()->setSectionsClickable(false);
    QString sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    mainTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    mainTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    mainTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    mainTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    mainTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    mainTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);
    mainTable->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents);
    mainTable->horizontalHeader()->setSectionResizeMode(6, QHeaderView::ResizeToContents);
    QString sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 0, 0);font-family: ����;";
    mainTable->setStyleSheet(sheetBackgroundColor);
    mainTable->setFrameShape(QFrame::NoFrame);
    mainTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    mainTable->setSelectionMode(QAbstractItemView::NoSelection);
    mainTable->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    mainTable->verticalHeader()->setDefaultSectionSize(45);
    mainTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�

    mainPageButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    mainPageUpPageButton = new QPushButton(mainPage);
    mainPageUpPageButton->setGeometry(580,525,100,50);
    mainPageUpPageButton->setStyleSheet(mainPageButtonStyle);
    mainPageUpPageButton->setText("��һҳ");
    mainPageUpPageButton->setFocusPolicy(Qt::NoFocus);
    connect(mainPageUpPageButton,SIGNAL(clicked()),this,SLOT(mainPageUpPageButtonClicked()));

    mainPageDownPageButton = new QPushButton(mainPage);
    mainPageDownPageButton->setGeometry(700,525,100,50);
    mainPageDownPageButton->setStyleSheet(mainPageButtonStyle);
    mainPageDownPageButton->setText("��һҳ");
    mainPageDownPageButton->setFocusPolicy(Qt::NoFocus);
    connect(mainPageDownPageButton,SIGNAL(clicked()),this,SLOT(mainPagedownPageButtonClicked()));

    //alarmRecordPage
    alarmRecordPage = new QWidget;
    alarmRecordPage->setGeometry(0,0,975,580);

    ft.setPointSize(24);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    alarmRecordPageHeader = new QLabel(alarmRecordPage);
    alarmRecordPageHeader->setGeometry(370,20,200,41);
    alarmRecordPageHeader->setText("������ʷ��¼");
    alarmRecordPageHeader->setFont(ft);
    alarmRecordPageHeader->setPalette(pa);

    ft.setPointSize(14);
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    pa.setColor(QPalette::Background, QColor(0, 0, 0));
    recordPageSumItem = new QLabel(alarmRecordPage);
    recordPageSumItem->setGeometry(5,530,150,35);
    recordPageSumItem->setText("��������0");
    recordPageSumItem->setAutoFillBackground(true);
    recordPageSumItem->setFont(ft);
    recordPageSumItem->setPalette(pa);

    recordPageCurrentPage = new QLabel(alarmRecordPage);
    recordPageCurrentPage->setGeometry(185,530,150,35);
    recordPageCurrentPage->setText("��ǰ�� 1 ҳ");
    recordPageCurrentPage->setAutoFillBackground(true);
    recordPageCurrentPage->setFont(ft);
    recordPageCurrentPage->setPalette(pa);

    recordPageSumPage = new QLabel(alarmRecordPage);
    recordPageSumPage->setGeometry(365,530,150,35);
    recordPageSumPage->setText("�� 1 ҳ");
    recordPageSumPage->setAutoFillBackground(true);
    recordPageSumPage->setFont(ft);
    recordPageSumPage->setPalette(pa);

    alarmRecordTable = new QTableWidget(alarmRecordPage);
    alarmRecordTable->setGeometry(0,65,975,450);
    alarmRecordTable->setColumnCount(alarmRecordTableHeader.length());
    alarmRecordTable->setHorizontalHeaderLabels(alarmRecordTableHeader);
    alarmRecordTable->verticalHeader()->setVisible(false);
    alarmRecordTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    alarmRecordTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);    
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents);
    alarmRecordTable->horizontalHeader()->setSectionResizeMode(6, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 0, 0);font-family: ����;";
    alarmRecordTable->setStyleSheet(sheetBackgroundColor);
    alarmRecordTable->setFrameShape(QFrame::NoFrame);
    alarmRecordTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    alarmRecordTable->setSelectionMode(QAbstractItemView::NoSelection);
    alarmRecordTable->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    alarmRecordTable->verticalHeader()->setDefaultSectionSize(45);
    alarmRecordTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�

    alarmRecordPageButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    alarmRecordUpPageButton = new QPushButton(alarmRecordPage);
    alarmRecordUpPageButton->setGeometry(580,520,100,50);
    alarmRecordUpPageButton->setStyleSheet(alarmRecordPageButtonStyle);
    alarmRecordUpPageButton->setText("��һҳ");
    alarmRecordUpPageButton->setFocusPolicy(Qt::NoFocus);
    connect(alarmRecordUpPageButton,SIGNAL(clicked()),this,SLOT(alarmRecordPageUpPageButtonClicked()));

    alarmRecordDownPageButton = new QPushButton(alarmRecordPage);
    alarmRecordDownPageButton->setGeometry(700,520,100,50);
    alarmRecordDownPageButton->setStyleSheet(alarmRecordPageButtonStyle);
    alarmRecordDownPageButton->setText("��һҳ");
    alarmRecordDownPageButton->setFocusPolicy(Qt::NoFocus);
    connect(alarmRecordDownPageButton,SIGNAL(clicked()),this,SLOT(alarmRecordPagedownPageButtonClicked()));

    //rotateAllPage
    rotateAllPage = new QWidget;
    rotateAllPage->setGeometry(0,0,975,580);

    ft.setPointSize(14);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    coacheSelectHeader = new QLabel(rotateAllPage);
    coacheSelectHeader->setGeometry(580,5,390,35);
    coacheSelectHeader->setText("����ѡ��");
    coacheSelectHeader->setFont(ft);
    coacheSelectHeader->setPalette(pa);

    rotateAllButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    rotateAllButtonClickedStyle = "QPushButton{ background-color: rgb(17, 48, 255);color: rgb(255, 255, 255);border:3px solid white;border-radius:5px;font: 75 18pt ;font-family: ����;}";
    rotateAllButton1 = new QPushButton(rotateAllPage);
    rotateAllButton1->setGeometry(580,50,91,121);
    rotateAllButton1->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton1->setText("01");
    rotateAllButton1->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton1,SIGNAL(clicked()),this,SLOT(rotateCoache1PushButtonClicked()));

    rotateAllButton2 = new QPushButton(rotateAllPage);
    rotateAllButton2->setGeometry(680,50,91,121);
    rotateAllButton2->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton2->setText("02");
    rotateAllButton2->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton2,SIGNAL(clicked()),this,SLOT(rotateCoache2PushButtonClicked()));

    rotateAllButton3 = new QPushButton(rotateAllPage);
    rotateAllButton3->setGeometry(780,50,91,121);
    rotateAllButton3->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton3->setText("03");
    rotateAllButton3->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton3,SIGNAL(clicked()),this,SLOT(rotateCoache3PushButtonClicked()));

    rotateAllButton4 = new QPushButton(rotateAllPage);
    rotateAllButton4->setGeometry(880,50,91,121);
    rotateAllButton4->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton4->setText("04");
    rotateAllButton4->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton4,SIGNAL(clicked()),this,SLOT(rotateCoache4PushButtonClicked()));

    rotateAllButton5 = new QPushButton(rotateAllPage);
    rotateAllButton5->setGeometry(580,180,91,121);
    rotateAllButton5->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton5->setText("05");
    rotateAllButton5->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton5,SIGNAL(clicked()),this,SLOT(rotateCoache5PushButtonClicked()));

    rotateAllButton6 = new QPushButton(rotateAllPage);
    rotateAllButton6->setGeometry(680,180,91,121);
    rotateAllButton6->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton6->setText("06");
    rotateAllButton6->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton6,SIGNAL(clicked()),this,SLOT(rotateCoache6PushButtonClicked()));

    rotateAllButton7 = new QPushButton(rotateAllPage);
    rotateAllButton7->setGeometry(780,180,91,121);
    rotateAllButton7->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton7->setText("07");
    rotateAllButton7->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton7,SIGNAL(clicked()),this,SLOT(rotateCoache7PushButtonClicked()));

    rotateAllButton8 = new QPushButton(rotateAllPage);
    rotateAllButton8->setGeometry(880,180,91,121);
    rotateAllButton8->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton8->setText("08");
    rotateAllButton8->setFocusPolicy(Qt::NoFocus);
    connect(rotateAllButton8,SIGNAL(clicked()),this,SLOT(rotateCoache8PushButtonClicked()));

    rotateAll1CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll1CoacheTable->setGeometry(5,5,565,570);
    rotateAll1CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll1CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll1CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll1CoacheTable->verticalHeader()->setVisible(false);
    rotateAll1CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll1CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll1CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll1CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll1CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll1CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll1CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll1CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll1CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll1CoacheTable->columnCount();j++)
        {
            if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                rotateAll1CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                rotateAll1CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll1CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    rotateAll1CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll1CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll1CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll1CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll1CoacheTable->hide();

    rotateAll2CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll2CoacheTable->setGeometry(5,5,565,570);
    rotateAll2CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll2CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll2CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll2CoacheTable->verticalHeader()->setVisible(false);
    rotateAll2CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll2CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll2CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll2CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll2CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll2CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll2CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll2CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll2CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll2CoacheTable->columnCount();j++)
        {
            rotateAll2CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    rotateAll2CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll2CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll2CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll2CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll2CoacheTable->hide();

    rotateAll3CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll3CoacheTable->setGeometry(5,5,565,570);
    rotateAll3CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll3CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll3CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll3CoacheTable->verticalHeader()->setVisible(false);
    rotateAll3CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll3CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll3CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll3CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll3CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll3CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll3CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll3CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll3CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll3CoacheTable->columnCount();j++)
        {
            if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                rotateAll3CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                rotateAll3CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll3CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    rotateAll3CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll3CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll3CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll3CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll3CoacheTable->hide();

    rotateAll4CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll4CoacheTable->setGeometry(5,5,565,570);
    rotateAll4CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll4CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll4CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll4CoacheTable->verticalHeader()->setVisible(false);
    rotateAll4CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll4CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll4CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll4CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll4CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll4CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll4CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll4CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll4CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll4CoacheTable->columnCount();j++)
        {
            rotateAll4CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    rotateAll4CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll4CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll4CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll4CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll4CoacheTable->hide();

    rotateAll5CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll5CoacheTable->setGeometry(5,5,565,570);
    rotateAll5CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll5CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll5CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll5CoacheTable->verticalHeader()->setVisible(false);
    rotateAll5CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll5CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll5CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll5CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll5CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll5CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll5CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll5CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll5CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll5CoacheTable->columnCount();j++)
        {
            rotateAll5CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    rotateAll5CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll5CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll5CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll5CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll5CoacheTable->hide();

    rotateAll6CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll6CoacheTable->setGeometry(5,5,565,570);
    rotateAll6CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll6CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll6CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll6CoacheTable->verticalHeader()->setVisible(false);
    rotateAll6CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll6CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll6CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll6CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll6CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll6CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll6CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll6CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll6CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll6CoacheTable->columnCount();j++)
        {
            if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                rotateAll6CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                rotateAll6CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll6CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    rotateAll6CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll6CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll6CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll6CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll6CoacheTable->hide();

    rotateAll7CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll7CoacheTable->setGeometry(5,5,565,570);
    rotateAll7CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll7CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll7CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll7CoacheTable->verticalHeader()->setVisible(false);
    rotateAll7CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll7CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll7CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll7CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll7CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll7CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll7CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll7CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll7CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll7CoacheTable->columnCount();j++)
        {
            rotateAll7CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    rotateAll7CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll7CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll7CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll7CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll7CoacheTable->hide();

    rotateAll8CoacheTable = new QTableWidget(rotateAllPage);
    rotateAll8CoacheTable->setGeometry(5,5,565,570);
    rotateAll8CoacheTable->setColumnCount(rotateAllTableHeader.length());
    rotateAll8CoacheTable->setRowCount(rotateAllTableColunm.length());
    rotateAll8CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
    rotateAll8CoacheTable->verticalHeader()->setVisible(false);
    rotateAll8CoacheTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAll8CoacheTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAll8CoacheTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAll8CoacheTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAll8CoacheTable->setStyleSheet(sheetBackgroundColor);
    rotateAll8CoacheTable->setFrameShape(QFrame::NoFrame);
    for(int i =0;i<rotateAllTableColunm.length();i++)
    {
        rotateAll8CoacheTable->setItem(i,0,new QTableWidgetItem(rotateAllTableColunm.at(i)));
        rotateAll8CoacheTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAll8CoacheTable->rowCount();i++)
    {
        for(int j=1;j<rotateAll8CoacheTable->columnCount();j++)
        {
            if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                rotateAll8CoacheTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                rotateAll8CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll8CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    rotateAll8CoacheTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAll8CoacheTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateAll8CoacheTable->verticalHeader()->setDefaultSectionSize(45);
    rotateAll8CoacheTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    rotateAll8CoacheTable->hide();

    //rotatesinglepage
    rotateSinglePage = new QWidget;
    rotateSinglePage->setGeometry(0,0,975,580);

    rotateAlxeTable = new QTableWidget(rotateSinglePage);
    rotateAlxeTable->setGeometry(5,5,965,590);
    rotateAlxeTable->setColumnCount(rotateSignleTableHeader.length());
    rotateAlxeTable->setHorizontalHeaderLabels(rotateSignleTableHeader);
    rotateAlxeTable->verticalHeader()->setVisible(false);
    rotateAlxeTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateAlxeTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateAlxeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateAlxeTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateAlxeTable->setStyleSheet(sheetBackgroundColor);
    rotateAlxeTable->setFrameShape(QFrame::NoFrame);
    rotateAlxeTable->setRowCount(rotateAlxeboxTableColunm.length());
    for(int i =0;i<rotateAlxeboxTableColunm.length();i++)
    {
        rotateAlxeTable->setItem(i,0,new QTableWidgetItem(rotateAlxeboxTableColunm.at(i)));
        rotateAlxeTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateAlxeTable->rowCount();i++)
    {
        for(int j=1;j<rotateAlxeTable->columnCount();j++)
        {
            rotateAlxeTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            rotateAlxeTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            rotateAlxeTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    rotateAlxeTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateAlxeTable->setSelectionMode(QAbstractItemView::NoSelection);
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayAlxeboxSheet(int)));

    rotateGearboxTable = new QTableWidget(rotateSinglePage);
    rotateGearboxTable->setGeometry(5,5,965,590);
    rotateGearboxTable->setColumnCount(rotateSignleTableHeader.length());
    rotateGearboxTable->setHorizontalHeaderLabels(rotateSignleTableHeader);
    rotateGearboxTable->verticalHeader()->setVisible(false);
    rotateGearboxTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateGearboxTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateGearboxTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateGearboxTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateGearboxTable->setStyleSheet(sheetBackgroundColor);
    rotateGearboxTable->setFrameShape(QFrame::NoFrame);
    rotateGearboxTable->setRowCount(rotateGearboxTableColunm.length());
    for(int i =0;i<rotateGearboxTableColunm.length();i++)
    {
        rotateGearboxTable->setItem(i,0,new QTableWidgetItem(rotateGearboxTableColunm.at(i)));
        rotateGearboxTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateGearboxTable->rowCount();i++)
    {
        for(int j=1;j<rotateGearboxTable->columnCount();j++)
        {
            if((j == 1)||(j == 3)||(j == 6)||(j == 8)){
                rotateGearboxTable->setItem(i,j,new QTableWidgetItem("-"));
                rotateGearboxTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateGearboxTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateGearboxTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else{
                rotateGearboxTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                rotateGearboxTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateGearboxTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    rotateGearboxTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateGearboxTable->setSelectionMode(QAbstractItemView::NoSelection);
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayGearboxSheet(int)));

    rotateMotorTable = new QTableWidget(rotateSinglePage);
    rotateMotorTable->setGeometry(5,5,965,590);
    rotateMotorTable->setColumnCount(rotateSignleTableHeader.length());
    rotateMotorTable->setHorizontalHeaderLabels(rotateSignleTableHeader);
    rotateMotorTable->verticalHeader()->setVisible(false);
    rotateMotorTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    rotateMotorTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    rotateMotorTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rotateMotorTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    rotateMotorTable->setStyleSheet(sheetBackgroundColor);
    rotateMotorTable->setFrameShape(QFrame::NoFrame);
    rotateMotorTable->setRowCount(rotateMotorTableColunm.length());
    for(int i =0;i<rotateMotorTableColunm.length();i++)
    {
        rotateMotorTable->setItem(i,0,new QTableWidgetItem(rotateMotorTableColunm.at(i)));
        rotateMotorTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<rotateMotorTable->rowCount();i++)
    {
        for(int j=1;j<rotateMotorTable->columnCount();j++)
        {
            if((j == 1)||(j == 3)||(j == 6)||(j == 8)){
                rotateMotorTable->setItem(i,j,new QTableWidgetItem("-"));
                rotateMotorTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateMotorTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateMotorTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else{
                rotateMotorTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                rotateMotorTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateMotorTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    rotateMotorTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rotateMotorTable->setSelectionMode(QAbstractItemView::NoSelection);
    rotateMotorTable->verticalHeader()->setDefaultSectionSize(45);
    rotateMotorTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayMotorSheet(int)));

    //fireWorkPage
    fireWorkPage = new QWidget;
    fireWorkPage->setGeometry(0,0,975,580);

    ft.setPointSize(24);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    fireWorkHeader = new QLabel(fireWorkPage);
    fireWorkHeader->setGeometry(360,20,200,40);
    fireWorkHeader->setText("�̻���");
    fireWorkHeader->setFont(ft);
    fireWorkHeader->setPalette(pa);

    fireWorkCoache1Table = new QTableWidget(fireWorkPage);
    fireWorkCoache1Table->setGeometry(5,60,965,520);
    fireWorkCoache1Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache1Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache1Table->verticalHeader()->setVisible(false);
    fireWorkCoache1Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache1Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache1Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache1Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache1Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache1Table->setRowCount(fireWorkCoache1.length());
    for(int i =0;i<fireWorkCoache1.length();i++)
    {
        fireWorkCoache1Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache1.at(i)));
        fireWorkCoache1Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache1Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache1Table->columnCount();j++)
        {
            if(j==3){
                fireWorkCoache1Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache1Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache1Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache1Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache1Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache1Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache1Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache1Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache1Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache1Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache1Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache1TableReceiveData(int)));
    fireWorkCoache1Table->hide();

    fireWorkCoache2Table = new QTableWidget(fireWorkPage);
    fireWorkCoache2Table->setGeometry(5,60,965,520);
    fireWorkCoache2Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache2Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache2Table->verticalHeader()->setVisible(false);
    fireWorkCoache2Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache2Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache2Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache2Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache2Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache2Table->setRowCount(fireWorkCoache2.length());
    for(int i =0;i<fireWorkCoache2.length();i++)
    {
        fireWorkCoache2Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache2.at(i)));
        fireWorkCoache2Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache2Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache2Table->columnCount();j++)
        {
            if((j==3)&&(i!=8)){
                fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache2Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==1)&&(i==8)){
                fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache2Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==2)&&(i==8)){
                fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache2Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache2Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache2Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache2Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache2Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache2TableReceiveData(int)));
    fireWorkCoache2Table->hide();

    fireWorkCoache3Table = new QTableWidget(fireWorkPage);
    fireWorkCoache3Table->setGeometry(5,60,965,520);
    fireWorkCoache3Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache3Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache3Table->verticalHeader()->setVisible(false);
    fireWorkCoache3Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache3Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache3Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache3Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache3Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache3Table->setRowCount(fireWorkCoache3.length());
    for(int i =0;i<fireWorkCoache3.length();i++)
    {
        fireWorkCoache3Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache3.at(i)));
        fireWorkCoache3Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache3Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache3Table->columnCount();j++)
        {
            if(j==3){
                fireWorkCoache3Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache3Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache3Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache3Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache3Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache3Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache3Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache3Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache3Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache3Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache3Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache3TableReceiveData(int)));
    fireWorkCoache3Table->hide();

    fireWorkCoache4Table = new QTableWidget(fireWorkPage);
    fireWorkCoache4Table->setGeometry(5,60,965,520);
    fireWorkCoache4Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache4Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache4Table->verticalHeader()->setVisible(false);
    fireWorkCoache4Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache4Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache4Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache4Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache4Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache4Table->setRowCount(fireWorkCoache4.length());
    for(int i =0;i<fireWorkCoache4.length();i++)
    {
        fireWorkCoache4Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache4.at(i)));
        fireWorkCoache4Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache4Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache4Table->columnCount();j++)
        {
            if((j==3)&&(i!=8)){
                fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache4Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==1)&&(i==8)){
                fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache4Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==2)&&(i==8)){
                fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache4Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache4Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache4Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache4Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache4Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache4TableReceiveData(int)));
    fireWorkCoache4Table->hide();

    fireWorkCoache5Table = new QTableWidget(fireWorkPage);
    fireWorkCoache5Table->setGeometry(5,60,965,520);
    fireWorkCoache5Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache5Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache5Table->verticalHeader()->setVisible(false);
    fireWorkCoache5Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache5Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache5Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache5Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache5Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache5Table->setRowCount(fireWorkCoache5.length());
    for(int i =0;i<fireWorkCoache5.length();i++)
    {
        fireWorkCoache5Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache5.at(i)));
        fireWorkCoache5Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache5Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache5Table->columnCount();j++)
        {
            if((j==3)&&(i!=7)){
                fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache5Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==1)&&(i==7)){
                fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache5Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==2)&&(i==7)){
                fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache5Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache5Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache5Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache5Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache5Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache5TableReceiveData(int)));
    fireWorkCoache5Table->hide();

    fireWorkCoache6Table = new QTableWidget(fireWorkPage);
    fireWorkCoache6Table->setGeometry(5,60,965,520);
    fireWorkCoache6Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache6Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache6Table->verticalHeader()->setVisible(false);
    fireWorkCoache6Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache6Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache6Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache6Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache6Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache6Table->setRowCount(fireWorkCoache6.length());
    for(int i =0;i<fireWorkCoache6.length();i++)
    {
        fireWorkCoache6Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache6.at(i)));
        fireWorkCoache6Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache6Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache6Table->columnCount();j++)
        {
            if(j==3){
                fireWorkCoache6Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache6Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache6Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache6Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache6Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache6Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache6Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache6Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache6Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache6Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache6Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache6TableReceiveData(int)));
    fireWorkCoache6Table->hide();

    fireWorkCoache7Table = new QTableWidget(fireWorkPage);
    fireWorkCoache7Table->setGeometry(5,60,965,520);
    fireWorkCoache7Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache7Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache7Table->verticalHeader()->setVisible(false);
    fireWorkCoache7Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache7Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache7Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache7Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache7Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache7Table->setRowCount(fireWorkCoache7.length());
    for(int i =0;i<fireWorkCoache7.length();i++)
    {
        fireWorkCoache7Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache7.at(i)));
        fireWorkCoache7Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache7Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache7Table->columnCount();j++)
        {
            if((j==3)&&(i!=8)){
                fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache7Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==1)&&(i==8)){
                fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache7Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else if((j==2)&&(i==8)){
                fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache7Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache7Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache7Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache7Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache7Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache7TableReceiveData(int)));
    fireWorkCoache7Table->hide();

    fireWorkCoache8Table = new QTableWidget(fireWorkPage);
    fireWorkCoache8Table->setGeometry(5,60,965,520);
    fireWorkCoache8Table->setColumnCount(fireWorkTableHeader.length());
    fireWorkCoache8Table->setHorizontalHeaderLabels(fireWorkTableHeader);
    fireWorkCoache8Table->verticalHeader()->setVisible(false);
    fireWorkCoache8Table->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireWorkCoache8Table->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireWorkCoache8Table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireWorkCoache8Table->setStyleSheet(sheetBackgroundColor);
    fireWorkCoache8Table->setFrameShape(QFrame::NoFrame);
    fireWorkCoache8Table->setRowCount(fireWorkCoache8.length());
    for(int i =0;i<fireWorkCoache8.length();i++)
    {
        fireWorkCoache8Table->setItem(i,0,new QTableWidgetItem(fireWorkCoache8.at(i)));
        fireWorkCoache8Table->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireWorkCoache8Table->rowCount();i++)
    {
        for(int j=1;j<fireWorkCoache8Table->columnCount();j++)
        {
            if(j==3){
                fireWorkCoache8Table->setItem(i,j,new QTableWidgetItem("-"));
                fireWorkCoache8Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                fireWorkCoache8Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                fireWorkCoache8Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }else{
                fireWorkCoache8Table->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                fireWorkCoache8Table->item(i,j)->setBackgroundColor(QColor(255,242,204));
                fireWorkCoache8Table->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    fireWorkCoache8Table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireWorkCoache8Table->setSelectionMode(QAbstractItemView::NoSelection);
    fireWorkCoache8Table->verticalHeader()->setDefaultSectionSize(45);
    fireWorkCoache8Table->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(fireWorkCoache8TableReceiveData(int)));
    fireWorkCoache8Table->hide();

    //balanceInstability Page
    balanceInstabilityPage  =   new QWidget;
    balanceInstabilityPage->setGeometry(0,0,975,580);

    ft.setPointSize(24);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    balanceInstabilityHeader = new QLabel(balanceInstabilityPage);
    balanceInstabilityHeader->setGeometry(360,20,200,40);
    balanceInstabilityHeader->setText("ʧ��ƽ��");
    balanceInstabilityHeader->setFont(ft);
    balanceInstabilityHeader->setPalette(pa);

    balanceInstabilityTable = new QTableWidget(balanceInstabilityPage);
    balanceInstabilityTable->setGeometry(5,60,965,520);
    balanceInstabilityTable->setColumnCount(balanceInstabilityTableHeader.length());
    balanceInstabilityTable->setHorizontalHeaderLabels(balanceInstabilityTableHeader);
    balanceInstabilityTable->verticalHeader()->setVisible(false);
    balanceInstabilityTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    balanceInstabilityTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    balanceInstabilityTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    balanceInstabilityTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    balanceInstabilityTable->setStyleSheet(sheetBackgroundColor);
    balanceInstabilityTable->setFrameShape(QFrame::NoFrame);
    balanceInstabilityTable->setRowCount(balanceInstabilityColumn.length());
    for(int i =0;i<balanceInstabilityColumn.length();i++)
    {
        balanceInstabilityTable->setItem(i,0,new QTableWidgetItem(balanceInstabilityColumn.at(i)));
        balanceInstabilityTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<balanceInstabilityTable->rowCount();i++)
    {
        for(int j=1;j<balanceInstabilityTable->columnCount();j++)
        {
            balanceInstabilityTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            balanceInstabilityTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            balanceInstabilityTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    balanceInstabilityTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    balanceInstabilityTable->setSelectionMode(QAbstractItemView::NoSelection);
    balanceInstabilityTable->verticalHeader()->setDefaultSectionSize(45);
    balanceInstabilityTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    balanceInstabilityTable->show();

    //fireLinkagePage
    fireLinkagePage  =   new QWidget;
    fireLinkagePage->setGeometry(0,0,975,580);

    ft.setPointSize(24);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    fireLinkageHeader = new QLabel(fireLinkagePage);
    fireLinkageHeader->setGeometry(360,20,200,40);
    fireLinkageHeader->setText("��������");
    fireLinkageHeader->setFont(ft);
    fireLinkageHeader->setPalette(pa);

    fireLinkageTable = new QTableWidget(fireLinkagePage);
    fireLinkageTable->setGeometry(5,60,965,520);
    fireLinkageTable->setColumnCount(fireLinkageTableHeader.length());
    fireLinkageTable->setHorizontalHeaderLabels(fireLinkageTableHeader);
    fireLinkageTable->verticalHeader()->setVisible(false);
    fireLinkageTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    fireLinkageTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    fireLinkageTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    fireLinkageTable->setStyleSheet(sheetBackgroundColor);
    fireLinkageTable->setFrameShape(QFrame::NoFrame);
    fireLinkageTable->setRowCount(fireLinkageColumn.length());
    for(int i =0;i<fireLinkageColumn.length();i++)
    {
        fireLinkageTable->setItem(i,0,new QTableWidgetItem(fireLinkageColumn.at(i)));
        fireLinkageTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<fireLinkageTable->rowCount();i++)
    {
        for(int j=1;j<fireLinkageTable->columnCount();j++)
        {
            fireLinkageTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            fireLinkageTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            fireLinkageTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    fireLinkageTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fireLinkageTable->setSelectionMode(QAbstractItemView::NoSelection);
    fireLinkageTable->verticalHeader()->setDefaultSectionSize(45);
    fireLinkageTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    fireLinkageTable->show();

    //temperaturePage
    temperaturePage = new QWidget;
    temperaturePage->setGeometry(0,0,975,580);

    temperatureAlxeTable = new QTableWidget(temperaturePage);
    temperatureAlxeTable->setGeometry(5,5,965,590);
    temperatureAlxeTable->setColumnCount(temperatureAlxeboxTableHeader.length());
    temperatureAlxeTable->setHorizontalHeaderLabels(temperatureAlxeboxTableHeader);
    temperatureAlxeTable->verticalHeader()->setVisible(false);
    temperatureAlxeTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    temperatureAlxeTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    temperatureAlxeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    temperatureAlxeTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    temperatureAlxeTable->setStyleSheet(sheetBackgroundColor);
    temperatureAlxeTable->setFrameShape(QFrame::NoFrame);
    temperatureAlxeTable->setRowCount(temperatureAlxeboxTableColunm.length());
    for(int i =0;i<temperatureAlxeboxTableColunm.length();i++)
    {
        temperatureAlxeTable->setItem(i,0,new QTableWidgetItem(temperatureAlxeboxTableColunm.at(i)));
        temperatureAlxeTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<temperatureAlxeTable->rowCount();i++)
    {
        for(int j=1;j<temperatureAlxeTable->columnCount();j++)
        {
            temperatureAlxeTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
            temperatureAlxeTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
            temperatureAlxeTable->item(i,j)->setFlags(Qt::NoItemFlags);
        }
    }
    temperatureAlxeTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    temperatureAlxeTable->setSelectionMode(QAbstractItemView::NoSelection);
    temperatureAlxeTable->verticalHeader()->setDefaultSectionSize(45);
    temperatureAlxeTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    temperatureAlxeTable->hide();
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayTemperatureAlxeTable(int)));

    temperatureGearboxTable = new QTableWidget(temperaturePage);
    temperatureGearboxTable->setGeometry(5,5,965,590);
    temperatureGearboxTable->setColumnCount(temperatureGearboxTableHeader.length());
    temperatureGearboxTable->setHorizontalHeaderLabels(temperatureGearboxTableHeader);
    temperatureGearboxTable->verticalHeader()->setVisible(false);
    temperatureGearboxTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    temperatureGearboxTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    temperatureGearboxTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    temperatureGearboxTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    temperatureGearboxTable->setStyleSheet(sheetBackgroundColor);
    temperatureGearboxTable->setFrameShape(QFrame::NoFrame);
    temperatureGearboxTable->setRowCount(temperatureGearboxTableColunm.length());
    for(int i =0;i<temperatureGearboxTableColunm.length();i++)
    {
        temperatureGearboxTable->setItem(i,0,new QTableWidgetItem(temperatureGearboxTableColunm.at(i)));
        temperatureGearboxTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<temperatureGearboxTable->rowCount();i++)
    {
        for(int j=1;j<temperatureGearboxTable->columnCount();j++)
        {
            if((j == 1)||(j == 3)||(j == 6)||(j == 8)){
                temperatureGearboxTable->setItem(i,j,new QTableWidgetItem("-"));
                temperatureGearboxTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                temperatureGearboxTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                temperatureGearboxTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else{
                temperatureGearboxTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                temperatureGearboxTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                temperatureGearboxTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    temperatureGearboxTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    temperatureGearboxTable->setSelectionMode(QAbstractItemView::NoSelection);
    temperatureGearboxTable->hide();
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayTemperatureGearTable(int)));

    temperatureMotorTable = new QTableWidget(temperaturePage);
    temperatureMotorTable->setGeometry(5,5,965,590);
    temperatureMotorTable->setColumnCount(temperatureMotorTableHeader.length());
    temperatureMotorTable->setHorizontalHeaderLabels(temperatureMotorTableHeader);
    temperatureMotorTable->verticalHeader()->setVisible(false);
    temperatureMotorTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    temperatureMotorTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    temperatureMotorTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    temperatureMotorTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    temperatureMotorTable->setStyleSheet(sheetBackgroundColor);
    temperatureMotorTable->setFrameShape(QFrame::NoFrame);
    temperatureMotorTable->setRowCount(temperatureMotorTableColunm.length());
    for(int i =0;i<temperatureMotorTableColunm.length();i++)
    {
        temperatureMotorTable->setItem(i,0,new QTableWidgetItem(temperatureMotorTableColunm.at(i)));
        temperatureMotorTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<temperatureMotorTable->rowCount();i++)
    {
        for(int j=1;j<temperatureGearboxTable->columnCount();j++)
        {
            if((j == 1)||(j == 3)||(j == 6)||(j == 8)){
                temperatureMotorTable->setItem(i,j,new QTableWidgetItem("-"));
                temperatureMotorTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                temperatureMotorTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                temperatureMotorTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else{
                temperatureMotorTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                temperatureMotorTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                temperatureMotorTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    temperatureMotorTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    temperatureMotorTable->setSelectionMode(QAbstractItemView::NoSelection);
    temperatureMotorTable->verticalHeader()->setDefaultSectionSize(45);
    temperatureMotorTable->horizontalHeader()->setFixedHeight(45); //���ñ�ͷ�ĸ߶�
    temperatureMotorTable->hide();
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayTemperatureMotorTable(int)));

    temperatureMotorAndDiningTable = new QTableWidget(temperaturePage);
    temperatureMotorAndDiningTable->setGeometry(5,5,965,590);
    temperatureMotorAndDiningTable->setColumnCount(temperatureMotorAndDiningTableHeader.length());
    temperatureMotorAndDiningTable->setHorizontalHeaderLabels(temperatureMotorAndDiningTableHeader);
    temperatureMotorAndDiningTable->verticalHeader()->setVisible(false);
    temperatureMotorAndDiningTable->horizontalHeader()->setSectionsClickable(false);
    sheetHorHeaderStyle="QHeaderView::section{background:rgba(0,255,255,255);}";
    temperatureMotorAndDiningTable->horizontalHeader()->setStyleSheet(sheetHorHeaderStyle);
    temperatureMotorAndDiningTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    temperatureMotorAndDiningTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    sheetBackgroundColor="background-color:rgba(0,0,0,0);color: rgb(0, 85, 255);font-family: ����;";
    temperatureMotorAndDiningTable->setStyleSheet(sheetBackgroundColor);
    temperatureMotorAndDiningTable->setFrameShape(QFrame::NoFrame);
    temperatureMotorAndDiningTable->setRowCount(temperatureMotorAndDiningTableColunm.length());
    for(int i =0;i<temperatureMotorAndDiningTableColunm.length();i++)
    {
        temperatureMotorAndDiningTable->setItem(i,0,new QTableWidgetItem(temperatureMotorAndDiningTableColunm.at(i)));
        temperatureMotorAndDiningTable->item(i,0)->setFlags(Qt::NoItemFlags);
    }
    for(int i=0;i<temperatureMotorAndDiningTable->rowCount();i++)
    {
        for(int j=1;j<temperatureMotorAndDiningTable->columnCount();j++)
        {
            if((i == 8)||(i == 9)||(i == 10)){
                if((j == 1)||(j == 2)||(j == 4)){
                    temperatureMotorAndDiningTable->setItem(i,j,new QTableWidgetItem("-"));
                    temperatureMotorAndDiningTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    temperatureMotorAndDiningTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    temperatureMotorAndDiningTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    temperatureMotorAndDiningTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                    temperatureMotorAndDiningTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                    temperatureMotorAndDiningTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }else{
                temperatureMotorAndDiningTable->setItem(i,j,new QTableWidgetItem("�ȴ�����"));
                temperatureMotorAndDiningTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                temperatureMotorAndDiningTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
    temperatureMotorAndDiningTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    temperatureMotorAndDiningTable->setSelectionMode(QAbstractItemView::NoSelection);
    temperatureMotorAndDiningTable->hide();
    connect(udpSocket,SIGNAL(sendRecieveCoacheNum(int)),this,SLOT(displayTemperatureMotorAndDiningTable(int)));

    //sysSettingPage
    sysSettingPage  =   new QWidget;
    sysSettingPage->setGeometry(0,0,975,580);

    ft.setPointSize(24);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,QColor(255, 255, 255));
    sysSettingHeader = new QLabel(sysSettingPage);
    sysSettingHeader->setGeometry(360,20,200,40);
    sysSettingHeader->setText("ϵͳ����");
    sysSettingHeader->setFont(ft);
    sysSettingHeader->setPalette(pa);

    lightSetting    =   new QGroupBox(sysSettingPage);
    sysSettingStyle = "QGroupBox{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    lightSetting->setGeometry(50,100,400,200);
    lightSetting->setStyleSheet(sysSettingStyle);
    lightSetting->setTitle("��������");

    addLightButon    =   new QPushButton(lightSetting);
    sysSettingStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    addLightButon->setGeometry(20,60,100,100);
    addLightButon->setStyleSheet(sysSettingStyle);
    addLightButon->setText("+");
    connect(addLightButon,SIGNAL(clicked()),this,SLOT(addLightButtonClicked()));

    reduceLightButon    =   new QPushButton(lightSetting);
    sysSettingStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    reduceLightButon->setGeometry(280,60,100,100);
    reduceLightButon->setStyleSheet(sysSettingStyle);
    reduceLightButon->setText("-");
    connect(reduceLightButon,SIGNAL(clicked()),this,SLOT(reduceLightButtonClicked()));

    lightValueLable     =   new QLabel(lightSetting);
    sysSettingStyle     =   "QLabel{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    lightValueLable->setGeometry(140,70,120,80);
    lightValueLable->setStyleSheet(sysSettingStyle);
    lightValueLable->setText("100");
    lightValueLable->setAlignment(Qt::AlignCenter);
    bool ok             =   false;
    brightValue         =   lightValueLable->text().toInt(&ok,10);
    QString a;
    a.setNum(brightValue,16);
    QString cmd = "gpio_i2c_write 0xf0 0x1 0x"+a;
    system(cmd.toLatin1().data());

    QSettings *configIniWrite = new QSettings("/root/run/init/brightnessinit.ini", QSettings::IniFormat);
    configIniWrite->setValue("/Bright/value", QString::number(brightValue,10));
    delete configIniWrite;

    timingSetting    =   new QGroupBox(sysSettingPage);
    sysSettingStyle = "QGroupBox{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    timingSetting->setGeometry(500,100,400,400);
    timingSetting->setStyleSheet(sysSettingStyle);
    timingSetting->setTitle("Уʱ");

    timingEdit      =   new QTimeEdit(timingSetting);
    sysSettingStyle = "QTimeEdit{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    timingEdit->setGeometry(20,60,360,50);
    timingEdit->setStyleSheet(sysSettingStyle);

    datingEdit      =   new QDateEdit(timingSetting);
    sysSettingStyle = "QDateEdit{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    datingEdit->setGeometry(20,170,360,50);
    datingEdit->setStyleSheet(sysSettingStyle);
    datingEdit->setDisplayFormat("yyyy-MM-dd");

    readSystimeButon    =   new QPushButton(timingSetting);
    sysSettingStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    readSystimeButon->setGeometry(20,280,150,80);
    readSystimeButon->setStyleSheet(sysSettingStyle);
    readSystimeButon->setText("ϵͳʱ��");
    connect(readSystimeButon,SIGNAL(clicked()),this,SLOT(readSystimeButtonClicked()));

    settingSystimeButon    =   new QPushButton(timingSetting);
    sysSettingStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255); background: transparent;font: 75 18pt ;font-family: ����;}";
    settingSystimeButon->setGeometry(220,280,150,80);
    settingSystimeButon->setStyleSheet(sysSettingStyle);
    settingSystimeButon->setText("����ʱ��");
    connect(settingSystimeButon,SIGNAL(clicked()),this,SLOT(settingSystimeButtonClicked()));
}
//display rotateAllTable
void Widget::displayrotateAllTable(int coacheNumber)
{
    switch (coacheNumber) {
    case 1:
        rotateAllTableHeader.replace(0,"01��");
        rotateAll1CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll1CoacheTable->show();
        break;
    case 2:
        rotateAllTableHeader.replace(0,"02��");
        rotateAll2CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll2CoacheTable->show();
        break;
    case 3:
        rotateAllTableHeader.replace(0,"03��");
        rotateAll3CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll3CoacheTable->show();
        break;
    case 4:
        rotateAllTableHeader.replace(0,"04��");
        rotateAll4CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll4CoacheTable->show();
        break;
    case 5:
        rotateAllTableHeader.replace(0,"05��");
        rotateAll5CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll5CoacheTable->show();
        break;
    case 6:
        rotateAllTableHeader.replace(0,"06��");
        rotateAll6CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll6CoacheTable->show();
        break;
    case 7:
        rotateAllTableHeader.replace(0,"07��");
        rotateAll7CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll7CoacheTable->show();
        break;
    case 8:
        rotateAllTableHeader.replace(0,"08��");
        rotateAll8CoacheTable->setHorizontalHeaderLabels(rotateAllTableHeader);
        rotateAllTableRelease();
        rotateAll8CoacheTable->show();
        break;
    default:
        break;
    }
}
//paint line
void Widget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setBrush(Qt::black);
    p.drawRect(rect());
    QPen pen;
    pen.setColor(Qt::white);
    pen.setWidth(3);
    p.setPen(pen);
    p.drawLine(0,70,1024,70);
    //p.drawLine(120,10,120,60);
    p.drawLine(200,10,200,60);
    //p.drawLine(400,10,400,60);
    p.drawLine(550,10,550,60);
    p.drawLine(900,10,900,60);
    //p.drawLine(860,10,860,60);
    p.drawLine(0,660,1024,660);
}
//set log file path
void Widget::setFilePath()
{
    QDir dir(QCoreApplication::applicationDirPath());
    if(dir.cdUp())
    {
        //only store the log files a month
        QDir _logdir(dir.path()+"/log");
        if(!_logdir.exists())
        {
            dir.mkdir("log");
        }
        _logdir.setFilter(QDir::Files|QDir::NoDotAndDotDot|QDir::NoSymLinks);
        _logdir.setSorting(QDir::Time|QDir::Reversed);
        QFileInfoList list = _logdir.entryInfoList();
        if(list.count()>30)
        {
            _logdir.remove(list.at(0).fileName());
        }
        pathLogFile = dir.path()+"/log/"+QDateTime::currentDateTime().toString("yyyy-MM-dd")+".log";
        writeLog("System Is Power Up!");
        writeLog("Log File Path --- " + pathLogFile);

        pathConfig = dir.path()+"/config/";

        //car config file
        QDir _clogdir(dir.path()+"/config");
        if(!_clogdir.exists())
        {
            dir.mkdir("config");
        }
        //ϵͳ�����ļ�
        pathSysConfig = dir.path()+"/config/sysConfig.xml";
        writeLog("Config File Path --- " + pathSysConfig);
        readSystemConfig(pathSysConfig);
    }
}
//read config file
void Widget::readSystemConfig(QString fileName)
{
    QFile file(fileName);
    QDomDocument doc;
    if(file.open(QIODevice::ReadOnly | QFile::Text))
    {
        QString errorStr;
        int     errorLine;
        int     errorColumn;
        if(!doc.setContent(&file,false,&errorStr,&errorLine,&errorColumn))
        {
            QString str = "[message-readSystemConfig]: set Content error, fileName:"+fileName;
            writeLog(str);
            file.close();
            return;
        }
        file.close();
    }
    QDomElement root = doc.documentElement();
    if(root.isNull())
    {
        root = doc.createElement("SysConfig");
        doc.appendChild(root);
        QDomElement element_sheetHeader = doc.createElement("SHEETHEADERINFO");
        element_sheetHeader.setAttribute("temperature","");
        element_sheetHeader.setAttribute("temperatureUnit","");
        element_sheetHeader.setAttribute("carName","");
        element_sheetHeader.setAttribute("carNumber","");
        element_sheetHeader.setAttribute("carSpeed","");
        element_sheetHeader.setAttribute("carSpeedUnit","");
        root.appendChild(element_sheetHeader);

        QDomElement element_mainTable = doc.createElement("MAINTABLEINFO");
        element_mainTable.setAttribute("one","");
        element_mainTable.setAttribute("two","");
        element_mainTable.setAttribute("three","");
        element_mainTable.setAttribute("four","");
        element_mainTable.setAttribute("five","");
        element_mainTable.setAttribute("six","");
        element_mainTable.setAttribute("seven","");
        root.appendChild(element_mainTable);

        QDomElement element_recordTable = doc.createElement("RECORDTABLEINFO");
        element_recordTable.setAttribute("one","");
        element_recordTable.setAttribute("two","");
        element_recordTable.setAttribute("three","");
        element_recordTable.setAttribute("four","");
        element_recordTable.setAttribute("five","");
        element_recordTable.setAttribute("six","");
        element_recordTable.setAttribute("seven","");
        root.appendChild(element_recordTable);

        QDomElement element_rotateTable = doc.createElement("ROTATEALLTABLEINFO");
        element_rotateTable.setAttribute("one","");
        element_rotateTable.setAttribute("two","");
        element_rotateTable.setAttribute("three","");
        element_rotateTable.setAttribute("four","");
        element_rotateTable.setAttribute("five","");
        root.appendChild(element_rotateTable);

        QDomElement element_rotateTableColumn = doc.createElement("ROTATEALLTABLECOLUMN");
        element_rotateTableColumn.setAttribute("one","");
        element_rotateTableColumn.setAttribute("two","");
        element_rotateTableColumn.setAttribute("three","");
        element_rotateTableColumn.setAttribute("four","");
        element_rotateTableColumn.setAttribute("five","");
        element_rotateTableColumn.setAttribute("six","");
        element_rotateTableColumn.setAttribute("seven","");
        element_rotateTableColumn.setAttribute("eight","");
        element_rotateTableColumn.setAttribute("nine","");
        element_rotateTableColumn.setAttribute("ten","");
        root.appendChild(element_rotateTableColumn);

        QDomElement element_rotateSingleTable = doc.createElement("ROTATESINGLETABLEINFO");
        element_rotateSingleTable.setAttribute("one","");
        element_rotateSingleTable.setAttribute("two","");
        element_rotateSingleTable.setAttribute("three","");
        element_rotateSingleTable.setAttribute("four","");
        element_rotateSingleTable.setAttribute("five","");
        element_rotateSingleTable.setAttribute("six","");
        element_rotateSingleTable.setAttribute("seven","");
        element_rotateSingleTable.setAttribute("eight","");
        element_rotateSingleTable.setAttribute("nine","");
        element_rotateSingleTable.setAttribute("ten","");
        root.appendChild(element_rotateSingleTable);

        QDomElement element_rotateAlxeTableColumn = doc.createElement("ROTATEALXETABLECOLUMN");
        element_rotateAlxeTableColumn.setAttribute("one","");
        element_rotateAlxeTableColumn.setAttribute("two","");
        element_rotateAlxeTableColumn.setAttribute("three","");
        element_rotateAlxeTableColumn.setAttribute("four","");
        element_rotateAlxeTableColumn.setAttribute("five","");
        element_rotateAlxeTableColumn.setAttribute("six","");
        element_rotateAlxeTableColumn.setAttribute("seven","");
        element_rotateAlxeTableColumn.setAttribute("eight","");
        element_rotateAlxeTableColumn.setAttribute("nine","");
        element_rotateAlxeTableColumn.setAttribute("ten","");
        element_rotateAlxeTableColumn.setAttribute("eleven","");
        element_rotateAlxeTableColumn.setAttribute("twelve","");
        element_rotateAlxeTableColumn.setAttribute("triteen","");
        element_rotateAlxeTableColumn.setAttribute("fourteen","");
        element_rotateAlxeTableColumn.setAttribute("fifteen","");
        element_rotateAlxeTableColumn.setAttribute("sixteen","");
        root.appendChild(element_rotateAlxeTableColumn);

        QDomElement element_rotateGearTableColumn = doc.createElement("ROTATEGEARTABLECOLUMN");
        element_rotateGearTableColumn.setAttribute("one","");
        element_rotateGearTableColumn.setAttribute("two","");
        element_rotateGearTableColumn.setAttribute("three","");
        element_rotateGearTableColumn.setAttribute("four","");
        element_rotateGearTableColumn.setAttribute("five","");
        element_rotateGearTableColumn.setAttribute("six","");
        element_rotateGearTableColumn.setAttribute("seven","");
        element_rotateGearTableColumn.setAttribute("eight","");
        element_rotateGearTableColumn.setAttribute("nine","");
        element_rotateGearTableColumn.setAttribute("ten","");
        element_rotateGearTableColumn.setAttribute("eleven","");
        element_rotateGearTableColumn.setAttribute("twelve","");
        element_rotateGearTableColumn.setAttribute("triteen","");
        element_rotateGearTableColumn.setAttribute("fourteen","");
        element_rotateGearTableColumn.setAttribute("fifteen","");
        element_rotateGearTableColumn.setAttribute("sixteen","");
        root.appendChild(element_rotateGearTableColumn);

        QDomElement element_rotateMotorTableColumn = doc.createElement("ROTATEMOTORTABLECOLUMN");
        element_rotateMotorTableColumn.setAttribute("one","");
        element_rotateMotorTableColumn.setAttribute("two","");
        element_rotateMotorTableColumn.setAttribute("three","");
        element_rotateMotorTableColumn.setAttribute("four","");
        element_rotateMotorTableColumn.setAttribute("five","");
        element_rotateMotorTableColumn.setAttribute("six","");
        element_rotateMotorTableColumn.setAttribute("seven","");
        element_rotateMotorTableColumn.setAttribute("eight","");
        root.appendChild(element_rotateMotorTableColumn);

        QDomElement element_fireWorkHeader = doc.createElement("FIREWORKHEADER");
        element_fireWorkHeader.setAttribute("one","");
        element_fireWorkHeader.setAttribute("two","");
        element_fireWorkHeader.setAttribute("three","");
        element_fireWorkHeader.setAttribute("four","");
        element_fireWorkHeader.setAttribute("five","");
        element_fireWorkHeader.setAttribute("six","");
        root.appendChild(element_fireWorkHeader);

        QDomElement element_fireWorkCoache1 = doc.createElement("FIREWORKCOACH1");
        element_fireWorkCoache1.setAttribute("one","");
        element_fireWorkCoache1.setAttribute("two","");
        element_fireWorkCoache1.setAttribute("three","");
        element_fireWorkCoache1.setAttribute("four","");
        element_fireWorkCoache1.setAttribute("five","");
        element_fireWorkCoache1.setAttribute("six","");
        element_fireWorkCoache1.setAttribute("seven","");
        element_fireWorkCoache1.setAttribute("eight","");
        element_fireWorkCoache1.setAttribute("nine","");
        element_fireWorkCoache1.setAttribute("ten","");
        root.appendChild(element_fireWorkCoache1);

        QDomElement element_fireWorkCoache2 = doc.createElement("FIREWORKCOACH2");
        element_fireWorkCoache2.setAttribute("one","");
        element_fireWorkCoache2.setAttribute("two","");
        element_fireWorkCoache2.setAttribute("three","");
        element_fireWorkCoache2.setAttribute("four","");
        element_fireWorkCoache2.setAttribute("five","");
        element_fireWorkCoache2.setAttribute("six","");
        element_fireWorkCoache2.setAttribute("seven","");
        element_fireWorkCoache2.setAttribute("eight","");
        element_fireWorkCoache2.setAttribute("nine","");
        root.appendChild(element_fireWorkCoache2);

        QDomElement element_fireWorkCoache3 = doc.createElement("FIREWORKCOACH3");
        element_fireWorkCoache3.setAttribute("one","");
        element_fireWorkCoache3.setAttribute("two","");
        element_fireWorkCoache3.setAttribute("three","");
        element_fireWorkCoache3.setAttribute("four","");
        element_fireWorkCoache3.setAttribute("five","");
        element_fireWorkCoache3.setAttribute("six","");
        element_fireWorkCoache3.setAttribute("seven","");
        element_fireWorkCoache3.setAttribute("eight","");
        root.appendChild(element_fireWorkCoache3);

        QDomElement element_fireWorkCoache4 = doc.createElement("FIREWORKCOACH4");
        element_fireWorkCoache4.setAttribute("one","");
        element_fireWorkCoache4.setAttribute("two","");
        element_fireWorkCoache4.setAttribute("three","");
        element_fireWorkCoache4.setAttribute("four","");
        element_fireWorkCoache4.setAttribute("five","");
        element_fireWorkCoache4.setAttribute("six","");
        element_fireWorkCoache4.setAttribute("seven","");
        element_fireWorkCoache4.setAttribute("eight","");
        element_fireWorkCoache4.setAttribute("nine","");
        root.appendChild(element_fireWorkCoache4);

        QDomElement element_fireWorkCoache5 = doc.createElement("FIREWORKCOACH5");
        element_fireWorkCoache5.setAttribute("one","");
        element_fireWorkCoache5.setAttribute("two","");
        element_fireWorkCoache5.setAttribute("three","");
        element_fireWorkCoache5.setAttribute("four","");
        element_fireWorkCoache5.setAttribute("five","");
        element_fireWorkCoache5.setAttribute("six","");
        element_fireWorkCoache5.setAttribute("seven","");
        element_fireWorkCoache5.setAttribute("eight","");
        root.appendChild(element_fireWorkCoache5);

        QDomElement element_fireWorkCoache6 = doc.createElement("FIREWORKCOACH6");
        element_fireWorkCoache6.setAttribute("one","");
        element_fireWorkCoache6.setAttribute("two","");
        element_fireWorkCoache6.setAttribute("three","");
        element_fireWorkCoache6.setAttribute("four","");
        element_fireWorkCoache6.setAttribute("five","");
        element_fireWorkCoache6.setAttribute("six","");
        element_fireWorkCoache6.setAttribute("seven","");
        element_fireWorkCoache6.setAttribute("eight","");
        root.appendChild(element_fireWorkCoache6);

        QDomElement element_fireWorkCoache7 = doc.createElement("FIREWORKCOACH7");
        element_fireWorkCoache7.setAttribute("one","");
        element_fireWorkCoache7.setAttribute("two","");
        element_fireWorkCoache7.setAttribute("three","");
        element_fireWorkCoache7.setAttribute("four","");
        element_fireWorkCoache7.setAttribute("five","");
        element_fireWorkCoache7.setAttribute("six","");
        element_fireWorkCoache7.setAttribute("seven","");
        element_fireWorkCoache7.setAttribute("eight","");
        element_fireWorkCoache7.setAttribute("nine","");
        root.appendChild(element_fireWorkCoache7);

        QDomElement element_fireWorkCoache8 = doc.createElement("FIREWORKCOACH8");
        element_fireWorkCoache8.setAttribute("one","");
        element_fireWorkCoache8.setAttribute("two","");
        element_fireWorkCoache8.setAttribute("three","");
        element_fireWorkCoache8.setAttribute("four","");
        element_fireWorkCoache8.setAttribute("five","");
        element_fireWorkCoache8.setAttribute("six","");
        element_fireWorkCoache8.setAttribute("seven","");
        element_fireWorkCoache8.setAttribute("eight","");
        element_fireWorkCoache8.setAttribute("nine","");
        element_fireWorkCoache8.setAttribute("ten","");
        root.appendChild(element_fireWorkCoache8);

        QDomElement element_balanceHeader = doc.createElement("BALANCEINSTABILITYHEADER");
        element_balanceHeader.setAttribute("one","");
        element_balanceHeader.setAttribute("two","");
        element_balanceHeader.setAttribute("three","");
        element_balanceHeader.setAttribute("four","");
        element_balanceHeader.setAttribute("five","");
        element_balanceHeader.setAttribute("six","");
        element_balanceHeader.setAttribute("seven","");
        element_balanceHeader.setAttribute("eight","");
        element_balanceHeader.setAttribute("nine","");
        root.appendChild(element_balanceHeader);

        QDomElement element_balanceColumn = doc.createElement("BALANCEINSTABILITYCOLUMN");
        element_balanceColumn.setAttribute("one","");
        element_balanceColumn.setAttribute("two","");
        element_balanceColumn.setAttribute("three","");
        element_balanceColumn.setAttribute("four","");
        root.appendChild(element_balanceColumn);

        QDomElement element_fireLinkageHeader = doc.createElement("FIRELINKAGEHEADER");
        element_fireLinkageHeader.setAttribute("one","");
        element_fireLinkageHeader.setAttribute("two","");
        element_fireLinkageHeader.setAttribute("three","");
        element_fireLinkageHeader.setAttribute("four","");
        root.appendChild(element_fireLinkageHeader);

        QDomElement element_fireLinkageColmun = doc.createElement("FIRELINKAGECOLUMN");
        element_fireLinkageColmun.setAttribute("one","");
        element_fireLinkageColmun.setAttribute("two","");
        root.appendChild(element_fireLinkageColmun);

        QDomElement element_temperatureAlxeHeader = doc.createElement("TEMPETATUREALXEHEADER");
        element_temperatureAlxeHeader.setAttribute("one","");
        element_temperatureAlxeHeader.setAttribute("two","");
        element_temperatureAlxeHeader.setAttribute("three","");
        element_temperatureAlxeHeader.setAttribute("four","");
        element_temperatureAlxeHeader.setAttribute("five","");
        element_temperatureAlxeHeader.setAttribute("six","");
        element_temperatureAlxeHeader.setAttribute("seven","");
        element_temperatureAlxeHeader.setAttribute("eight","");
        element_temperatureAlxeHeader.setAttribute("nine","");
        root.appendChild(element_temperatureAlxeHeader);

        QDomElement element_temperatureAlxeColmun = doc.createElement("TEMPETATUREALXECOLUMN");
        element_temperatureAlxeColmun.setAttribute("one","");
        element_temperatureAlxeColmun.setAttribute("two","");
        element_temperatureAlxeColmun.setAttribute("three","");
        element_temperatureAlxeColmun.setAttribute("four","");
        element_temperatureAlxeColmun.setAttribute("five","");
        element_temperatureAlxeColmun.setAttribute("six","");
        element_temperatureAlxeColmun.setAttribute("seven","");
        element_temperatureAlxeColmun.setAttribute("eight","");
        root.appendChild(element_temperatureAlxeColmun);

        QDomElement element_temperatureGearHeader = doc.createElement("TEMPETATUREGEARHEADER");
        element_temperatureGearHeader.setAttribute("one","");
        element_temperatureGearHeader.setAttribute("two","");
        element_temperatureGearHeader.setAttribute("three","");
        element_temperatureGearHeader.setAttribute("four","");
        element_temperatureGearHeader.setAttribute("five","");
        element_temperatureGearHeader.setAttribute("six","");
        element_temperatureGearHeader.setAttribute("seven","");
        element_temperatureGearHeader.setAttribute("eight","");
        element_temperatureGearHeader.setAttribute("nine","");
        root.appendChild(element_temperatureGearHeader);

        QDomElement element_temperatureGearColmun = doc.createElement("TEMPETATUREGEARCOLUMN");
        element_temperatureGearColmun.setAttribute("one","");
        element_temperatureGearColmun.setAttribute("two","");
        element_temperatureGearColmun.setAttribute("three","");
        element_temperatureGearColmun.setAttribute("four","");
        element_temperatureGearColmun.setAttribute("five","");
        element_temperatureGearColmun.setAttribute("six","");
        element_temperatureGearColmun.setAttribute("seven","");
        element_temperatureGearColmun.setAttribute("eight","");
        element_temperatureGearColmun.setAttribute("nine","");
        element_temperatureGearColmun.setAttribute("ten","");
        element_temperatureGearColmun.setAttribute("eleven","");
        element_temperatureGearColmun.setAttribute("twelve","");
        element_temperatureGearColmun.setAttribute("triteen","");
        element_temperatureGearColmun.setAttribute("fourteen","");
        element_temperatureGearColmun.setAttribute("fifteen","");
        element_temperatureGearColmun.setAttribute("sixteen","");
        root.appendChild(element_temperatureGearColmun);

        QDomElement element_temperatureMotorHeader = doc.createElement("TEMPETATUREMOTORHEADER");
        element_temperatureMotorHeader.setAttribute("one","");
        element_temperatureMotorHeader.setAttribute("two","");
        element_temperatureMotorHeader.setAttribute("three","");
        element_temperatureMotorHeader.setAttribute("four","");
        element_temperatureMotorHeader.setAttribute("five","");
        element_temperatureMotorHeader.setAttribute("six","");
        element_temperatureMotorHeader.setAttribute("seven","");
        element_temperatureMotorHeader.setAttribute("eight","");
        element_temperatureMotorHeader.setAttribute("nine","");
        root.appendChild(element_temperatureMotorHeader);

        QDomElement element_temperatureMotorColmun = doc.createElement("TEMPETATUREMOTORCOLUMN");
        element_temperatureMotorColmun.setAttribute("one","");
        element_temperatureMotorColmun.setAttribute("two","");
        element_temperatureMotorColmun.setAttribute("three","");
        element_temperatureMotorColmun.setAttribute("four","");
        element_temperatureMotorColmun.setAttribute("five","");
        element_temperatureMotorColmun.setAttribute("six","");
        element_temperatureMotorColmun.setAttribute("seven","");
        element_temperatureMotorColmun.setAttribute("eight","");
        root.appendChild(element_temperatureMotorColmun);

        QDomElement element_temperatureMotorDiningHeader = doc.createElement("TEMPETATUREMOTORDININGHEADER");
        element_temperatureMotorDiningHeader.setAttribute("one","");
        element_temperatureMotorDiningHeader.setAttribute("two","");
        element_temperatureMotorDiningHeader.setAttribute("three","");
        element_temperatureMotorDiningHeader.setAttribute("four","");
        element_temperatureMotorDiningHeader.setAttribute("five","");
        root.appendChild(element_temperatureMotorDiningHeader);

        QDomElement element_temperatureMotorDiningColmun = doc.createElement("TEMPETATUREMOTORDININGCOLUMN");
        element_temperatureMotorDiningColmun.setAttribute("one","");
        element_temperatureMotorDiningColmun.setAttribute("two","");
        element_temperatureMotorDiningColmun.setAttribute("three","");
        element_temperatureMotorDiningColmun.setAttribute("four","");
        element_temperatureMotorDiningColmun.setAttribute("five","");
        element_temperatureMotorDiningColmun.setAttribute("six","");
        element_temperatureMotorDiningColmun.setAttribute("seven","");
        element_temperatureMotorDiningColmun.setAttribute("eight","");
        element_temperatureMotorDiningColmun.setAttribute("nine","");
        element_temperatureMotorDiningColmun.setAttribute("ten","");
        element_temperatureMotorDiningColmun.setAttribute("eleven","");
        element_temperatureMotorDiningColmun.setAttribute("twelve","");
        root.appendChild(element_temperatureMotorDiningColmun);

        if(file.open(QIODevice::WriteOnly | QFile::Text))
        {
            QTextStream out(&file);
            doc.save(out,4);
            file.close();
        }
    }
    else//read the system-related setting
    {
        /****SHEETHEADER Information****/
        QDomNodeList list = doc.elementsByTagName("SHEETHEADERINFO");
        for(int i=0;i<list.length();i++)
        {
            QDomElement e = list.at(i).toElement();
            temperature     = e.attribute("temperature");
            temperatureUnit = e.attribute("temperatureUnit");
            carName         = e.attribute("carName");
            carNumber       = e.attribute("carNumber");
            carSpeed        = e.attribute("carSpeed");
            carSpeedUnit    = e.attribute("carSpeedUnit");
        }

        /****MAINTABLEINFO Information****/
        QDomNodeList maintablelist = doc.elementsByTagName("MAINTABLEINFO");
        for(int i=0;i<maintablelist.length();i++)
        {
            QDomElement e = maintablelist.at(i).toElement();
            mainTableHeader.append(e.attribute("one"));
            mainTableHeader.append(e.attribute("two"));
            mainTableHeader.append(e.attribute("three"));
            mainTableHeader.append(e.attribute("four"));
            mainTableHeader.append(e.attribute("five"));
            mainTableHeader.append(e.attribute("six"));
            mainTableHeader.append(e.attribute("seven"));
        }

        /****RECORDTABLEINFO Information****/
        QDomNodeList recordtablelist = doc.elementsByTagName("RECORDTABLEINFO");
        for(int i=0;i<recordtablelist.length();i++)
        {
            QDomElement e = recordtablelist.at(i).toElement();
            alarmRecordTableHeader.append(e.attribute("one"));
            alarmRecordTableHeader.append(e.attribute("two"));
            alarmRecordTableHeader.append(e.attribute("three"));
            alarmRecordTableHeader.append(e.attribute("four"));
            alarmRecordTableHeader.append(e.attribute("five"));
            alarmRecordTableHeader.append(e.attribute("six"));
            alarmRecordTableHeader.append(e.attribute("seven"));
        }

        /****ROTATEALLTABLEINFO Information****/
        QDomNodeList rotatealltablelist = doc.elementsByTagName("ROTATEALLTABLEINFO");
        for(int i=0;i<rotatealltablelist.length();i++)
        {
            QDomElement e = rotatealltablelist.at(i).toElement();
            rotateAllTableHeader.append(e.attribute("one"));
            rotateAllTableHeader.append(e.attribute("two"));
            rotateAllTableHeader.append(e.attribute("three"));
            rotateAllTableHeader.append(e.attribute("four"));
            rotateAllTableHeader.append(e.attribute("five"));
        }

        /****ROTATEALLTABLECOLUMN Information****/
        QDomNodeList rotateallcolumnlist = doc.elementsByTagName("ROTATEALLTABLECOLUMN");
        for(int i=0;i<rotateallcolumnlist.length();i++)
        {
            QDomElement e = rotateallcolumnlist.at(i).toElement();
            rotateAllTableColunm.append(e.attribute("one"));
            rotateAllTableColunm.append(e.attribute("two"));
            rotateAllTableColunm.append(e.attribute("three"));
            rotateAllTableColunm.append(e.attribute("four"));
            rotateAllTableColunm.append(e.attribute("five"));
            rotateAllTableColunm.append(e.attribute("six"));
            rotateAllTableColunm.append(e.attribute("seven"));
            rotateAllTableColunm.append(e.attribute("eight"));
            rotateAllTableColunm.append(e.attribute("nine"));
            rotateAllTableColunm.append(e.attribute("ten"));
        }

        /****ROTATESINGLETABLEINFO Information****/
        QDomNodeList rotatesingletablelist = doc.elementsByTagName("ROTATESINGLETABLEINFO");
        for(int i=0;i<rotatesingletablelist.length();i++)
        {
            QDomElement e = rotatesingletablelist.at(i).toElement();
            rotateSignleTableHeader.append(e.attribute("one"));
            rotateSignleTableHeader.append(e.attribute("two"));
            rotateSignleTableHeader.append(e.attribute("three"));
            rotateSignleTableHeader.append(e.attribute("four"));
            rotateSignleTableHeader.append(e.attribute("five"));
            rotateSignleTableHeader.append(e.attribute("six"));
            rotateSignleTableHeader.append(e.attribute("seven"));
            rotateSignleTableHeader.append(e.attribute("eight"));
            rotateSignleTableHeader.append(e.attribute("nine"));
        }

        /****ROTATESINGLETABLECOLUMN Information****/
        QDomNodeList rotatealxecolumnlist = doc.elementsByTagName("ROTATEALXETABLECOLUMN");
        for(int i=0;i<rotatealxecolumnlist.length();i++)
        {
            QDomElement e = rotatealxecolumnlist.at(i).toElement();
            rotateAlxeboxTableColunm.append(e.attribute("one"));
            rotateAlxeboxTableColunm.append(e.attribute("two"));
            rotateAlxeboxTableColunm.append(e.attribute("three"));
            rotateAlxeboxTableColunm.append(e.attribute("four"));
            rotateAlxeboxTableColunm.append(e.attribute("five"));
            rotateAlxeboxTableColunm.append(e.attribute("six"));
            rotateAlxeboxTableColunm.append(e.attribute("seven"));
            rotateAlxeboxTableColunm.append(e.attribute("eight"));
            rotateAlxeboxTableColunm.append(e.attribute("nine"));
            rotateAlxeboxTableColunm.append(e.attribute("ten"));
            rotateAlxeboxTableColunm.append(e.attribute("eleven"));
            rotateAlxeboxTableColunm.append(e.attribute("twelve"));
            rotateAlxeboxTableColunm.append(e.attribute("triteen"));
            rotateAlxeboxTableColunm.append(e.attribute("fourteen"));
            rotateAlxeboxTableColunm.append(e.attribute("fifteen"));
            rotateAlxeboxTableColunm.append(e.attribute("sixteen"));
        }


        /****ROTATEGEARTABLECOLUMN Information****/
        QDomNodeList rotategearcolumnlist = doc.elementsByTagName("ROTATEGEARTABLECOLUMN");
        for(int i=0;i<rotategearcolumnlist.length();i++)
        {
            QDomElement e = rotategearcolumnlist.at(i).toElement();
            rotateGearboxTableColunm.append(e.attribute("one"));
            rotateGearboxTableColunm.append(e.attribute("two"));
            rotateGearboxTableColunm.append(e.attribute("three"));
            rotateGearboxTableColunm.append(e.attribute("four"));
            rotateGearboxTableColunm.append(e.attribute("five"));
            rotateGearboxTableColunm.append(e.attribute("six"));
            rotateGearboxTableColunm.append(e.attribute("seven"));
            rotateGearboxTableColunm.append(e.attribute("eight"));
            rotateGearboxTableColunm.append(e.attribute("nine"));
            rotateGearboxTableColunm.append(e.attribute("ten"));
            rotateGearboxTableColunm.append(e.attribute("eleven"));
            rotateGearboxTableColunm.append(e.attribute("twelve"));
            rotateGearboxTableColunm.append(e.attribute("triteen"));
            rotateGearboxTableColunm.append(e.attribute("fourteen"));
            rotateGearboxTableColunm.append(e.attribute("fifteen"));
            rotateGearboxTableColunm.append(e.attribute("sixteen"));
        }

        /****ROTATEMOTORTABLECOLUMN Information****/
        QDomNodeList rotatemotorcolumnlist = doc.elementsByTagName("ROTATEMOTORTABLECOLUMN");
        for(int i=0;i<rotatemotorcolumnlist.length();i++)
        {
            QDomElement e = rotatemotorcolumnlist.at(i).toElement();
            rotateMotorTableColunm.append(e.attribute("one"));
            rotateMotorTableColunm.append(e.attribute("two"));
            rotateMotorTableColunm.append(e.attribute("three"));
            rotateMotorTableColunm.append(e.attribute("four"));
            rotateMotorTableColunm.append(e.attribute("five"));
            rotateMotorTableColunm.append(e.attribute("six"));
            rotateMotorTableColunm.append(e.attribute("seven"));
            rotateMotorTableColunm.append(e.attribute("eight"));
        }

        /****FIREWORKHEADER Information****/
        QDomNodeList fireWorkHeaderlist = doc.elementsByTagName("FIREWORKHEADER");
        for(int i=0;i<fireWorkHeaderlist.length();i++)
        {
            QDomElement e = fireWorkHeaderlist.at(i).toElement();
            fireWorkTableHeader.append(e.attribute("one"));
            fireWorkTableHeader.append(e.attribute("two"));
            fireWorkTableHeader.append(e.attribute("three"));
            fireWorkTableHeader.append(e.attribute("four"));
            fireWorkTableHeader.append(e.attribute("five"));
            fireWorkTableHeader.append(e.attribute("six"));
        }

        /****FIREWORKCOACH1 Information****/
        QDomNodeList fireWorkCoache1list = doc.elementsByTagName("FIREWORKCOACH1");
        for(int i=0;i<fireWorkCoache1list.length();i++)
        {
            QDomElement e = fireWorkCoache1list.at(i).toElement();
            fireWorkCoache1.append(e.attribute("one"));
            fireWorkCoache1.append(e.attribute("two"));
            fireWorkCoache1.append(e.attribute("three"));
            fireWorkCoache1.append(e.attribute("four"));
            fireWorkCoache1.append(e.attribute("five"));
            fireWorkCoache1.append(e.attribute("six"));
            fireWorkCoache1.append(e.attribute("seven"));
            fireWorkCoache1.append(e.attribute("eight"));
            fireWorkCoache1.append(e.attribute("nine"));
            fireWorkCoache1.append(e.attribute("ten"));
        }

        /****FIREWORKCOACH2 Information****/
        QDomNodeList fireWorkCoache2list = doc.elementsByTagName("FIREWORKCOACH2");
        for(int i=0;i<fireWorkCoache2list.length();i++)
        {
            QDomElement e = fireWorkCoache2list.at(i).toElement();
            fireWorkCoache2.append(e.attribute("one"));
            fireWorkCoache2.append(e.attribute("two"));
            fireWorkCoache2.append(e.attribute("three"));
            fireWorkCoache2.append(e.attribute("four"));
            fireWorkCoache2.append(e.attribute("five"));
            fireWorkCoache2.append(e.attribute("six"));
            fireWorkCoache2.append(e.attribute("seven"));
            fireWorkCoache2.append(e.attribute("eight"));
            fireWorkCoache2.append(e.attribute("nine"));
        }

        /****FIREWORKCOACH3 Information****/
        QDomNodeList fireWorkCoache3list = doc.elementsByTagName("FIREWORKCOACH3");
        for(int i=0;i<fireWorkCoache3list.length();i++)
        {
            QDomElement e = fireWorkCoache3list.at(i).toElement();
            fireWorkCoache3.append(e.attribute("one"));
            fireWorkCoache3.append(e.attribute("two"));
            fireWorkCoache3.append(e.attribute("three"));
            fireWorkCoache3.append(e.attribute("four"));
            fireWorkCoache3.append(e.attribute("five"));
            fireWorkCoache3.append(e.attribute("six"));
            fireWorkCoache3.append(e.attribute("seven"));
            fireWorkCoache3.append(e.attribute("eight"));
        }

        /****FIREWORKCOACH4 Information****/
        QDomNodeList fireWorkCoache4list = doc.elementsByTagName("FIREWORKCOACH4");
        for(int i=0;i<fireWorkCoache4list.length();i++)
        {
            QDomElement e = fireWorkCoache4list.at(i).toElement();
            fireWorkCoache4.append(e.attribute("one"));
            fireWorkCoache4.append(e.attribute("two"));
            fireWorkCoache4.append(e.attribute("three"));
            fireWorkCoache4.append(e.attribute("four"));
            fireWorkCoache4.append(e.attribute("five"));
            fireWorkCoache4.append(e.attribute("six"));
            fireWorkCoache4.append(e.attribute("seven"));
            fireWorkCoache4.append(e.attribute("eight"));
            fireWorkCoache4.append(e.attribute("nine"));
        }

        /****FIREWORKCOACH5 Information****/
        QDomNodeList fireWorkCoache5list = doc.elementsByTagName("FIREWORKCOACH5");
        for(int i=0;i<fireWorkCoache5list.length();i++)
        {
            QDomElement e = fireWorkCoache5list.at(i).toElement();
            fireWorkCoache5.append(e.attribute("one"));
            fireWorkCoache5.append(e.attribute("two"));
            fireWorkCoache5.append(e.attribute("three"));
            fireWorkCoache5.append(e.attribute("four"));
            fireWorkCoache5.append(e.attribute("five"));
            fireWorkCoache5.append(e.attribute("six"));
            fireWorkCoache5.append(e.attribute("seven"));
            fireWorkCoache5.append(e.attribute("eight"));
        }

        /****FIREWORKCOACH6 Information****/
        QDomNodeList fireWorkCoache6list = doc.elementsByTagName("FIREWORKCOACH6");
        for(int i=0;i<fireWorkCoache6list.length();i++)
        {
            QDomElement e = fireWorkCoache6list.at(i).toElement();
            fireWorkCoache6.append(e.attribute("one"));
            fireWorkCoache6.append(e.attribute("two"));
            fireWorkCoache6.append(e.attribute("three"));
            fireWorkCoache6.append(e.attribute("four"));
            fireWorkCoache6.append(e.attribute("five"));
            fireWorkCoache6.append(e.attribute("six"));
            fireWorkCoache6.append(e.attribute("seven"));
            fireWorkCoache6.append(e.attribute("eight"));
        }

        /****FIREWORKCOACH7 Information****/
        QDomNodeList fireWorkCoache7list = doc.elementsByTagName("FIREWORKCOACH7");
        for(int i=0;i<fireWorkCoache7list.length();i++)
        {
            QDomElement e = fireWorkCoache7list.at(i).toElement();
            fireWorkCoache7.append(e.attribute("one"));
            fireWorkCoache7.append(e.attribute("two"));
            fireWorkCoache7.append(e.attribute("three"));
            fireWorkCoache7.append(e.attribute("four"));
            fireWorkCoache7.append(e.attribute("five"));
            fireWorkCoache7.append(e.attribute("six"));
            fireWorkCoache7.append(e.attribute("seven"));
            fireWorkCoache7.append(e.attribute("eight"));
            fireWorkCoache7.append(e.attribute("nine"));
        }

        /****FIREWORKCOACH8 Information****/
        QDomNodeList fireWorkCoache8list = doc.elementsByTagName("FIREWORKCOACH8");
        for(int i=0;i<fireWorkCoache8list.length();i++)
        {
            QDomElement e = fireWorkCoache8list.at(i).toElement();
            fireWorkCoache8.append(e.attribute("one"));
            fireWorkCoache8.append(e.attribute("two"));
            fireWorkCoache8.append(e.attribute("three"));
            fireWorkCoache8.append(e.attribute("four"));
            fireWorkCoache8.append(e.attribute("five"));
            fireWorkCoache8.append(e.attribute("six"));
            fireWorkCoache8.append(e.attribute("seven"));
            fireWorkCoache8.append(e.attribute("eight"));
            fireWorkCoache8.append(e.attribute("nine"));
            fireWorkCoache8.append(e.attribute("ten"));
        }

        /****BALANCEINSTABILITYHEADER Information****/
        QDomNodeList balanceHeaderList = doc.elementsByTagName("BALANCEINSTABILITYHEADER");
        for(int i=0;i<balanceHeaderList.length();i++)
        {
            QDomElement e = balanceHeaderList.at(i).toElement();
            balanceInstabilityTableHeader.append(e.attribute("one"));
            balanceInstabilityTableHeader.append(e.attribute("two"));
            balanceInstabilityTableHeader.append(e.attribute("three"));
            balanceInstabilityTableHeader.append(e.attribute("four"));
            balanceInstabilityTableHeader.append(e.attribute("five"));
            balanceInstabilityTableHeader.append(e.attribute("six"));
            balanceInstabilityTableHeader.append(e.attribute("seven"));
            balanceInstabilityTableHeader.append(e.attribute("eight"));
            balanceInstabilityTableHeader.append(e.attribute("nine"));
        }

        /****BALANCEINSTABILITYCOLUMN Information****/
        QDomNodeList balanceColumnList = doc.elementsByTagName("BALANCEINSTABILITYCOLUMN");
        for(int i=0;i<balanceColumnList.length();i++)
        {
            QDomElement e = balanceColumnList.at(i).toElement();
            balanceInstabilityColumn.append(e.attribute("one"));
            balanceInstabilityColumn.append(e.attribute("two"));
            balanceInstabilityColumn.append(e.attribute("three"));
            balanceInstabilityColumn.append(e.attribute("four"));
        }

        /****FIREWORKCOACH8 Information****/
        QDomNodeList fireLinkageHeaderList = doc.elementsByTagName("FIRELINKAGEHEADER");
        for(int i=0;i<fireLinkageHeaderList.length();i++)
        {
            QDomElement e = fireLinkageHeaderList.at(i).toElement();
            fireLinkageTableHeader.append(e.attribute("one"));
            fireLinkageTableHeader.append(e.attribute("two"));
            fireLinkageTableHeader.append(e.attribute("three"));
            fireLinkageTableHeader.append(e.attribute("four"));
        }

        /****FIRELINKAGECOLUMN Information****/
        QDomNodeList fireLinkageColumnList = doc.elementsByTagName("FIRELINKAGECOLUMN");
        for(int i=0;i<fireLinkageColumnList.length();i++)
        {
            QDomElement e = fireLinkageColumnList.at(i).toElement();
            fireLinkageColumn.append(e.attribute("one"));
            fireLinkageColumn.append(e.attribute("two"));
        }

        /****TEMPETATUREALXEHEADER Information****/
        QDomNodeList temperatureAlxeHeaderList = doc.elementsByTagName("TEMPETATUREALXEHEADER");
        for(int i=0;i<temperatureAlxeHeaderList.length();i++)
        {
            QDomElement e = temperatureAlxeHeaderList.at(i).toElement();
            temperatureAlxeboxTableHeader.append(e.attribute("one"));
            temperatureAlxeboxTableHeader.append(e.attribute("two"));
            temperatureAlxeboxTableHeader.append(e.attribute("three"));
            temperatureAlxeboxTableHeader.append(e.attribute("four"));
            temperatureAlxeboxTableHeader.append(e.attribute("five"));
            temperatureAlxeboxTableHeader.append(e.attribute("six"));
            temperatureAlxeboxTableHeader.append(e.attribute("seven"));
            temperatureAlxeboxTableHeader.append(e.attribute("eight"));
            temperatureAlxeboxTableHeader.append(e.attribute("nine"));
        }

        /****TEMPETATUREALXECOLUMN Information****/
        QDomNodeList temperatureAlxeColumnList = doc.elementsByTagName("TEMPETATUREALXECOLUMN");
        for(int i=0;i<temperatureAlxeColumnList.length();i++)
        {
            QDomElement e = temperatureAlxeColumnList.at(i).toElement();
            temperatureAlxeboxTableColunm.append(e.attribute("one"));
            temperatureAlxeboxTableColunm.append(e.attribute("two"));
            temperatureAlxeboxTableColunm.append(e.attribute("three"));
            temperatureAlxeboxTableColunm.append(e.attribute("four"));
            temperatureAlxeboxTableColunm.append(e.attribute("five"));
            temperatureAlxeboxTableColunm.append(e.attribute("six"));
            temperatureAlxeboxTableColunm.append(e.attribute("seven"));
            temperatureAlxeboxTableColunm.append(e.attribute("eight"));
        }

        /****TEMPETATUREGEARHEADER Information****/
        QDomNodeList temperatureGearHeaderList = doc.elementsByTagName("TEMPETATUREGEARHEADER");
        for(int i=0;i<temperatureGearHeaderList.length();i++)
        {
            QDomElement e = temperatureGearHeaderList.at(i).toElement();
            temperatureGearboxTableHeader.append(e.attribute("one"));
            temperatureGearboxTableHeader.append(e.attribute("two"));
            temperatureGearboxTableHeader.append(e.attribute("three"));
            temperatureGearboxTableHeader.append(e.attribute("four"));
            temperatureGearboxTableHeader.append(e.attribute("five"));
            temperatureGearboxTableHeader.append(e.attribute("six"));
            temperatureGearboxTableHeader.append(e.attribute("seven"));
            temperatureGearboxTableHeader.append(e.attribute("eight"));
            temperatureGearboxTableHeader.append(e.attribute("nine"));
        }

        /****TEMPETATUREGEARCOLUMN Information****/
        QDomNodeList temperatureGearColumnList = doc.elementsByTagName("TEMPETATUREGEARCOLUMN");
        for(int i=0;i<temperatureGearColumnList.length();i++)
        {
            QDomElement e = temperatureGearColumnList.at(i).toElement();
            temperatureGearboxTableColunm.append(e.attribute("one"));
            temperatureGearboxTableColunm.append(e.attribute("two"));
            temperatureGearboxTableColunm.append(e.attribute("three"));
            temperatureGearboxTableColunm.append(e.attribute("four"));
            temperatureGearboxTableColunm.append(e.attribute("five"));
            temperatureGearboxTableColunm.append(e.attribute("six"));
            temperatureGearboxTableColunm.append(e.attribute("seven"));
            temperatureGearboxTableColunm.append(e.attribute("eight"));
            temperatureGearboxTableColunm.append(e.attribute("nine"));
            temperatureGearboxTableColunm.append(e.attribute("ten"));
            temperatureGearboxTableColunm.append(e.attribute("eleven"));
            temperatureGearboxTableColunm.append(e.attribute("twelve"));
            temperatureGearboxTableColunm.append(e.attribute("triteen"));
            temperatureGearboxTableColunm.append(e.attribute("fourteen"));
            temperatureGearboxTableColunm.append(e.attribute("fifteen"));
            temperatureGearboxTableColunm.append(e.attribute("sixteen"));
        }

        /****TEMPETATUREMOTORHEADER Information****/
        QDomNodeList temperatureMotorHeaderList = doc.elementsByTagName("TEMPETATUREMOTORHEADER");
        for(int i=0;i<temperatureMotorHeaderList.length();i++)
        {
            QDomElement e = temperatureMotorHeaderList.at(i).toElement();
            temperatureMotorTableHeader.append(e.attribute("one"));
            temperatureMotorTableHeader.append(e.attribute("two"));
            temperatureMotorTableHeader.append(e.attribute("three"));
            temperatureMotorTableHeader.append(e.attribute("four"));
            temperatureMotorTableHeader.append(e.attribute("five"));
            temperatureMotorTableHeader.append(e.attribute("six"));
            temperatureMotorTableHeader.append(e.attribute("seven"));
            temperatureMotorTableHeader.append(e.attribute("eight"));
            temperatureMotorTableHeader.append(e.attribute("nine"));
        }

        /****TEMPETATUREMOTORCOLUMN Information****/
        QDomNodeList temperatureMotorColumnList = doc.elementsByTagName("TEMPETATUREMOTORCOLUMN");
        for(int i=0;i<temperatureMotorColumnList.length();i++)
        {
            QDomElement e = temperatureMotorColumnList.at(i).toElement();
            temperatureMotorTableColunm.append(e.attribute("one"));
            temperatureMotorTableColunm.append(e.attribute("two"));
            temperatureMotorTableColunm.append(e.attribute("three"));
            temperatureMotorTableColunm.append(e.attribute("four"));
            temperatureMotorTableColunm.append(e.attribute("five"));
            temperatureMotorTableColunm.append(e.attribute("six"));
            temperatureMotorTableColunm.append(e.attribute("seven"));
            temperatureMotorTableColunm.append(e.attribute("eight"));
        }

        /****TEMPETATUREMOTORDININGHEADER Information****/
        QDomNodeList temperatureMotorDiningHeaderList = doc.elementsByTagName("TEMPETATUREMOTORDININGHEADER");
        for(int i=0;i<temperatureMotorDiningHeaderList.length();i++)
        {
            QDomElement e = temperatureMotorDiningHeaderList.at(i).toElement();
            temperatureMotorAndDiningTableHeader.append(e.attribute("one"));
            temperatureMotorAndDiningTableHeader.append(e.attribute("two"));
            temperatureMotorAndDiningTableHeader.append(e.attribute("three"));
            temperatureMotorAndDiningTableHeader.append(e.attribute("four"));
            temperatureMotorAndDiningTableHeader.append(e.attribute("five"));
        }

        /****TEMPETATUREMOTORDININGCOLUMN Information****/
        QDomNodeList temperatureMotorDiningColumnList = doc.elementsByTagName("TEMPETATUREMOTORDININGCOLUMN");
        for(int i=0;i<temperatureMotorDiningColumnList.length();i++)
        {
            QDomElement e = temperatureMotorDiningColumnList.at(i).toElement();
            temperatureMotorAndDiningTableColunm.append(e.attribute("one"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("two"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("three"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("four"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("five"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("six"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("seven"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("eight"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("nine"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("ten"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("eleven"));
            temperatureMotorAndDiningTableColunm.append(e.attribute("twelve"));
        }
    }
}
//get Sum Page
QString Widget::getSumPage()
{
    int ret =0;
    int tem =0;
    int rowCount = mainTable->model()->rowCount();//��ǰ����
    //int rowHeight = mainTable->rowHeight(0);//ÿ���и�
    int rowHeight = 45;//ÿ���и�
    int tableViewHeight = mainTable->height();//�����ܸ߶�
    int rowCountPerPage = tableViewHeight/rowHeight-1;//ÿҳ��ʾ����
    if(rowCountPerPage != 0){
        ret = rowCount/rowCountPerPage;//��ҳ��
        tem = rowCount%rowCountPerPage;
    }
    if (tem != 0)
    {
        ret = ret+1;
    }
    QString sumpage = QString::number(ret,10);
    return sumpage;
}
//get Record SumPage
QString Widget::getRecordSumPage()
{
    int ret =0;
    int tem =0;
    int rowCount = alarmRecordTable->model()->rowCount();//��ǰ����
    int rowHeight = alarmRecordTable->rowHeight(0);//ÿ���и�
    int tableViewHeight = alarmRecordTable->height();//�����ܸ߶�
    int rowCountPerPage = tableViewHeight/rowHeight-1;//ÿҳ��ʾ����
    if(rowCountPerPage != 0){
        ret = rowCount/rowCountPerPage;//��ҳ��
        tem = rowCount%rowCountPerPage;
    }
    if (tem != 0)
    {
        ret = ret+1;
    }
    QString sumpage = QString::number(ret,10);
    return sumpage;
}
//mainPage DisplayFaultAndAlarm
void Widget::mainPageDisplayFaultAndAlarm(int Type)
{
    QList<R_SQLData> rdate;
    rdate.clear();

    if(Type == FaultQuery){
        Sql_mutex.lock();
        sqlLink->GetSQLData(Type); //read from SQL to get al the type of data. HJ or GZ
        rdate = sqlLink->R_Data;
        Sql_mutex.unlock();
        if(rdate.count()>0)
            bHavedata = true;
    }else if(Type == FaultHistory){
        Sql_mutex.lock();
        sqlLink->GetSQLData(Type); //read from SQL to get al the type of data. HJ or GZ
        rdate = sqlLink->R_Data;
        Sql_mutex.unlock();
        if(rdate.count()>0)
            bHavedata = true;
    }

    if(bHavedata){
        if(Type == FaultQuery){
            iCount = rdate.count();
            mainPageSumItem->setText("��������"+QString::number(iCount,10));

            while(mainTable->rowCount()>0){
                mainTable->removeRow(0);
            }
            //mainTable->setRowCount(0);

            for(int i = 0; i < iCount; i++)
            {
                mainTable->insertRow(0);
                mainTable->setItem(0,0,new QTableWidgetItem(QString::number(i+1,10)));
                mainTable->setItem(0,1,new QTableWidgetItem("400"));
                mainTable->setItem(0,2,new QTableWidgetItem(QString::number(rdate.at(i).CarNo,10)));
                mainTable->setItem(0,3,new QTableWidgetItem(rdate.at(i).deviceType+" "+rdate.at(i).SensorType+" "+rdate.at(i).ErrorType));
                mainTable->setItem(0,4,new QTableWidgetItem(QString::number(rdate.at(i).i_ErrorNo,10)));
                mainTable->setItem(0,5,new QTableWidgetItem(rdate.at(i).StarTime));
                mainTable->setItem(0,6,new QTableWidgetItem(rdate.at(i).EndTime));
                mainTable->item(0,0)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,0)->setTextAlignment(Qt::AlignCenter);
                mainTable->item(0,1)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,1)->setTextAlignment(Qt::AlignCenter);
                mainTable->item(0,2)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,2)->setTextAlignment(Qt::AlignCenter);
                mainTable->item(0,3)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,3)->setTextAlignment(Qt::AlignCenter);
                mainTable->item(0,4)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,4)->setTextAlignment(Qt::AlignCenter);
                mainTable->item(0,5)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,5)->setTextAlignment(Qt::AlignCenter);
                mainTable->item(0,6)->setBackgroundColor(QColor(255,170,0));
                mainTable->item(0,6)->setTextAlignment(Qt::AlignCenter);
                labelCurrentAlarm->setText("��ǰ����:"+ QString::number(rdate.at(i).CarNo,10) +rdate.at(i).deviceType+" "+rdate.at(i).SensorType+" "+rdate.at(i).ErrorType);
            }
            QString mainsumpage = getSumPage();
            mainPageSumPage->setText("�� "+mainsumpage+" ҳ");
            QString mainButtonErrorStyle = "QPushButton{border:3px solid green;border-radius:5px;color: rgb(255, 255, 255); background: rgb(255, 0, 0);font: 75 14pt ;font-family: ����;}";
            mainNavigationMainInterfaceButton->setStyleSheet(mainButtonErrorStyle);
        }else if(Type == FaultHistory){
            iCount = rdate.count();
            recordPageSumItem->setText("��������"+QString::number(iCount,10));

#ifdef Debug
            qDebug()<<"--rdate.count--"+QString::number(iCount,10);
#endif

            writeLog("FaultHistory sumItem --- " + QString::number(iCount,10));

            for(int i = 0; i < iCount; i++)
            {
                alarmRecordTable->insertRow(0);
                qDebug()<<"--i-- : " + QString::number(i+1,10);
                alarmRecordTable->setItem(0,0,new QTableWidgetItem(QString::number(i+1,10)));
                qDebug()<<"--1-- : " + QString::number(400,10);
                alarmRecordTable->setItem(0,1,new QTableWidgetItem(QString::number(400,10)));
                qDebug()<<"--2-- : " + QString::number(rdate.at(i).CarNo,10);
                alarmRecordTable->setItem(0,2,new QTableWidgetItem(QString::number(rdate.at(i).CarNo,10)));
                qDebug()<<"--3-- : " + rdate.at(i).deviceType+" "+rdate.at(i).SensorType+" "+rdate.at(i).ErrorType;
                alarmRecordTable->setItem(0,3,new QTableWidgetItem(rdate.at(i).deviceType+" "+rdate.at(i).SensorType+" "+rdate.at(i).ErrorType));
                qDebug()<<"--4-- : " + QString::number(rdate.at(i).i_ErrorNo,10);
                alarmRecordTable->setItem(0,4,new QTableWidgetItem(QString::number(rdate.at(i).i_ErrorNo,10)));
                qDebug()<<"--5-- : " + rdate.at(i).StarTime;
                alarmRecordTable->setItem(0,5,new QTableWidgetItem(rdate.at(i).StarTime));
                qDebug()<<"--6-- : " + rdate.at(i).EndTime;
                alarmRecordTable->setItem(0,6,new QTableWidgetItem(rdate.at(i).EndTime));
                alarmRecordTable->item(0,0)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,0)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,0)->setFlags(Qt::NoItemFlags);
                alarmRecordTable->item(0,1)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,1)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,1)->setFlags(Qt::NoItemFlags);
                alarmRecordTable->item(0,2)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,2)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,2)->setFlags(Qt::NoItemFlags);
                alarmRecordTable->item(0,3)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,3)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,3)->setFlags(Qt::NoItemFlags);
                alarmRecordTable->item(0,4)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,4)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,4)->setFlags(Qt::NoItemFlags);
                alarmRecordTable->item(0,5)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,5)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,5)->setFlags(Qt::NoItemFlags);
                alarmRecordTable->item(0,6)->setBackgroundColor(QColor(255,170,0));
                alarmRecordTable->item(0,6)->setTextAlignment(Qt::AlignCenter);
                alarmRecordTable->item(0,6)->setFlags(Qt::NoItemFlags);
            }
#ifdef Debug
            qDebug()<<"FaultHistory Loading Succeed !";
#endif
            writeLog("FaultHistory Loading Succeed ! ");
            QString sumpage = getRecordSumPage();
            recordPageSumPage->setText("�� "+sumpage+" ҳ");
            RefreshThread.stop = true;
            writeLog("HeartBeatTimerThread Start ! ");
#ifdef Debug
            qDebug()<<"HeartBeatTimerThread Start ! ";
#endif
            udpSocket->heartBeatTimerThread->start();
            emit    initOffLineSignal();
        }
    }else{
        if(Type == FaultHistory){
            RefreshThread.stop = true;
            writeLog("HeartBeatTimerThread Loading Succeed ! ");
            udpSocket->heartBeatTimerThread->start();
            emit    initOffLineSignal();
        }
    }
}
//fireWorkCoache ButtonClicked
void Widget::fireWorkCoache1PushButtonClicked()
{
    if(currentFireWorkCoache == 1 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 1;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("01");
        fireWorkButton1->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache1Table->show();
    }
}
void Widget::fireWorkCoache2PushButtonClicked()
{
    if(currentFireWorkCoache == 2 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 2;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("02");
        fireWorkButton2->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache2Table->show();
    }
}
void Widget::fireWorkCoache3PushButtonClicked()
{
    if(currentFireWorkCoache == 3 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 3;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("03");
        fireWorkButton3->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache3Table->show();
    }
}
void Widget::fireWorkCoache4PushButtonClicked()
{
    if(currentFireWorkCoache == 4 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 4;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("04");
        fireWorkButton4->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache4Table->show();
    }
}
void Widget::fireWorkCoache5PushButtonClicked()
{
    if(currentFireWorkCoache == 5 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 5;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("05");
        fireWorkButton5->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache5Table->show();
    }
}
void Widget::fireWorkCoache6PushButtonClicked()
{
    if(currentFireWorkCoache == 6 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 6;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("06");
        fireWorkButton6->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache6Table->show();
    }
}
void Widget::fireWorkCoache7PushButtonClicked()
{
    if(currentFireWorkCoache == 7 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 7;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("07");
        fireWorkButton7->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache7Table->show();
    }
}
void Widget::fireWorkCoache8PushButtonClicked()
{
    if(currentFireWorkCoache == 8 && fireWorkCoacheClickedStatue == true){
        currentFireWorkCoache = 0;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCoacheClickedStatue = false;
        fireWorkCurrentCoacheNum->setText("00");
    }
    else {
        currentFireWorkCoache = 8;
        fireWorkButtonUnclickedRelease();
        releaseFireWorkTable();
        fireWorkCurrentCoacheNum->setText("08");
        fireWorkButton8->setStyleSheet(navigationButtonClickedStyle);
        fireWorkCoacheClickedStatue = true;
        fireWorkCoache8Table->show();
    }
}
//fireWorkReturn PushButtonClicked
void Widget::fireWorkReturnPushButtonClicked()
{
    navigationButtonRelease();
    fireWorkReturn->setStyleSheet(navigationButtonClickedStyle);
    stackedWidgetNavigation->setCurrentIndex(0);
    mainNavigationMainInterfaceButtonClicked();
}
//fireWorkCoacheTable ReceiveData
void Widget::fireWorkCoache1TableReceiveData(int index)
{
    if(index != 0)
    {
        return;
    }
    for(int i=0;i<10;i++)
    {
        fireWorkCoache1Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache1Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache1Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache1Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache1Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache1Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache1Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache1Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache1Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache1Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache1Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache1Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache1Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache1Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache1Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache1Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache1Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache1Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache1Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache1Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache2TableReceiveData(int index)
{
    if(index != 1)
    {
        return;
    }
    for(int i=0;i<8;i++)
    {
        fireWorkCoache2Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache2Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache2Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache2Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache2Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache2Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache2Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache2Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache2Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache2Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache2Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache2Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache2Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache2Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache2Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache2Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache2Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache2Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache2Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache2Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
    fireWorkCoache2Table->setItem(8,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[0].i_LHD)));
    fireWorkCoache2Table->item(8,3)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache2Table->item(8,3)->setFlags(Qt::NoItemFlags);
    fireWorkCoache2Table->setItem(8,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].YHVersion));
    fireWorkCoache2Table->item(8,5)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache2Table->item(8,5)->setFlags(Qt::NoItemFlags);
    fireWorkCoache2Table->setItem(8,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS));
    if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache2Table->item(8,4)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache2Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache2Table->item(8,4)->setBackgroundColor(QColor(255,0,0));
        fireWorkCoache2Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache2Table->item(8,4)->setBackgroundColor(QColor(255,255,0));
        fireWorkCoache2Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache2Table->item(8,4)->setBackgroundColor(QColor(255,85,127));
        fireWorkCoache2Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache3TableReceiveData(int index)
{
    if(index != 2)
    {
        return;
    }
    for(int i=0;i<8;i++)
    {
        fireWorkCoache3Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache3Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache3Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache3Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache3Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache3Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache3Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache3Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache3Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache3Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache3Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache3Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache3Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache3Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache3Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache3Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache3Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache3Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache3Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache3Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache4TableReceiveData(int index)
{
    if(index != 3)
    {
        return;
    }
    for(int i=0;i<8;i++)
    {
        fireWorkCoache4Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache4Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache4Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache4Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache4Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache4Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache4Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache4Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache4Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache4Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache4Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache4Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache4Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache4Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache4Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache4Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache4Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache4Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache4Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache4Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
    fireWorkCoache4Table->setItem(8,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[0].i_LHD)));
    fireWorkCoache4Table->item(8,3)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache4Table->item(8,3)->setFlags(Qt::NoItemFlags);
    fireWorkCoache4Table->setItem(8,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].YHVersion));
    fireWorkCoache4Table->item(8,5)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache4Table->item(8,5)->setFlags(Qt::NoItemFlags);
    fireWorkCoache4Table->setItem(8,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS));
    if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache4Table->item(8,4)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache4Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache4Table->item(8,4)->setBackgroundColor(QColor(255,0,0));
        fireWorkCoache4Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache4Table->item(8,4)->setBackgroundColor(QColor(255,255,0));
        fireWorkCoache4Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache4Table->item(8,4)->setBackgroundColor(QColor(255,85,127));
        fireWorkCoache4Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache5TableReceiveData(int index)
{
    if(index != 4)
    {
        return;
    }
    for(int i=0;i<7;i++)
    {
        fireWorkCoache5Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache5Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache5Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache5Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache5Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache5Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache5Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache5Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache5Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache5Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache5Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache5Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache5Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache5Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache5Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache5Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache5Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache5Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache5Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache5Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
    fireWorkCoache5Table->setItem(7,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[0].i_LHD)));
    fireWorkCoache5Table->item(7,3)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache5Table->item(7,3)->setFlags(Qt::NoItemFlags);
    fireWorkCoache5Table->setItem(7,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].YHVersion));
    fireWorkCoache5Table->item(7,5)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache5Table->item(7,5)->setFlags(Qt::NoItemFlags);
    fireWorkCoache5Table->setItem(7,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS));
    if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache5Table->item(7,4)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache5Table->item(7,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache5Table->item(7,4)->setBackgroundColor(QColor(255,0,0));
        fireWorkCoache5Table->item(7,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache5Table->item(7,4)->setBackgroundColor(QColor(255,255,0));
        fireWorkCoache5Table->item(7,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache5Table->item(7,4)->setBackgroundColor(QColor(255,85,127));
        fireWorkCoache5Table->item(7,4)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache6TableReceiveData(int index)
{
    if(index != 5)
    {
        return;
    }
    for(int i=0;i<8;i++)
    {
        fireWorkCoache6Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache6Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache6Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache6Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache6Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache6Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache6Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache6Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache6Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache6Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache6Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache6Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache6Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache6Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache6Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache6Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache6Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache6Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache6Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache6Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache7TableReceiveData(int index)
{
    if(index != 6)
    {
        return;
    }
    for(int i=0;i<8;i++)
    {
        fireWorkCoache7Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache7Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache7Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache7Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache7Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache7Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache7Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache7Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache7Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache7Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache7Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache7Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache7Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache7Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache7Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache7Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache7Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache7Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache7Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache7Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
    fireWorkCoache7Table->setItem(8,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[0].i_LHD)));
    fireWorkCoache7Table->item(8,3)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache7Table->item(8,3)->setFlags(Qt::NoItemFlags);
    fireWorkCoache7Table->setItem(8,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].YHVersion));
    fireWorkCoache7Table->item(8,5)->setBackgroundColor(QColor(0,255,0));
    fireWorkCoache7Table->item(8,5)->setFlags(Qt::NoItemFlags);
    fireWorkCoache7Table->setItem(8,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS));
    if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache7Table->item(8,4)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache7Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache7Table->item(8,4)->setBackgroundColor(QColor(255,0,0));
        fireWorkCoache7Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache7Table->item(8,4)->setBackgroundColor(QColor(255,255,0));
        fireWorkCoache7Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
    else if(udpSocket->coacheList[index].sensoryh[0].yanHuoLHDSS=="����")
    {
        fireWorkCoache7Table->item(8,4)->setBackgroundColor(QColor(255,85,127));
        fireWorkCoache7Table->item(8,4)->setFlags(Qt::NoItemFlags);
    }
}
void Widget::fireWorkCoache8TableReceiveData(int index)
{
    if(index != 7)
    {
        return;
    }
    for(int i=0;i<10;i++)
    {
        fireWorkCoache8Table->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_yanWuNongDu)));
        fireWorkCoache8Table->item(i,1)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache8Table->item(i,1)->setFlags(Qt::NoItemFlags);
        fireWorkCoache8Table->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensoryh[i].i_SDWD)));
        fireWorkCoache8Table->item(i,2)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache8Table->item(i,2)->setFlags(Qt::NoItemFlags);
        fireWorkCoache8Table->setItem(i,4,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS));
        if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache8Table->item(i,4)->setBackgroundColor(QColor(0,255,0));
            fireWorkCoache8Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache8Table->item(i,4)->setBackgroundColor(QColor(255,0,0));
            fireWorkCoache8Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache8Table->item(i,4)->setBackgroundColor(QColor(255,255,0));
            fireWorkCoache8Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="��Ⱦ")
        {
            fireWorkCoache8Table->item(i,4)->setBackgroundColor(QColor(255,125,0));
            fireWorkCoache8Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensoryh[i].yanHuoTCQSS=="����")
        {
            fireWorkCoache8Table->item(i,4)->setBackgroundColor(QColor(255,85,127));
            fireWorkCoache8Table->item(i,4)->setFlags(Qt::NoItemFlags);
        }
        fireWorkCoache8Table->setItem(i,5,new QTableWidgetItem(udpSocket->coacheList[index].sensoryh[i].YHVersion));
        fireWorkCoache8Table->item(i,5)->setBackgroundColor(QColor(0,255,0));
        fireWorkCoache8Table->item(i,5)->setFlags(Qt::NoItemFlags);
    }
}
//displayBalanceSheet
void Widget::displayBalanceSheet(int index)
{
    QString str0 = QString::number(udpSocket->coacheList[index].sensorsp[0].b_faultSWKL);
    QString str1 = QString::number(udpSocket->coacheList[index].sensorsp[0].b_faultSWDL);
    QString str2 = QString::number(udpSocket->coacheList[index].sensorsp[0].b_faultPWKL);
    QString str3 = QString::number(udpSocket->coacheList[index].sensorsp[0].b_faultPWDL);

    QString str00 = QString::number(udpSocket->coacheList[index].sensorsp[1].b_faultSWKL);
    QString str11 = QString::number(udpSocket->coacheList[index].sensorsp[1].b_faultSWDL);
    QString str22 = QString::number(udpSocket->coacheList[index].sensorsp[1].b_faultPWKL);
    QString str33 = QString::number(udpSocket->coacheList[index].sensorsp[1].b_faultPWDL);
    /***************************ƽ��ʧ��[0-1]������***************************/
    if(str2 == "0"&& str3=="0")
    {
        balanceInstabilityTable->setItem(0,index+1,new QTableWidgetItem("����"));
        balanceInstabilityTable->item(0,index+1)->setBackgroundColor(QColor(0,255,0));
        balanceInstabilityTable->item(0,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str2 == "1"&& str3== "0")
    {
        balanceInstabilityTable->setItem(0,index+1,new QTableWidgetItem("ƽ�ȿ�·����"));
        balanceInstabilityTable->item(0,index+1)->setBackgroundColor(QColor(255,255,0));
        balanceInstabilityTable->item(0,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str2 == "0"&& str3== "1")
    {
        balanceInstabilityTable->setItem(0,index+1,new QTableWidgetItem("ƽ�ȶ�·����"));
        balanceInstabilityTable->item(0,index+1)->setBackgroundColor(QColor(255,85,0));
        balanceInstabilityTable->item(0,index+1)->setFlags(Qt::NoItemFlags);
    }
    if(str0 == "0"&& str1=="0")
    {
        balanceInstabilityTable->setItem(1,index+1,new QTableWidgetItem("����"));
        balanceInstabilityTable->item(1,index+1)->setBackgroundColor(QColor(0,255,0));
        balanceInstabilityTable->item(1,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str0 == "1"&& str1== "0")
    {
        balanceInstabilityTable->setItem(1,index+1,new QTableWidgetItem("ʧ�ȿ�·����"));
        balanceInstabilityTable->item(1,index+1)->setBackgroundColor(QColor(255,255,0));
        balanceInstabilityTable->item(1,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str0 == "0"&& str1== "1")
    {
        balanceInstabilityTable->setItem(1,index+1,new QTableWidgetItem("ʧ�ȶ�·����"));
        balanceInstabilityTable->item(1,index+1)->setBackgroundColor(QColor(255,85,0));
        balanceInstabilityTable->item(1,index+1)->setFlags(Qt::NoItemFlags);
    }
    /***************************ƽ��ʧ��[0-1]������***************************/
    /***************************ƽ��ʧ��[2-3]������***************************/
    if(str22 == "0"&& str33=="0")
    {
        balanceInstabilityTable->setItem(2,index+1,new QTableWidgetItem("����"));
        balanceInstabilityTable->item(2,index+1)->setBackgroundColor(QColor(0,255,0));
        balanceInstabilityTable->item(2,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str22 == "1"&& str33== "0")
    {
        balanceInstabilityTable->setItem(2,index+1,new QTableWidgetItem("ƽ�ȿ�·����"));
        balanceInstabilityTable->item(2,index+1)->setBackgroundColor(QColor(255,255,0));
        balanceInstabilityTable->item(2,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str22 == "0"&& str33== "1")
    {
        balanceInstabilityTable->setItem(2,index+1,new QTableWidgetItem("ƽ�ȶ�·����"));
        balanceInstabilityTable->item(2,index+1)->setBackgroundColor(QColor(255,85,0));
        balanceInstabilityTable->item(2,index+1)->setFlags(Qt::NoItemFlags);
    }
    if(str00 == "0"&& str11=="0")
    {
        balanceInstabilityTable->setItem(3,index+1,new QTableWidgetItem("����"));
        balanceInstabilityTable->item(3,index+1)->setBackgroundColor(QColor(0,255,0));
        balanceInstabilityTable->item(3,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str00 == "1"&& str11== "0")
    {
        balanceInstabilityTable->setItem(3,index+1,new QTableWidgetItem("ʧ�ȿ�·����"));
        balanceInstabilityTable->item(3,index+1)->setBackgroundColor(QColor(255,255,0));
        balanceInstabilityTable->item(3,index+1)->setFlags(Qt::NoItemFlags);
    }
    else if(str00 == "0"&& str11== "1")
    {
        balanceInstabilityTable->setItem(3,index+1,new QTableWidgetItem("ʧ�ȶ�·����"));
        balanceInstabilityTable->item(3,index+1)->setBackgroundColor(QColor(255,85,0));
        balanceInstabilityTable->item(3,index+1)->setFlags(Qt::NoItemFlags);
    }
    /***************************ƽ��ʧ��[2-3]������***************************/
}
//displayFireLinkageSheet
void Widget::displayFireLinkageSheet(int index)
{
    if(index==1)
    {
        fireLinkageTable->setItem(0,1,new QTableWidgetItem(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS));
        if(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS=="ѹ������")
        {
            fireLinkageTable->item(0,1)->setBackgroundColor(QColor(0,255,0));
            fireLinkageTable->item(0,1)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS=="ѹ������")
        {
            fireLinkageTable->item(0,1)->setBackgroundColor(QColor(255,0,0));
            fireLinkageTable->item(0,1)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS=="ѹ��Ƿ��")
        {
            fireLinkageTable->item(0,1)->setBackgroundColor(QColor(255,255,0));
            fireLinkageTable->item(0,1)->setFlags(Qt::NoItemFlags);
        }
        fireLinkageTable->setItem(0,2,new QTableWidgetItem(udpSocket->coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS));
        if(udpSocket->coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS=="ҩ������")
        {
            fireLinkageTable->item(0,2)->setBackgroundColor(QColor(0,255,0));
            fireLinkageTable->item(0,2)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS=="ҩ��Ƿȱ")
        {
            fireLinkageTable->item(0,2)->setBackgroundColor(QColor(255,0,255));
            fireLinkageTable->item(0,2)->setFlags(Qt::NoItemFlags);
        }
        fireLinkageTable->setItem(0,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensorfhld.pressureWatcher,10)));
        fireLinkageTable->item(0,3)->setBackgroundColor(QColor(0,255,0));
        fireLinkageTable->item(0,3)->setFlags(Qt::NoItemFlags);
    }
    else if(index==6)
    {
        fireLinkageTable->setItem(1,1,new QTableWidgetItem(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS));
        if(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS=="ѹ������")
        {
            fireLinkageTable->item(1,1)->setBackgroundColor(QColor(0,255,0));
            fireLinkageTable->item(1,1)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS=="ѹ������")
        {
            fireLinkageTable->item(1,1)->setBackgroundColor(QColor(255,0,0));
            fireLinkageTable->item(1,1)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensorfhld.xiaoFangXiangFHLDSS=="ѹ��Ƿ��")
        {
            fireLinkageTable->item(1,1)->setBackgroundColor(QColor(255,255,0));
            fireLinkageTable->item(1,1)->setFlags(Qt::NoItemFlags);
        }
        fireLinkageTable->setItem(1,2,new QTableWidgetItem(udpSocket->coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS));
        if(udpSocket->coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS=="ҩ������")
        {
            fireLinkageTable->item(1,2)->setBackgroundColor(QColor(0,255,0));
            fireLinkageTable->item(1,2)->setFlags(Qt::NoItemFlags);
        }
        else if(udpSocket->coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS=="ҩ��Ƿȱ")
        {
            fireLinkageTable->item(1,2)->setBackgroundColor(QColor(255,0,255));
            fireLinkageTable->item(1,2)->setFlags(Qt::NoItemFlags);
        }
        fireLinkageTable->setItem(1,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensorfhld.pressureWatcher,10)));
        fireLinkageTable->item(1,3)->setBackgroundColor(QColor(0,255,0));
        fireLinkageTable->item(1,3)->setFlags(Qt::NoItemFlags);
    }
}
//clean CoacheNum Data
void Widget::cleanCoacheNumDataSlot(int index)
{
    int i           =   0;
    int j           =   0;
    int rowCount    =   0;
    int columnCount =   0;
    //balance
    rowCount = balanceInstabilityTable->rowCount();
    for(i = 0;i<rowCount;i++){
        balanceInstabilityTable->setItem(i,index+1,new QTableWidgetItem("����������"));
        balanceInstabilityTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
        balanceInstabilityTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
    }
    //Alxe
    rowCount = rotateAlxeTable->rowCount();
    for(i = 0;i<rowCount;i++){
        rotateAlxeTable->setItem(i,index+1,new QTableWidgetItem("����������"));
        rotateAlxeTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
        rotateAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
    }
    //AlxeT
    rowCount = temperatureAlxeTable->rowCount();
    for(i = 0;i<rowCount;i++){
        temperatureAlxeTable->setItem(i,index+1,new QTableWidgetItem("����������"));
        temperatureAlxeTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
        temperatureAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
    }

    //gear
    rowCount = rotateGearboxTable->rowCount();
    for(i = 0;i<rowCount;i++){
        if(index == 1){
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 3){
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 4){
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 6){
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
    }
    //gearT
    rowCount = temperatureGearboxTable->rowCount();
    for(i = 0;i<rowCount;i++){
        if(index == 1){
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 3){
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 4){
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 6){
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
    }

    //motor
    rowCount = temperatureMotorTable->rowCount();
    for(i = 0;i<rowCount;i++){
        if(index == 1){
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 3){
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 4){
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 6){
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
    }
    //motorT
    rowCount = rotateMotorTable->rowCount();
    for(i = 0;i<rowCount;i++){
        if(index == 1){
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 3){
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 4){
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }else if(index == 6){
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("����������"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(217,217,217));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
    }
    switch (index) {
    case 0:
        //rotateAll1CoacheTable
        rowCount    = rotateAll1CoacheTable->rowCount();
        columnCount = rotateAll1CoacheTable->columnCount();
        for(int i=0;i<rowCount;i++)
        {
            for(int j=1;j<columnCount;j++)
            {
                if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                    rotateAll1CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                    rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    rotateAll1CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                    rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    rotateAll1CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        //fireWorkCoache1
        rowCount    = fireWorkCoache1Table->rowCount();
        columnCount = fireWorkCoache1Table->columnCount();
        for(i = 0;i<rowCount;i++){
            for(j = 1;j < columnCount;j++){
                if(j==3){
                    fireWorkCoache1Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache1Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache1Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache1Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache1Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache1Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache1Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 1:
        rowCount    = rotateAll2CoacheTable->rowCount();
        columnCount = rotateAll2CoacheTable->columnCount();
        for(i = 0;i < rowCount;i++){
            for(j = 1;j < columnCount;j++){
                rotateAll2CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
        //dong and dining
        rowCount    = temperatureMotorAndDiningTable->rowCount();
        for(i = 0;i < rowCount;i++){
            if((i != 8)&&(i != 9)&&(i != 10)){
                temperatureMotorAndDiningTable->setItem(i,1,new QTableWidgetItem("����������"));
                temperatureMotorAndDiningTable->item(i,1)->setBackgroundColor(QColor(217,217,217));
                temperatureMotorAndDiningTable->item(i,1)->setFlags(Qt::NoItemFlags);
            }
        }
        //fire link
        columnCount = fireLinkageTable->columnCount();
        for(i = 1;i<columnCount;i++){
            fireLinkageTable->setItem(0,i,new QTableWidgetItem("����������"));
            fireLinkageTable->item(0,i)->setBackgroundColor(QColor(217,217,217));
            fireLinkageTable->item(0,i)->setFlags(Qt::NoItemFlags);
        }
        //fireWorkCoache2
        rowCount    = fireWorkCoache2Table->rowCount();
        columnCount = fireWorkCoache2Table->columnCount();
        for(int i=0;i<fireWorkCoache2Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache2Table->columnCount();j++)
            {
                if((j==3)&&(i!=8)){
                    fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache2Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==1)&&(i==8)){
                    fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache2Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==2)&&(i==8)){
                    fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache2Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache2Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache2Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache2Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 2:
        //rotateAll3CoacheTable
        rowCount    = rotateAll3CoacheTable->rowCount();
        columnCount = rotateAll3CoacheTable->columnCount();
        for(int i=0;i<rowCount;i++)
        {
            for(int j=1;j<columnCount;j++)
            {
                if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                    rotateAll3CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                    rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    rotateAll3CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                    rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    rotateAll3CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        //fireWorkCoache3
        for(int i=0;i<fireWorkCoache3Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache3Table->columnCount();j++)
            {
                if(j==3){
                    fireWorkCoache3Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache3Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache3Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache3Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache3Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache3Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache3Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 3:
        rowCount    = rotateAll4CoacheTable->rowCount();
        columnCount = rotateAll4CoacheTable->columnCount();
        for(i = 0;i < rowCount;i++){
            for(j = 1;j < columnCount;j++){
                rotateAll4CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
        //dong and dining
        rowCount    = temperatureMotorAndDiningTable->rowCount();
        for(i = 0;i < rowCount;i++){
            if((i != 8)&&(i != 9)&&(i != 10)){
                temperatureMotorAndDiningTable->setItem(i,2,new QTableWidgetItem("����������"));
                temperatureMotorAndDiningTable->item(i,2)->setBackgroundColor(QColor(217,217,217));
                temperatureMotorAndDiningTable->item(i,2)->setFlags(Qt::NoItemFlags);
            }
        }
        //fireWorkCoache4
        for(int i=0;i<fireWorkCoache4Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache4Table->columnCount();j++)
            {
                if((j==3)&&(i!=8)){
                    fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache4Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==1)&&(i==8)){
                    fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache4Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==2)&&(i==8)){
                    fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache4Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache4Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache4Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache4Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 4:
        rowCount    = rotateAll5CoacheTable->rowCount();
        columnCount = rotateAll5CoacheTable->columnCount();
        for(i = 0;i < rowCount;i++){
            for(j = 1;j < columnCount;j++){
                rotateAll5CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
        //dong and dining
        rowCount    = temperatureMotorAndDiningTable->rowCount();
        for(i = 0;i < rowCount;i++){
            temperatureMotorAndDiningTable->setItem(i,3,new QTableWidgetItem("����������"));
            temperatureMotorAndDiningTable->item(i,3)->setBackgroundColor(QColor(217,217,217));
            temperatureMotorAndDiningTable->item(i,3)->setFlags(Qt::NoItemFlags);
        }
        //fireWorkCoache5
        for(int i=0;i<fireWorkCoache5Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache5Table->columnCount();j++)
            {
                if((j==3)&&(i!=7)){
                    fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache5Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==1)&&(i==7)){
                    fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache5Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==2)&&(i==7)){
                    fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache5Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache5Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache5Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache5Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 5:
        //rotateAll3CoacheTable
        rowCount    = rotateAll6CoacheTable->rowCount();
        columnCount = rotateAll6CoacheTable->columnCount();
        for(int i=0;i<rowCount;i++)
        {
            for(int j=1;j<columnCount;j++)
            {
                if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                    rotateAll6CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                    rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    rotateAll6CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                    rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    rotateAll6CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        //fireWorkCoache6Table
        for(int i=0;i<fireWorkCoache6Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache6Table->columnCount();j++)
            {
                if(j==3){
                    fireWorkCoache6Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache6Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache6Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache6Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache6Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache6Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache6Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 6:
        rowCount    = rotateAll7CoacheTable->rowCount();
        columnCount = rotateAll7CoacheTable->columnCount();
        for(i = 0;i < rowCount;i++){
            for(j = 1;j < columnCount;j++){
                rotateAll7CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
        //dong and dining
        rowCount    = temperatureMotorAndDiningTable->rowCount();
        for(i = 0;i < rowCount;i++){
            if((i != 8)&&(i != 9)&&(i != 10)){
                temperatureMotorAndDiningTable->setItem(i,4,new QTableWidgetItem("����������"));
                temperatureMotorAndDiningTable->item(i,4)->setBackgroundColor(QColor(217,217,217));
                temperatureMotorAndDiningTable->item(i,4)->setFlags(Qt::NoItemFlags);
            }
        }
        //fire link
        columnCount = fireLinkageTable->columnCount();
        for(i = 1;i<columnCount;i++){
            fireLinkageTable->setItem(1,i,new QTableWidgetItem("����������"));
            fireLinkageTable->item(1,i)->setBackgroundColor(QColor(217,217,217));
            fireLinkageTable->item(1,i)->setFlags(Qt::NoItemFlags);
        }
        //fireWorkCoache7Table
        for(int i=0;i<fireWorkCoache7Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache7Table->columnCount();j++)
            {
                if((j==3)&&(i!=8)){
                    fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache7Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==1)&&(i==8)){
                    fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache7Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else if((j==2)&&(i==8)){
                    fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache7Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache7Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache7Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache7Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    case 7:
        //rotateAll8CoacheTable
        rowCount    = rotateAll8CoacheTable->rowCount();
        columnCount = rotateAll8CoacheTable->columnCount();
        for(int i=0;i<rowCount;i++)
        {
            for(int j=1;j<columnCount;j++)
            {
                if((i == 0)||(i == 1)||(i == 8)||(i == 9)){
                    rotateAll8CoacheTable->setItem(i,j,new QTableWidgetItem("����������"));
                    rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    rotateAll8CoacheTable->setItem(i,j,new QTableWidgetItem("-"));
                    rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    rotateAll8CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        //fireWorkCoache8Table
        for(int i=0;i<fireWorkCoache8Table->rowCount();i++)
        {
            for(int j=1;j<fireWorkCoache8Table->columnCount();j++)
            {
                if(j==3){
                    fireWorkCoache8Table->setItem(i,j,new QTableWidgetItem("-"));
                    fireWorkCoache8Table->item(i,j)->setBackgroundColor(QColor(0,0,0));
                    fireWorkCoache8Table->item(i,j)->setTextAlignment(Qt::AlignCenter);
                    fireWorkCoache8Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }else{
                    fireWorkCoache8Table->setItem(i,j,new QTableWidgetItem("����������"));
                    fireWorkCoache8Table->item(i,j)->setBackgroundColor(QColor(217,217,217));
                    fireWorkCoache8Table->item(i,j)->setFlags(Qt::NoItemFlags);
                }
            }
        }
        break;
    default:
        break;
    }
}
//addLightButtonClicked
void Widget::addLightButtonClicked()
{
    if(brightValue<150)
    {
        brightValue+=15;
        if(brightValue>150)
        {
            brightValue = 150;
        }
        lightValueLable->setText(QString::number(brightValue,10));
        QString a;
        a.setNum(brightValue,16);
        QString cmd = "gpio_i2c_write 0xf0 0x1 0x"+a;
        system(cmd.toLatin1().data());

        QSettings *configIniWrite = new QSettings("/root/run/init/brightnessinit.ini", QSettings::IniFormat);
        configIniWrite->setValue("/Bright/value", QString::number(brightValue,10));
        delete configIniWrite;
    }
}
//reduceLightButtonClicked
void Widget::reduceLightButtonClicked()
{
    if(brightValue>0)
    {
        brightValue-=15;
        if(brightValue<15)
        {
            brightValue = 15;
        }
        lightValueLable->setText(QString::number(brightValue,10));
        QString a;
        a.setNum(brightValue,16);
        QString cmd = "gpio_i2c_write 0xf0 0x1 0x"+a;
        system(cmd.toLatin1().data());

        QSettings *configIniWrite = new QSettings("/root/run/init/brightnessinit.ini", QSettings::IniFormat);
        configIniWrite->setValue("/Bright/value", QString::number(brightValue,10));
        delete configIniWrite;
    }
}
//system Timing Slot
void Widget::systemTimingSlot(int year, int month, int day, int hour, int minute, int second)
{
    QString qyear,qmonth,qday,qhour,qminute,qsecond;
    qyear = QString::number(year+2000);
    if(month<=9 && month>=0)
       qmonth = QString("%1").arg(month,2,10,QLatin1Char('0'));
    else
       qmonth = QString::number(month);

    if(day<=9 && day>=0)
       qday = QString("%1").arg(day,2,10,QLatin1Char('0'));
    else
       qday = QString::number(day);

    if(hour<=9 && hour>=0)
       qhour = QString("%1").arg(hour,2,10,QLatin1Char('0'));
    else
       qhour = QString::number(hour);

    if(minute<=9 && minute>=0)
       qminute = QString("%1").arg(minute,2,10,QLatin1Char('0'));
    else
       qminute = QString::number(minute);

    if(second<=9 && second>=0)
       qsecond = QString("%1").arg(second,2,10,QLatin1Char('0'));
    else
       qsecond = QString::number(second);

    QString strDate;
    strDate = qyear+"-"+qmonth+"-"+qday+" "+qhour+":"+qminute+":"+qsecond;

    char cmd_buff[100];
    QDateTime dateTime;
    dateTime = QDateTime::fromString(strDate, "yyyy-MM-dd hh:mm:ss");
    //******************
    QString date = qyear+qmonth+qday+qhour+qminute+qsecond;
    if(QDateTime::currentDateTime().addSecs(-60)>QDateTime::fromString(date, "yyyyMMddhhmmss"))
    {
        QDateTime xitong = QDateTime::currentDateTime();
        QString sxitong = xitong.toString("yyyy-MM-dd hh:mm:ss");
        writeLog(QString("��ǰϵͳʱ��Ϊ��%1,����60������,���ڽ�ʱ...").arg(sxitong));
        QString  ds1339_set = QString("ds1339_set %1 %2 %3 %4 %5 %6").arg(year).arg(month).arg(day).arg(hour).arg(minute).arg(second);
        snprintf(cmd_buff, sizeof(cmd_buff), "date -s \"%s\";"+ds1339_set.toLatin1(),dateTime.toString("yyyy-MM-dd hh:mm:ss").toLatin1().data());
        //snprintf(cmd_buff, sizeof(cmd_buff), "date -s \"%s\";hwclock -w",dateTime.toString("yyyy-MM-dd hh:mm:ss").toLatin1().data());
        system(cmd_buff);
        printf("exec set date cmd =%s\n", cmd_buff);
        if((QDateTime::currentDateTime().addSecs(-60)<QDateTime::fromString(date, "yyyyMMddhhmmss"))
          &&(QDateTime::currentDateTime().addSecs(60)>QDateTime::fromString(date, "yyyyMMddhhmmss")))
        {
            xitong = QDateTime::currentDateTime();
            sxitong = xitong.toString("yyyy-MM-dd hh:mm:ss");
            writeLog(QString("��ʱ�ɹ�����ǰϵͳʱ��Ϊ��%1,���С��60��").arg(sxitong));
        }
    }
    else if(QDateTime::currentDateTime().addSecs(60)<QDateTime::fromString(date, "yyyyMMddhhmmss"))
    {
        QDateTime xitong = QDateTime::currentDateTime();
        QString sxitong = xitong.toString("yyyy-MM-dd hh:mm:ss");
        writeLog(QString("��ǰϵͳʱ��Ϊ��%1,����60������,���ڽ�ʱ...").arg(sxitong));
        QString  ds1339_set = QString("ds1339_set %1 %2 %3 %4 %5 %6").arg(year).arg(month).arg(day).arg(hour).arg(minute).arg(second);
        //snprintf(cmd_buff, sizeof(cmd_buff), "date -s \"%s\";hwclock -w",dateTime.toString("yyyy-MM-dd hh:mm:ss").toLatin1().data());
        snprintf(cmd_buff, sizeof(cmd_buff), "date -s \"%s\";"+ds1339_set.toLatin1(),dateTime.toString("yyyy-MM-dd hh:mm:ss").toLatin1().data());
        system(cmd_buff);
        printf("exec set date cmd =%s\n", cmd_buff);
        if((QDateTime::currentDateTime().addSecs(-60)<QDateTime::fromString(date, "yyyyMMddhhmmss"))
          &&(QDateTime::currentDateTime().addSecs(60)>QDateTime::fromString(date, "yyyyMMddhhmmss")))
        {
            xitong = QDateTime::currentDateTime();
            sxitong = xitong.toString("yyyy-MM-dd hh:mm:ss");
            writeLog(QString("��ǰϵͳʱ��Ϊ��%1,��ʱ�ɹ������С��60��").arg(sxitong));
        }
    }
}
//readSystimeButton
void Widget::readSystimeButtonClicked()
{
    QDateTime currentDateTime = QDateTime::currentDateTime();
    timingEdit->setTime(currentDateTime.time());
    datingEdit->setDate(currentDateTime.date());
}
//settingSystimeButton
void Widget::settingSystimeButtonClicked()
{
    QString strYear     =   datingEdit->sectionText(QDateEdit::YearSection);
    QString strMonth    =   datingEdit->sectionText(QDateEdit::MonthSection);
    QString strDay      =   datingEdit->sectionText(QDateEdit::DaySection);
    QString strHour     =   timingEdit->sectionText(QTimeEdit::HourSection);
    QString strMinute   =   timingEdit->sectionText(QTimeEdit::MinuteSection);
    QString strSecond   =   timingEdit->sectionText(QTimeEdit::SecondSection);

    bool ok             =   false;
    int year = strYear.toInt(&ok,10)-2000;
    int month = strMonth.toInt(&ok,10);
    int day = strDay.toInt(&ok,10);
    int hour = strHour.toInt(&ok,10);
    int minute = strMinute.toInt(&ok,10);
    int second = strSecond.toInt(&ok,10);

    systemTimingSlot(year,month,day,hour,minute,second);
}
//upPageButton
void Widget::mainPageUpPageButtonClicked()
{
    if(mainTable->rowCount()>0)
    {
        int rowCount = mainTable->model()->rowCount();//��ǰ����
        int rowHeight = mainTable->rowHeight(0);//ÿ���и�
        int tableViewHeight = mainTable->height();//�����ܸ߶�
        int rowCountPerPage = tableViewHeight/rowHeight-1;//ÿҳ��ʾ����
        int canNotViewCount = rowCount-rowCountPerPage;//����������
        if(canNotViewCount == 0)
        {
            return;
        }
        int maxValue = mainTable->verticalScrollBar()->maximum();		// ��ǰSCROLLER�����ʾֵ
        if(maxValue == 0)
        {
            return;
        }
        int pageValue = (maxValue*rowCountPerPage)/canNotViewCount;
        int nCurScroller = mainTable->verticalScrollBar()->value();		//��õ�ǰscrollerֵ
        if(nCurScroller>0)
        {
            currentPageCount = currentPageCount -1 ;
            mainPageCurrentPage->setText("��ǰ�� "+QString::number(currentPageCount,10)+" ҳ");
            mainTable->verticalScrollBar()->setSliderPosition(nCurScroller-pageValue);
        }
        else
        {
            QString messageBoxStyle = "QMessageBox{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255);background:rgba(0,255,255,255);font: 75 12pt ;font-family: ����;}";
            QMessageBox *msgBox = new QMessageBox(QMessageBox::Question,"�Ի������", "�Ƿ���ת��ĩҳ", QMessageBox::Yes | QMessageBox::No);
            msgBox->setStyleSheet(messageBoxStyle);
            msgBox->setIcon(QMessageBox::NoIcon);
            QString messageButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(0, 0, 0); background: transparent;font: 75 18pt ;font-family: ����;}";
            msgBox->button(QMessageBox::Yes)->setText("��");
            msgBox->button(QMessageBox::Yes)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::Yes)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::Yes)->setFixedSize(80,40);
            msgBox->button(QMessageBox::No)->setText("��");
            msgBox->button(QMessageBox::No)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::No)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::No)->setFixedSize(80,40);
            int result = msgBox->exec();
            if(result == QMessageBox::Yes)
            {
                QString sumpage = getSumPage();
                currentPageCount = sumpage.toInt();
                mainPageCurrentPage->setText("��ǰ�� "+QString::number(currentPageCount,10)+" ҳ");
                mainTable->verticalScrollBar()->setSliderPosition(mainTable->verticalScrollBar()->maximum());
                return;
            }
        }
    }
}
//downPageButton
void Widget::mainPagedownPageButtonClicked()
{
    if(mainTable->rowCount()>0)
    {
        int rowCount = mainTable->model()->rowCount();//��ǰ����
        int rowHeight = mainTable->rowHeight(0);//ÿ���и�
        int tableViewHeight = mainTable->height();//�����ܸ߶�
        int rowCountPerPage = tableViewHeight/rowHeight-1;//ÿҳ��ʾ����
        int canNotViewCount = rowCount-rowCountPerPage;//����������
        if(canNotViewCount == 0)
        {
            return;
        }
        int maxValue = mainTable->verticalScrollBar()->maximum();		// ��ǰSCROLLER�����ʾֵ
        if(maxValue == 0)
        {
            return;
        }
        int pageValue = (maxValue*rowCountPerPage)/canNotViewCount;
        int nCurScroller = mainTable->verticalScrollBar()->value();		//��õ�ǰscrollerֵ
        if( nCurScroller < maxValue)
        {
           mainTable->verticalScrollBar()->setSliderPosition(nCurScroller+pageValue);
           currentPageCount = currentPageCount +1 ;
           mainPageCurrentPage->setText("��ǰ�� "+QString::number(currentPageCount,10)+" ҳ");
        }
        else
        {
            QString messageBoxStyle = "QMessageBox{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255);background:rgba(0,255,255,255);font: 75 12pt ;font-family: ����;}";
            QMessageBox *msgBox = new QMessageBox(QMessageBox::Question,"�Ի������", "�Ƿ���ת����ҳ", QMessageBox::Yes | QMessageBox::No);
            msgBox->setStyleSheet(messageBoxStyle);
            msgBox->setIcon(QMessageBox::NoIcon);
            QString messageButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(0, 0, 0); background: transparent;font: 75 18pt ;font-family: ����;}";
            msgBox->button(QMessageBox::Yes)->setText("��");
            msgBox->button(QMessageBox::Yes)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::Yes)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::Yes)->setFixedSize(80,40);
            msgBox->button(QMessageBox::No)->setText("��");
            msgBox->button(QMessageBox::No)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::No)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::No)->setFixedSize(80,40);
            int result = msgBox->exec();
            if(result == QMessageBox::Yes)
            {
                currentPageCount=1;
                mainPageCurrentPage->setText("��ǰ�� "+QString::number(currentPageCount,10)+" ҳ");
                mainTable->verticalScrollBar()->setSliderPosition(0);
                return;
            }
        }
    }
}
//alarmRecordPageUpPageButtonClicked
void Widget::alarmRecordPageUpPageButtonClicked()
{
    if(alarmRecordTable->rowCount()>0)
    {
        int rowCount = alarmRecordTable->model()->rowCount();//��ǰ����
        int rowHeight = alarmRecordTable->rowHeight(0);//ÿ���и�
        int tableViewHeight = alarmRecordTable->height();//�����ܸ߶�
        int rowCountPerPage = tableViewHeight/rowHeight-1;//ÿҳ��ʾ����
        int canNotViewCount = rowCount-rowCountPerPage;//����������
        if(canNotViewCount == 0)
        {
            return;
        }
        int maxValue = alarmRecordTable->verticalScrollBar()->maximum();		// ��ǰSCROLLER�����ʾֵ
        if(maxValue == 0)
        {
            return;
        }
        int pageValue = (maxValue*rowCountPerPage)/canNotViewCount;
        int nCurScroller = alarmRecordTable->verticalScrollBar()->value();		//��õ�ǰscrollerֵ
        if(nCurScroller>0)
        {
            recordCurrentPageCount = recordCurrentPageCount -1 ;
            recordPageCurrentPage->setText("��ǰ�� "+QString::number(recordCurrentPageCount,10)+" ҳ");
            alarmRecordTable->verticalScrollBar()->setSliderPosition(nCurScroller-pageValue);
        }
        else
        {
            QString messageBoxStyle = "QMessageBox{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255);background:rgba(0,255,255,255);font: 75 12pt ;font-family: ����;}";
            QMessageBox *msgBox = new QMessageBox(QMessageBox::Question,"�Ի������", "�Ƿ���ת��ĩҳ", QMessageBox::Yes | QMessageBox::No);
            msgBox->setStyleSheet(messageBoxStyle);
            msgBox->setIcon(QMessageBox::NoIcon);
            QString messageButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(0, 0, 0); background: transparent;font: 75 18pt ;font-family: ����;}";
            msgBox->button(QMessageBox::Yes)->setText("��");
            msgBox->button(QMessageBox::Yes)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::Yes)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::Yes)->setFixedSize(80,40);
            msgBox->button(QMessageBox::No)->setText("��");
            msgBox->button(QMessageBox::No)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::No)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::No)->setFixedSize(80,40);
            int result = msgBox->exec();
            if(result == QMessageBox::Yes)
            {
                QString sumpage = getRecordSumPage();
                recordCurrentPageCount = sumpage.toInt();
                recordPageCurrentPage->setText("��ǰ�� "+QString::number(recordCurrentPageCount,10)+" ҳ");
                alarmRecordTable->verticalScrollBar()->setSliderPosition(alarmRecordTable->verticalScrollBar()->maximum());
                return;
            }
        }
    }
}
//alarmRecordPagedownPageButtonClicked
void Widget::alarmRecordPagedownPageButtonClicked()
{
    if(alarmRecordTable->rowCount()>0)
    {
        int rowCount = alarmRecordTable->model()->rowCount();//��ǰ����
        int rowHeight = alarmRecordTable->rowHeight(0);//ÿ���и�
        int tableViewHeight = alarmRecordTable->height();//�����ܸ߶�
        int rowCountPerPage = tableViewHeight/rowHeight-1;//ÿҳ��ʾ����
        int canNotViewCount = rowCount-rowCountPerPage;//����������
        if(canNotViewCount == 0)
        {
            return;
        }
        int maxValue = alarmRecordTable->verticalScrollBar()->maximum();		// ��ǰSCROLLER�����ʾֵ
        if(maxValue == 0)
        {
            return;
        }
        int pageValue = (maxValue*rowCountPerPage)/canNotViewCount;
        int nCurScroller = alarmRecordTable->verticalScrollBar()->value();		//��õ�ǰscrollerֵ
        if(nCurScroller<maxValue)
        {
           alarmRecordTable->verticalScrollBar()->setSliderPosition(nCurScroller+pageValue);
           recordCurrentPageCount = recordCurrentPageCount +1 ;
           recordPageCurrentPage->setText("��ǰ�� "+QString::number(recordCurrentPageCount,10)+" ҳ");
        }
        else
        {
            QString messageBoxStyle = "QMessageBox{border:3px solid white;border-radius:5px;color: rgb(255, 255, 255);background:rgba(0,255,255,255);font: 75 12pt ;font-family: ����;}";
            QMessageBox *msgBox = new QMessageBox(QMessageBox::Question,"�Ի������", "�Ƿ���ת����ҳ", QMessageBox::Yes | QMessageBox::No);
            msgBox->setStyleSheet(messageBoxStyle);
            msgBox->setIcon(QMessageBox::NoIcon);
            QString messageButtonStyle = "QPushButton{border:3px solid white;border-radius:5px;color: rgb(0, 0, 0); background: transparent;font: 75 18pt ;font-family: ����;}";
            msgBox->button(QMessageBox::Yes)->setText("��");
            msgBox->button(QMessageBox::Yes)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::Yes)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::Yes)->setFixedSize(80,40);
            msgBox->button(QMessageBox::No)->setText("��");
            msgBox->button(QMessageBox::No)->setStyleSheet(messageButtonStyle);
            msgBox->button(QMessageBox::No)->setFocusPolicy(Qt::NoFocus);
            msgBox->button(QMessageBox::No)->setFixedSize(80,40);
            int result = msgBox->exec();
            if(result == QMessageBox::Yes)
            {
                recordCurrentPageCount=1;
                recordPageCurrentPage->setText("��ǰ�� "+QString::number(recordCurrentPageCount,10)+" ҳ");
                alarmRecordTable->verticalScrollBar()->setSliderPosition(0);
                return;
            }
        }
    }
}
//displayTemperatureTable
void Widget::displayTemperatureAlxeTable(int index)
{
    for(int i=0;i<4;i++)
    {
/***************************����ǰ�ô�����ǰ�ĸ�������***************************/
        QString str0 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].temperatureStatue.b_DLFault);
        QString str1 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].temperatureStatue.b_KLFault);
        QString str2 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].temperatureStatue.i_temperature-50,10);

        QString str00 = QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].temperatureStatue.b_DLFault);
        QString str11 = QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].temperatureStatue.b_KLFault);
        QString str22 = QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].temperatureStatue.i_temperature-50,10);

        /************�����������[0-3]��*************/
        if(str0=="1")
        {
            temperatureAlxeTable->setItem(i,index+1,new QTableWidgetItem("�¶ȶ�·"));
            temperatureAlxeTable->item(i,index+1)->setBackgroundColor(QColor(255,255,0));
            temperatureAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if(str1 =="1")
        {
            temperatureAlxeTable->setItem(i,index+1,new QTableWidgetItem("�¶ȿ�·"));
            temperatureAlxeTable->item(i,index+1)->setBackgroundColor(QColor(255,85,127));
            temperatureAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str1 =="0"))
        {
            temperatureAlxeTable->setItem(i,index+1,new QTableWidgetItem(str2+"��"));
            temperatureAlxeTable->item(i,index+1)->setBackgroundColor(QColor(0,255,0));
            temperatureAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����������[0-3]��*************/

        /************�����¶��������[4-7]��*************/
        if(str00=="1")
        {
            temperatureAlxeTable->setItem(i+4,index+1,new QTableWidgetItem("�¶ȶ�·"));
            temperatureAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(255,255,0));
            temperatureAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if(str11 =="1")
        {
            temperatureAlxeTable->setItem(i+4,index+1,new QTableWidgetItem("�¶ȿ�·"));
            temperatureAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(255,85,127));
            temperatureAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str11 =="0"))
        {
            temperatureAlxeTable->setItem(i+4,index+1,new QTableWidgetItem(str22+"��"));
            temperatureAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(0,255,0));
            temperatureAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����¶��������[4-7]��*************/
    }
}
void Widget::displayTemperatureGearTable(int index)
{
    if((index == 0)||(index == 2)||(index == 5)||(index == 7)){
        return;
    }
    for(int i=0;i<8;i++)
    {
        /***************************����ǰ�ô�����ǰ5-12��������***************************/
        QString str0 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+4].temperatureStatue.b_DLFault);
        QString str1 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+4].temperatureStatue.b_KLFault);
        QString str2 = QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+4].temperatureStatue.i_temperature-50,10);

        QString str00 = QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+4].temperatureStatue.b_DLFault);
        QString str11 = QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+4].temperatureStatue.b_KLFault);
        QString str22 = QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+4].temperatureStatue.i_temperature-50,10);
        /************�����¶ȳ��������[0-7]��*************/
        if(str0=="1")
        {
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem("�¶ȶ�·"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(255,255,0));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if(str1 =="1")
        {
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem("�¶ȿ�·"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(255,85,127));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str1 =="0"))
        {
            temperatureGearboxTable->setItem(i,index+1,new QTableWidgetItem(str2+"��"));
            temperatureGearboxTable->item(i,index+1)->setBackgroundColor(QColor(0,255,0));
            temperatureGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����¶ȳ��������[0-7]��*************/
        /************�����¶ȳ��������[8-15]��*************/
        if(str00=="1")
        {
            temperatureGearboxTable->setItem(i+8,index+1,new QTableWidgetItem("�¶ȶ�·"));
            temperatureGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(255,255,0));
            temperatureGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if(str11 =="1")
        {
            temperatureGearboxTable->setItem(i+8,index+1,new QTableWidgetItem("�¶ȿ�·"));
            temperatureGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(255,85,127));
            temperatureGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str11 =="0"))
        {
            temperatureGearboxTable->setItem(i+8,index+1,new QTableWidgetItem(str22+"��"));
            temperatureGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(0,255,0));
            temperatureGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����¶ȳ��������[8-15]��*************/
    }
}
void Widget::displayTemperatureMotorTable(int index)
{
    if((index == 0)||(index == 2)||(index == 5)||(index == 7)){
        return;
    }
    for(int i=0;i<4;i++)
    {
        QString str0 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+12].temperatureStatue.b_DLFault);
        QString str1 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+12].temperatureStatue.b_KLFault);
        QString str2 =  QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+12].temperatureStatue.i_temperature-50,10);

        QString str00 =  QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+12].temperatureStatue.b_DLFault);
        QString str11 =  QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+12].temperatureStatue.b_KLFault);
        QString str22 =  QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+12].temperatureStatue.i_temperature-50,10);
        /************�����¶ȵ������[0-3]��*************/
        if(str0=="1")
        {
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem("�¶ȶ�·"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(255,255,0));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if(str1 =="1")
        {
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem("�¶ȿ�·"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(255,85,127));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str1 =="0"))
        {
            temperatureMotorTable->setItem(i,index+1,new QTableWidgetItem(str2+"��"));
            temperatureMotorTable->item(i,index+1)->setBackgroundColor(QColor(0,255,0));
            temperatureMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����¶ȵ������[0-3]��*************/
        /************�����¶ȵ������[4-7]��*************/
        if(str00=="1")
        {
            temperatureMotorTable->setItem(i+4,index+1,new QTableWidgetItem("�¶ȶ�·"));
            temperatureMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(255,255,0));
            temperatureMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if(str11 =="1")
        {
            temperatureMotorTable->setItem(i+4,index+1,new QTableWidgetItem("�¶ȿ�·"));
            temperatureMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(255,85,127));
            temperatureMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str11 =="0"))
        {
            temperatureMotorTable->setItem(i+4,index+1,new QTableWidgetItem(str22+"��"));
            temperatureMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(0,255,0));
            temperatureMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����¶ȵ������[4-7]��*************/
    }
}
void Widget::displayTemperatureMotorAndDiningTable(int index)
{
    if((index==1))
    {
        for(int i=0;i<4;i++)
        {
            /***************************��������״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,1,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,1)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i,1)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,1,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,1)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i,1)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarDZWD)));
                temperatureMotorAndDiningTable->item(i,1)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i,1)->setFlags(Qt::NoItemFlags);
            }
            /***************************��������״̬��ʾ***************************/

            /***************************������ȴ״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,1,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,1)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i+4,1)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,1,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,1)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i+4,1)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i+4,1,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarLQWD)));
                temperatureMotorAndDiningTable->item(i+4,1)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i+4,1)->setFlags(Qt::NoItemFlags);
            }
            /***************************������ȴ״̬��ʾ***************************/
        }
        temperatureMotorAndDiningTable->setItem(11,1,new QTableWidgetItem(udpSocket->coacheList[index].PTVersion));
        temperatureMotorAndDiningTable->item(11,1)->setBackgroundColor(QColor(0,255,0));
        temperatureMotorAndDiningTable->item(11,1)->setFlags(Qt::NoItemFlags);
    }else if(index == 3){
        for(int i=0;i<4;i++)
        {
            /***************************��������״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,2,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,2)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i,2)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,2,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,2)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i,2)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarDZWD)));
                temperatureMotorAndDiningTable->item(i,2)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i,2)->setFlags(Qt::NoItemFlags);
            }
            /***************************��������״̬��ʾ***************************/

            /***************************������ȴ״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,2,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,2)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i+4,2)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,2,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,2)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i+4,2)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i+4,2,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarLQWD)));
                temperatureMotorAndDiningTable->item(i+4,2)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i+4,2)->setFlags(Qt::NoItemFlags);
            }
            /***************************������ȴ״̬��ʾ***************************/
        }
        temperatureMotorAndDiningTable->setItem(11,2,new QTableWidgetItem(udpSocket->coacheList[index].PTVersion));
        temperatureMotorAndDiningTable->item(11,2)->setBackgroundColor(QColor(0,255,0));
        temperatureMotorAndDiningTable->item(11,2)->setFlags(Qt::NoItemFlags);
    }else if(index == 6){
        for(int i=0;i<4;i++)
        {
            /***************************��������״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,4,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,4)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i,4)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,4,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,4)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i,4)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i,4,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarDZWD)));
                temperatureMotorAndDiningTable->item(i,4)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i,4)->setFlags(Qt::NoItemFlags);
            }
            /***************************��������״̬��ʾ***************************/

            /***************************������ȴ״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,4,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,4)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i+4,4)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,4,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,4)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i+4,4)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i+4,4,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarLQWD)));
                temperatureMotorAndDiningTable->item(i+4,4)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i+4,4)->setFlags(Qt::NoItemFlags);
            }
            /***************************������ȴ״̬��ʾ***************************/
        }
        temperatureMotorAndDiningTable->setItem(11,4,new QTableWidgetItem(udpSocket->coacheList[index].PTVersion));
        temperatureMotorAndDiningTable->item(11,4)->setBackgroundColor(QColor(0,255,0));
        temperatureMotorAndDiningTable->item(11,4)->setFlags(Qt::NoItemFlags);
    }else if(index==4)
    {
        for(int i=0;i<4;i++)
        {
            /***************************��������״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,3,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,3)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i,3)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i,3,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i,3)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i,3)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarDZSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarDZWD)));
                temperatureMotorAndDiningTable->item(i,3)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i,3)->setFlags(Qt::NoItemFlags);
            }
            /***************************��������״̬��ʾ***************************/

            /***************************������ȴ״̬��ʾ***************************/
            if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,3,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,3)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(i+4,3)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(i+4,3,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(i+4,3)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(i+4,3)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensordongcar[i].dongCarLQSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(i+4,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensordongcar[i].i_dongCarLQWD)));
                temperatureMotorAndDiningTable->item(i+4,3)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(i+4,3)->setFlags(Qt::NoItemFlags);
            }
            /***************************������ȴ״̬��ʾ***************************/
        }
        temperatureMotorAndDiningTable->setItem(11,3,new QTableWidgetItem(udpSocket->coacheList[index].PTVersion));
        temperatureMotorAndDiningTable->item(11,3)->setBackgroundColor(QColor(0,255,0));
        temperatureMotorAndDiningTable->item(11,3)->setFlags(Qt::NoItemFlags);

        for(int j=0;j<3;j++)
        {
            if(udpSocket->coacheList[index].sensorcancarwd[j].canCarWDSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(j+8,3,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(j+8,3)->setBackgroundColor(QColor(255,255,0));
                temperatureMotorAndDiningTable->item(j+8,3)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensorcancarwd[j].canCarWDSS=="��·")
            {
                temperatureMotorAndDiningTable->setItem(j+8,3,new QTableWidgetItem("��·����"));
                temperatureMotorAndDiningTable->item(j+8,3)->setBackgroundColor(QColor(255,85,127));
                temperatureMotorAndDiningTable->item(j+8,3)->setFlags(Qt::NoItemFlags);
            }
            else if(udpSocket->coacheList[index].sensorcancarwd[j].canCarWDSS=="����")
            {
                temperatureMotorAndDiningTable->setItem(j+8,3,new QTableWidgetItem(QString::number(udpSocket->coacheList[index].sensorcancarwd[j].i_canCarWD)));
                temperatureMotorAndDiningTable->item(j+8,3)->setBackgroundColor(QColor(0,255,0));
                temperatureMotorAndDiningTable->item(j+8,3)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::temperatureNavigationReturnButtonClicked()
{
    navigationButtonRelease();
    temperatureNavigationReturnButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidgetNavigation->setCurrentIndex(0);
    mainNavigationMainInterfaceButtonClicked();
}
//rotateAllButton Unclicked Release
void Widget::rotateAllButtonUnclickedRelease()
{
    rotateAllButton1->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton2->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton3->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton4->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton5->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton6->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton7->setStyleSheet(rotateAllButtonStyle);
    rotateAllButton8->setStyleSheet(rotateAllButtonStyle);
}
//rotateAllTableRelease
void Widget::rotateAllTableRelease()
{
    rotateAll1CoacheTable->hide();
    rotateAll2CoacheTable->hide();
    rotateAll3CoacheTable->hide();
    rotateAll4CoacheTable->hide();
    rotateAll5CoacheTable->hide();
    rotateAll6CoacheTable->hide();
    rotateAll7CoacheTable->hide();
    rotateAll8CoacheTable->hide();
}
//releaseRotateSingleTable
void Widget::releaseRotateSingleTable()
{
    rotateAlxeTable->hide();
    rotateGearboxTable->hide();
    rotateMotorTable->hide();
}
//release FireWorkTable
void Widget::releaseFireWorkTable()
{
    fireWorkCoache1Table->hide();
    fireWorkCoache2Table->hide();
    fireWorkCoache3Table->hide();
    fireWorkCoache4Table->hide();
    fireWorkCoache5Table->hide();
    fireWorkCoache6Table->hide();
    fireWorkCoache7Table->hide();
    fireWorkCoache8Table->hide();
}
//release TemperatureTable
void Widget::releaseTemperatureTable()
{
    temperatureAlxeTable->hide();
    temperatureGearboxTable->hide();
    temperatureMotorTable->hide();
    temperatureMotorAndDiningTable->hide();
}
//fireWorkButtonUnclickedRelease
void Widget::fireWorkButtonUnclickedRelease()
{
    fireWorkButton1->setStyleSheet(navigationButtonStyle);
    fireWorkButton2->setStyleSheet(navigationButtonStyle);
    fireWorkButton3->setStyleSheet(navigationButtonStyle);
    fireWorkButton4->setStyleSheet(navigationButtonStyle);
    fireWorkButton5->setStyleSheet(navigationButtonStyle);
    fireWorkButton6->setStyleSheet(navigationButtonStyle);
    fireWorkButton7->setStyleSheet(navigationButtonStyle);
    fireWorkButton8->setStyleSheet(navigationButtonStyle);
}
//navigationButton Unclicked Release
void Widget::navigationButtonRelease()
{
    //mainNavigation Button
    mainNavigationMainInterfaceButton->setStyleSheet(navigationButtonStyle);
    mainNavigationRotateButton->setStyleSheet(navigationButtonStyle);
    mainNavigationFireworksButton->setStyleSheet(navigationButtonStyle);
    mainNavigationBalanceButton->setStyleSheet(navigationButtonStyle);
    mainNavigationFireLinkageButton->setStyleSheet(navigationButtonStyle);
    mainNavigationTemperatureButton->setStyleSheet(navigationButtonStyle);
    mainNavigationAlarmRecordButton->setStyleSheet(navigationButtonStyle);
    mainNavigationSystemSetButton->setStyleSheet(navigationButtonStyle);

    //rotateNavigation Button
    rotateNavigationAllCoacheButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationAlxeboxButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationGearboxButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationMotorButton->setStyleSheet(navigationButtonStyle);
    rotateNavigationReturnButton->setStyleSheet(navigationButtonStyle);

    //fireWorkNavigation Button
    fireWorkReturn->setStyleSheet(navigationButtonStyle);

    //temperatureNavigation Button
    temperatureNavigationAlxeboxButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationGearboxButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationMotorButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationMotorAndDiningCoacheButton->setStyleSheet(navigationButtonStyle);
    temperatureNavigationReturnButton->setStyleSheet(navigationButtonStyle);
}

//slot time
void Widget::doTime1()
{
    time1 = new QTimer;
    time1Thread = new QThread;
    time1->start(1000);
    time1->moveToThread(time1Thread);
    connect(time1, SIGNAL(timeout()), this, SLOT(time1out()));
    time1Thread->start();
}
void Widget::time1out()
{

    //time
    curTime = QDateTime::currentDateTime();
    dateYear =curTime.toString("yyyy��");
    dateMonthDay = curTime.toString("MM��dd��");
    timeHoursMinite = curTime.toString("hh:mm");
    timeSecond = curTime.toString("ss");

    //QFont
    ft.setPointSize(25);
    ft.setFamily("����");
    pa.setColor(QPalette::WindowText,Qt::white);


    labelDateYear->setGeometry(250,15,260,40);
    labelDateYear->setText(dateYear);
    labelDateYear->setFont(ft);
    labelDateYear->setPalette(pa);


    labelDateMonthDay->setGeometry(360,15,260,40);
    labelDateMonthDay->setText(dateMonthDay);
    labelDateMonthDay->setFont(ft);
    labelDateMonthDay->setPalette(pa);

    ft.setPointSize(25);
    ft.setFamily("����");
    labelHoursMiniter->setGeometry(20,15,90,40);
    labelHoursMiniter->setText(timeHoursMinite);
    labelHoursMiniter->setFont(ft);
    labelHoursMiniter->setPalette(pa);

    ft.setPointSize(18);
    labelSecond->setGeometry(130,25,70,30);
    labelSecond->setText(timeSecond);
    labelSecond->setFont(ft);
    labelSecond->setPalette(pa);
}
//writeLog
void Widget::writeLog(QString str)
{
    QDir dir(QCoreApplication::applicationDirPath());
    if(dir.cdUp())
    {
        pathLogFile = dir.path()+"/log/"+QDateTime::currentDateTime().toString("yyyy-MM-dd")+".log";
    }
    QFile file(pathLogFile);
    if(file.open(QIODevice::ReadWrite|QIODevice::Append|QIODevice::Text))
    {
        QString strDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        QString strLog = " [ "+strDateTime+" ] : "+str+"\r\n";
        file.write(strLog.toUtf8());
        file.flush();
        file.close();
    }
}
//rotateAllPushButton Clicked
void Widget::rotateCoache1PushButtonClicked()
{
    if(currentRotateCoache == 1 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll1CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 1;
        rotateAllButtonUnclickedRelease();
        rotateAllButton1->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(1);
        rotateCoacheClickedStatue = true;
    }
}
//displayRotateAllSheet
void Widget::displayRotateAllCoache1Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,1)->text();
    rotateAll1CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,1)->text();
    rotateAll1CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,1)->text();
    rotateAll1CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,1)->text();
    rotateAll1CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,1)->text();
    rotateAll1CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,1)->text();
    rotateAll1CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,1)->text();
    rotateAll1CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,1)->text();
    rotateAll1CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,1)->text();
    rotateAll1CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,1)->text();
    rotateAll1CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,1)->text();
    rotateAll1CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,1)->text();
    rotateAll1CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,1)->text();
    rotateAll1CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,1)->text();
    rotateAll1CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,1)->text();
    rotateAll1CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,1)->text();
    rotateAll1CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,1)->text();
    rotateAll1CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,1)->text();
    rotateAll1CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,1)->text();
    rotateAll1CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,1)->text();
    rotateAll1CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,1)->text();
    rotateAll1CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,1)->text();
    rotateAll1CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,1)->text();
    rotateAll1CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,1)->text();
    rotateAll1CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,1)->text();
    rotateAll1CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,1)->text();
    rotateAll1CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,1)->text();
    rotateAll1CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,1)->text();
    rotateAll1CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,1)->text();
    rotateAll1CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,1)->text();
    rotateAll1CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,1)->text();
    rotateAll1CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,1)->text();
    rotateAll1CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,1)->text();
    rotateAll1CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,1)->text();
    rotateAll1CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,1)->text();
    rotateAll1CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,1)->text();
    rotateAll1CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,1)->text();
    rotateAll1CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,1)->text();
    rotateAll1CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,1)->text();
    rotateAll1CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,1)->text();
    rotateAll1CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll1CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll1CoacheTable->columnCount();j++)
        {
            if(rotateAll1CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll1CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll1CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll1CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll1CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache2PushButtonClicked()
{
    if(currentRotateCoache == 2 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll2CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 2;
        rotateAllButtonUnclickedRelease();
        rotateAllButton2->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(2);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache2Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,2)->text();
    rotateAll2CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,2)->text();
    rotateAll2CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,2)->text();
    rotateAll2CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,2)->text();
    rotateAll2CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,2)->text();
    rotateAll2CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,2)->text();
    rotateAll2CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,2)->text();
    rotateAll2CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,2)->text();
    rotateAll2CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************����ֳ��ֶ�*************/
    QString dclq1 = rotateGearboxTable->item(0,2)->text();
    rotateAll2CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,2)->text();
    rotateAll2CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,2)->text();
    rotateAll2CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,2)->text();
    rotateAll2CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************����ֳ��ֶ�*************/
    /**
     **/
    /************����ֵ����*************/
    QString dclfq1 = rotateGearboxTable->item(1,2)->text();
    rotateAll2CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,2)->text();
    rotateAll2CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,2)->text();
    rotateAll2CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,2)->text();
    rotateAll2CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ֵ����*************/
    /**
     **/
    /************С���ֳ��ֶ�*************/
    QString xclq1 = rotateGearboxTable->item(4,2)->text();
    rotateAll2CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,2)->text();
    rotateAll2CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,2)->text();
    rotateAll2CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,2)->text();
    rotateAll2CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С���ֳ��ֶ�*************/
    /**
     **/
    /************С���ֵ����*************/
    QString xclfq1 = rotateGearboxTable->item(5,2)->text();
    rotateAll2CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,2)->text();
    rotateAll2CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,2)->text();
    rotateAll2CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,2)->text();
    rotateAll2CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ֵ����*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,2)->text();
    rotateAll2CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,2)->text();
    rotateAll2CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,2)->text();
    rotateAll2CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,2)->text();
    rotateAll2CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,2)->text();
    rotateAll2CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,2)->text();
    rotateAll2CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,2)->text();
    rotateAll2CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,2)->text();
    rotateAll2CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,2)->text();
    rotateAll2CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,2)->text();
    rotateAll2CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,2)->text();
    rotateAll2CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,2)->text();
    rotateAll2CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,2)->text();
    rotateAll2CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,2)->text();
    rotateAll2CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,2)->text();
    rotateAll2CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,2)->text();
    rotateAll2CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll2CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll2CoacheTable->columnCount();j++)
        {
            if(rotateAll2CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll2CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll2CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll2CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll2CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache3PushButtonClicked()
{
    if(currentRotateCoache == 3 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll3CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 3;
        rotateAllButtonUnclickedRelease();
        rotateAllButton3->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(3);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache3Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,3)->text();
    rotateAll3CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,3)->text();
    rotateAll3CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,3)->text();
    rotateAll3CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,3)->text();
    rotateAll3CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,3)->text();
    rotateAll3CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,3)->text();
    rotateAll3CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,3)->text();
    rotateAll3CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,3)->text();
    rotateAll3CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,3)->text();
    rotateAll3CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,3)->text();
    rotateAll3CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,3)->text();
    rotateAll3CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,3)->text();
    rotateAll3CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,3)->text();
    rotateAll3CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,3)->text();
    rotateAll3CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,3)->text();
    rotateAll3CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,3)->text();
    rotateAll3CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,3)->text();
    rotateAll3CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,3)->text();
    rotateAll3CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,3)->text();
    rotateAll3CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,3)->text();
    rotateAll3CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,3)->text();
    rotateAll3CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,3)->text();
    rotateAll3CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,3)->text();
    rotateAll3CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,3)->text();
    rotateAll3CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,3)->text();
    rotateAll3CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,3)->text();
    rotateAll3CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,3)->text();
    rotateAll3CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,3)->text();
    rotateAll3CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,3)->text();
    rotateAll3CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,3)->text();
    rotateAll3CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,3)->text();
    rotateAll3CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,3)->text();
    rotateAll3CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,3)->text();
    rotateAll3CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,3)->text();
    rotateAll3CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,3)->text();
    rotateAll3CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,3)->text();
    rotateAll3CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,3)->text();
    rotateAll3CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,3)->text();
    rotateAll3CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,3)->text();
    rotateAll3CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,3)->text();
    rotateAll3CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll3CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll3CoacheTable->columnCount();j++)
        {
            if(rotateAll3CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll3CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll3CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll3CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll3CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache4PushButtonClicked()
{
    if(currentRotateCoache == 4 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll4CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 4;
        rotateAllButtonUnclickedRelease();
        rotateAllButton4->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(4);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache4Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,4)->text();
    rotateAll4CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,4)->text();
    rotateAll4CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,4)->text();
    rotateAll4CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,4)->text();
    rotateAll4CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,4)->text();
    rotateAll4CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,4)->text();
    rotateAll4CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,4)->text();
    rotateAll4CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,4)->text();
    rotateAll4CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,4)->text();
    rotateAll4CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,4)->text();
    rotateAll4CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,4)->text();
    rotateAll4CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,4)->text();
    rotateAll4CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,4)->text();
    rotateAll4CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,4)->text();
    rotateAll4CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,4)->text();
    rotateAll4CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,4)->text();
    rotateAll4CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,4)->text();
    rotateAll4CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,4)->text();
    rotateAll4CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,4)->text();
    rotateAll4CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,4)->text();
    rotateAll4CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,4)->text();
    rotateAll4CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,4)->text();
    rotateAll4CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,4)->text();
    rotateAll4CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,4)->text();
    rotateAll4CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,4)->text();
    rotateAll4CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,4)->text();
    rotateAll4CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,4)->text();
    rotateAll4CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,4)->text();
    rotateAll4CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,4)->text();
    rotateAll4CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,4)->text();
    rotateAll4CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,4)->text();
    rotateAll4CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,4)->text();
    rotateAll4CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,4)->text();
    rotateAll4CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,4)->text();
    rotateAll4CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,4)->text();
    rotateAll4CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,4)->text();
    rotateAll4CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,4)->text();
    rotateAll4CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,4)->text();
    rotateAll4CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,4)->text();
    rotateAll4CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,4)->text();
    rotateAll4CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll4CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll4CoacheTable->columnCount();j++)
        {
            if(rotateAll4CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll4CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll4CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll4CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll4CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache5PushButtonClicked()
{
    if(currentRotateCoache == 5 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll5CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 5;
        rotateAllButtonUnclickedRelease();
        rotateAllButton5->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(5);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache5Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,5)->text();
    rotateAll5CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,5)->text();
    rotateAll5CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,5)->text();
    rotateAll5CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,5)->text();
    rotateAll5CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,5)->text();
    rotateAll5CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,5)->text();
    rotateAll5CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,5)->text();
    rotateAll5CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,5)->text();
    rotateAll5CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,5)->text();
    rotateAll5CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,5)->text();
    rotateAll5CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,5)->text();
    rotateAll5CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,5)->text();
    rotateAll5CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,5)->text();
    rotateAll5CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,5)->text();
    rotateAll5CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,5)->text();
    rotateAll5CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,5)->text();
    rotateAll5CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,5)->text();
    rotateAll5CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,5)->text();
    rotateAll5CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,5)->text();
    rotateAll5CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,5)->text();
    rotateAll5CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,5)->text();
    rotateAll5CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,5)->text();
    rotateAll5CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,5)->text();
    rotateAll5CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,5)->text();
    rotateAll5CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,5)->text();
    rotateAll5CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,5)->text();
    rotateAll5CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,5)->text();
    rotateAll5CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,5)->text();
    rotateAll5CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,5)->text();
    rotateAll5CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,5)->text();
    rotateAll5CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,5)->text();
    rotateAll5CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,5)->text();
    rotateAll5CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,5)->text();
    rotateAll5CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,5)->text();
    rotateAll5CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,5)->text();
    rotateAll5CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,5)->text();
    rotateAll5CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,5)->text();
    rotateAll5CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,5)->text();
    rotateAll5CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,5)->text();
    rotateAll5CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,5)->text();
    rotateAll5CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll5CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll5CoacheTable->columnCount();j++)
        {
            if(rotateAll5CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll5CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll5CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll5CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll5CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache6PushButtonClicked()
{
    if(currentRotateCoache == 6 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll6CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 6;
        rotateAllButtonUnclickedRelease();
        rotateAllButton6->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(6);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache6Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,6)->text();
    rotateAll6CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,6)->text();
    rotateAll6CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,6)->text();
    rotateAll6CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,6)->text();
    rotateAll6CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,6)->text();
    rotateAll6CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,6)->text();
    rotateAll6CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,6)->text();
    rotateAll6CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,6)->text();
    rotateAll6CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,6)->text();
    rotateAll6CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,6)->text();
    rotateAll6CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,6)->text();
    rotateAll6CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,6)->text();
    rotateAll6CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,6)->text();
    rotateAll6CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,6)->text();
    rotateAll6CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,6)->text();
    rotateAll6CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,6)->text();
    rotateAll6CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,6)->text();
    rotateAll6CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,6)->text();
    rotateAll6CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,6)->text();
    rotateAll6CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,6)->text();
    rotateAll6CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,6)->text();
    rotateAll6CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,6)->text();
    rotateAll6CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,6)->text();
    rotateAll6CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,6)->text();
    rotateAll6CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,6)->text();
    rotateAll6CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,6)->text();
    rotateAll6CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,6)->text();
    rotateAll6CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,6)->text();
    rotateAll6CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,6)->text();
    rotateAll6CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,6)->text();
    rotateAll6CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,6)->text();
    rotateAll6CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,6)->text();
    rotateAll6CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,6)->text();
    rotateAll6CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,6)->text();
    rotateAll6CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,6)->text();
    rotateAll6CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,6)->text();
    rotateAll6CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,6)->text();
    rotateAll6CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,6)->text();
    rotateAll6CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,6)->text();
    rotateAll6CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,6)->text();
    rotateAll6CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll6CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll6CoacheTable->columnCount();j++)
        {
            if(rotateAll6CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll6CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll6CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll6CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll6CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache7PushButtonClicked()
{
    if(currentRotateCoache == 7 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll7CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 7;
        rotateAllButtonUnclickedRelease();
        rotateAllButton7->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(7);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache7Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,7)->text();
    rotateAll7CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,7)->text();
    rotateAll7CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,7)->text();
    rotateAll7CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,7)->text();
    rotateAll7CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,7)->text();
    rotateAll7CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,7)->text();
    rotateAll7CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,7)->text();
    rotateAll7CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,7)->text();
    rotateAll7CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,7)->text();
    rotateAll7CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,7)->text();
    rotateAll7CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,7)->text();
    rotateAll7CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,7)->text();
    rotateAll7CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,7)->text();
    rotateAll7CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,7)->text();
    rotateAll7CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,7)->text();
    rotateAll7CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,7)->text();
    rotateAll7CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,7)->text();
    rotateAll7CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,7)->text();
    rotateAll7CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,7)->text();
    rotateAll7CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,7)->text();
    rotateAll7CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,7)->text();
    rotateAll7CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,7)->text();
    rotateAll7CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,7)->text();
    rotateAll7CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,7)->text();
    rotateAll7CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,7)->text();
    rotateAll7CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,7)->text();
    rotateAll7CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,7)->text();
    rotateAll7CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,7)->text();
    rotateAll7CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,7)->text();
    rotateAll7CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,7)->text();
    rotateAll7CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,7)->text();
    rotateAll7CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,7)->text();
    rotateAll7CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,7)->text();
    rotateAll7CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,7)->text();
    rotateAll7CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,7)->text();
    rotateAll7CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,7)->text();
    rotateAll7CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,7)->text();
    rotateAll7CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,7)->text();
    rotateAll7CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,7)->text();
    rotateAll7CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,7)->text();
    rotateAll7CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll7CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll7CoacheTable->columnCount();j++)
        {
            if(rotateAll7CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll7CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll7CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll7CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll7CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}
void Widget::rotateCoache8PushButtonClicked()
{
    if(currentRotateCoache == 8 && rotateCoacheClickedStatue == true){
        currentRotateCoache = 0;
        rotateAllButtonUnclickedRelease();
        rotateAll8CoacheTable->hide();
        rotateCoacheClickedStatue = false;
    }
    else {
        currentRotateCoache = 8;
        rotateAllButtonUnclickedRelease();
        rotateAllButton8->setStyleSheet(rotateAllButtonClickedStyle);
        displayrotateAllTable(8);
        rotateCoacheClickedStatue = true;
    }
}

void Widget::displayRotateAllCoache8Sheet(int index)
{
    Q_UNUSED(index);
    /************1λ̤��*************/
    QString zwtm11 = rotateAlxeTable->item(0,8)->text();
    rotateAll8CoacheTable->setItem(0,1,new QTableWidgetItem(zwtm11));
    QString zwtm21 = rotateAlxeTable->item(1,8)->text();
    rotateAll8CoacheTable->setItem(0,2,new QTableWidgetItem(zwtm21));
    QString zwtm31 = rotateAlxeTable->item(2,8)->text();
    rotateAll8CoacheTable->setItem(0,3,new QTableWidgetItem(zwtm31));
    QString zwtm41 = rotateAlxeTable->item(3,8)->text();
    rotateAll8CoacheTable->setItem(0,4,new QTableWidgetItem(zwtm41));
    /************1λ̤��*************/
    /**
     **/
    /************2λ̤��*************/
    QString zwtm12 = rotateAlxeTable->item(4,8)->text();
    rotateAll8CoacheTable->setItem(1,1,new QTableWidgetItem(zwtm12));
    QString zwtm22 = rotateAlxeTable->item(5,8)->text();
    rotateAll8CoacheTable->setItem(1,2,new QTableWidgetItem(zwtm22));
    QString zwtm32 = rotateAlxeTable->item(6,8)->text();
    rotateAll8CoacheTable->setItem(1,3,new QTableWidgetItem(zwtm32));
    QString zwtm42 = rotateAlxeTable->item(7,8)->text();
    rotateAll8CoacheTable->setItem(1,4,new QTableWidgetItem(zwtm42));
    /************2λ̤��*************/
    /**
     **/
    /************�����������*************/
    QString dclq1 = rotateGearboxTable->item(0,8)->text();
    rotateAll8CoacheTable->setItem(2,1,new QTableWidgetItem(dclq1));
    QString dclq2 = rotateGearboxTable->item(2,8)->text();
    rotateAll8CoacheTable->setItem(2,2,new QTableWidgetItem(dclq2));
    QString dclq3 = rotateGearboxTable->item(8,8)->text();
    rotateAll8CoacheTable->setItem(2,3,new QTableWidgetItem(dclq3));
    QString dclq4 = rotateGearboxTable->item(10,8)->text();
    rotateAll8CoacheTable->setItem(2,4,new QTableWidgetItem(dclq4));
    /************�����������*************/
    /**
     **/
    /************����ַ�������*************/
    QString dclfq1 = rotateGearboxTable->item(1,8)->text();
    rotateAll8CoacheTable->setItem(3,1,new QTableWidgetItem(dclfq1));
    QString dclfq2 = rotateGearboxTable->item(3,8)->text();
    rotateAll8CoacheTable->setItem(3,2,new QTableWidgetItem(dclfq2));
    QString dclfq3 = rotateGearboxTable->item(9,8)->text();
    rotateAll8CoacheTable->setItem(3,3,new QTableWidgetItem(dclfq3));
    QString dclfq4 = rotateGearboxTable->item(11,8)->text();
    rotateAll8CoacheTable->setItem(3,4,new QTableWidgetItem(dclfq4));
    /************����ַ�������*************/
    /**
     **/
    /************С����������*************/
    QString xclq1 = rotateGearboxTable->item(4,8)->text();
    rotateAll8CoacheTable->setItem(4,1,new QTableWidgetItem(xclq1));
    QString xclq2 = rotateGearboxTable->item(6,8)->text();
    rotateAll8CoacheTable->setItem(4,2,new QTableWidgetItem(xclq2));
    QString xclq3 = rotateGearboxTable->item(12,8)->text();
    rotateAll8CoacheTable->setItem(4,3,new QTableWidgetItem(xclq3));
    QString xclq4 = rotateGearboxTable->item(14,8)->text();
    rotateAll8CoacheTable->setItem(4,4,new QTableWidgetItem(xclq4));
    /************С����������*************/
    /**
     **/
    /************С���ַ�������*************/
    QString xclfq1 = rotateGearboxTable->item(5,8)->text();
    rotateAll8CoacheTable->setItem(5,1,new QTableWidgetItem(xclfq1));
    QString xclfq2 = rotateGearboxTable->item(7,8)->text();
    rotateAll8CoacheTable->setItem(5,2,new QTableWidgetItem(xclfq2));
    QString xclfq3 = rotateGearboxTable->item(13,8)->text();
    rotateAll8CoacheTable->setItem(5,3,new QTableWidgetItem(xclfq3));
    QString xclfq4 = rotateGearboxTable->item(15,8)->text();
    rotateAll8CoacheTable->setItem(5,4,new QTableWidgetItem(xclfq4));
    /************С���ַ�������*************/
    /**
     **/
    /************���������*************/
    QString djq1 = rotateMotorTable->item(0,8)->text();
    rotateAll8CoacheTable->setItem(6,1,new QTableWidgetItem(djq1));
    QString djq2 = rotateMotorTable->item(1,8)->text();
    rotateAll8CoacheTable->setItem(6,2,new QTableWidgetItem(djq2));
    QString djq3 = rotateMotorTable->item(4,8)->text();
    rotateAll8CoacheTable->setItem(6,3,new QTableWidgetItem(djq3));
    QString djq4 = rotateMotorTable->item(5,8)->text();
    rotateAll8CoacheTable->setItem(6,4,new QTableWidgetItem(djq4));
    /************���������*************/
    /**
     **/
    /************�����������*************/
    QString djfq1 = rotateMotorTable->item(2,8)->text();
    rotateAll8CoacheTable->setItem(7,1,new QTableWidgetItem(djfq1));
    QString djfq2 = rotateMotorTable->item(3,8)->text();
    rotateAll8CoacheTable->setItem(7,2,new QTableWidgetItem(djfq2));
    QString djfq3 = rotateMotorTable->item(6,8)->text();
    rotateAll8CoacheTable->setItem(7,3,new QTableWidgetItem(djfq3));
    QString djfq4 = rotateMotorTable->item(7,8)->text();
    rotateAll8CoacheTable->setItem(7,4,new QTableWidgetItem(djfq4));
    /************�����������*************/
    /**
     **/
    /************1λ���*************/
    QString zwzc11 = rotateAlxeTable->item(8,8)->text();
    rotateAll8CoacheTable->setItem(8,1,new QTableWidgetItem(zwzc11));
    QString zwzc21 = rotateAlxeTable->item(9,8)->text();
    rotateAll8CoacheTable->setItem(8,2,new QTableWidgetItem(zwzc21));
    QString zwzc31 = rotateAlxeTable->item(10,8)->text();
    rotateAll8CoacheTable->setItem(8,3,new QTableWidgetItem(zwzc31));
    QString zwzc41 = rotateAlxeTable->item(11,8)->text();
    rotateAll8CoacheTable->setItem(8,4,new QTableWidgetItem(zwzc41));
    /************1λ���*************/
    /**
     **/
    /************2λ���*************/
    QString zwzc12 = rotateAlxeTable->item(12,8)->text();
    rotateAll8CoacheTable->setItem(9,1,new QTableWidgetItem(zwzc12));
    QString zwzc22 = rotateAlxeTable->item(13,8)->text();
    rotateAll8CoacheTable->setItem(9,2,new QTableWidgetItem(zwzc22));
    QString zwzc32 = rotateAlxeTable->item(14,8)->text();
    rotateAll8CoacheTable->setItem(9,3,new QTableWidgetItem(zwzc32));
    QString zwzc42 = rotateAlxeTable->item(15,8)->text();
    rotateAll8CoacheTable->setItem(9,4,new QTableWidgetItem(zwzc42));
    /************2λ���*************/
    //������ɫ
    for(int i=0;i<rotateAll8CoacheTable->rowCount();i++)
    {
        for(int j=0;j<rotateAll8CoacheTable->columnCount();j++)
        {
            if(rotateAll8CoacheTable->item(i,j)->text()== "����")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(0,255,0));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "̤��1��")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,255,0));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "̤��2��")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,125,0));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "���1��")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,85,127));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "���2��")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,255));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "�񶯹���")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,0,0));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "�ȴ�����")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(255,242,204));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "����������")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(217,217,217));
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
            else if(rotateAll8CoacheTable->item(i,j)->text()== "-")
            {
                rotateAll8CoacheTable->item(i,j)->setBackgroundColor(QColor(0,0,0));
                rotateAll8CoacheTable->item(i,j)->setTextAlignment(Qt::AlignCenter);
                rotateAll8CoacheTable->item(i,j)->setFlags(Qt::NoItemFlags);
            }
        }
    }
}

//mainNavigationPushButton Clicked
void Widget::mainNavigationMainInterfaceButtonClicked()
{
    navigationButtonRelease();
    mainNavigationMainInterfaceButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->show();
    stackedWidget->setCurrentIndex(0);
    stackedWidgetNavigation->setCurrentIndex(0);
}
void Widget::mainNavigationRotateButtonClicked()
{
    navigationButtonRelease();
    mainNavigationRotateButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidgetNavigation->setCurrentIndex(1);
    rotateNavigationAllCoacheButtonClicked();
}
void Widget::mainNavigationFireworksButtonClicked()
{
    navigationButtonRelease();
    mainNavigationFireworksButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidgetNavigation->setCurrentIndex(2);
    stackedWidget->setCurrentIndex(3);
    stackedWidget->show();
}
void Widget::mainNavigationBalanceButtonClicked()
{
    navigationButtonRelease();
    mainNavigationBalanceButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(4);
    stackedWidget->show();
}
void Widget::mainNavigationFireLinkageButtonClicked()
{
    navigationButtonRelease();
    mainNavigationFireLinkageButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(5);
    stackedWidget->show();
}
void Widget::mainNavigationTemperatureButtonClicked()
{
    navigationButtonRelease();
    mainNavigationTemperatureButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidgetNavigation->setCurrentIndex(3);
    temperatureNavigationAlxeboxButtonClicked();
}
void Widget::mainNavigationAlarmRecordButtonClicked()
{
    navigationButtonRelease();
    mainNavigationAlarmRecordButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(7);
    stackedWidget->show();
}
void Widget::mainNavigationSystemSetButtonClicked()
{
    navigationButtonRelease();
    mainNavigationSystemSetButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(8);
    stackedWidget->show();
}
//rotateNavigationPushButton Clicked
void Widget::rotateNavigationAllCoacheButtonClicked()
{
    navigationButtonRelease();
    rotateNavigationAllCoacheButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->show();
    stackedWidget->setCurrentIndex(1);
}
void Widget::rotateNavigationAlxeboxButtonClicked()
{
    navigationButtonRelease();
    rotateNavigationAlxeboxButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->show();
    stackedWidget->setCurrentIndex(2);
    releaseRotateSingleTable();
    rotateAlxeTable->show();
}
void Widget::displayAlxeboxSheet(int index)
{
    for(int i=0;i<4;i++)
    {
/***************************����ǰ�ô�����ǰ�ĸ�������***************************/
        QString str0 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].shockStatue.b_isFault);
        QString str1 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].shockStatue.b_TMAlarm1);
        QString str2 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].shockStatue.b_TMAlarm2);
        QString str3 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].shockStatue.b_ZCAlarm1);
        QString str4 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i].shockStatue.b_ZCAlarm2);

        QString str00 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].shockStatue.b_isFault);
        QString str11 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].shockStatue.b_TMAlarm1);
        QString str22 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].shockStatue.b_TMAlarm2);
        QString str33 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].shockStatue.b_ZCAlarm1);
        QString str44 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i].shockStatue.b_ZCAlarm2);

        /************�����������[0-3]��*************/
        if(str0=="1")
        {
            rotateAlxeTable->setItem(i,index+1,new QTableWidgetItem("�񶯹���"));
            rotateAlxeTable->item(i,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str2 =="1"))
        {
            rotateAlxeTable->setItem(i,index+1,new QTableWidgetItem("̤��2��"));
            rotateAlxeTable->item(i,index+1)->setBackgroundColor(QColor(255,125,0));
            rotateAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str2 =="0") && (str1 =="1"))
        {
            rotateAlxeTable->setItem(i,index+1,new QTableWidgetItem("̤��1��"));
            rotateAlxeTable->item(i,index+1)->setBackgroundColor(QColor(255,255,0));
            rotateAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str2 =="0") && (str1 =="0"))
        {
            rotateAlxeTable->setItem(i,index+1,new QTableWidgetItem("����"));
            rotateAlxeTable->item(i,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateAlxeTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����������[0-3]��*************/
        /**
         **
         **/
        /************�����������[4-7]��*************/
        if(str00=="1")
        {
            rotateAlxeTable->setItem(i+4,index+1,new QTableWidgetItem("�񶯹���"));
            rotateAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str22 =="1"))
        {
            rotateAlxeTable->setItem(i+4,index+1,new QTableWidgetItem("̤��2��"));
            rotateAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(255,125,0));
            rotateAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str22 =="0") && (str11 =="1"))
        {
            rotateAlxeTable->setItem(i+4,index+1,new QTableWidgetItem("̤��1��"));
            rotateAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(255,255,0));
            rotateAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00 =="0") && (str22 =="0") && (str11 =="0"))
        {
            rotateAlxeTable->setItem(i+4,index+1,new QTableWidgetItem("����"));
            rotateAlxeTable->item(i+4,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateAlxeTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����������[4-7]��*************/
        /**
         **/
        /************�����������[8-11]��*************/
        if(str0=="1")
        {
            rotateAlxeTable->setItem(i+8,index+1,new QTableWidgetItem("�񶯹���"));
            rotateAlxeTable->item(i+8,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateAlxeTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str4 =="1"))
        {
            rotateAlxeTable->setItem(i+8,index+1,new QTableWidgetItem("���2��"));
            rotateAlxeTable->item(i+8,index+1)->setBackgroundColor(QColor(255,0,255));
            rotateAlxeTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str4 =="0") && (str3 =="1"))
        {
            rotateAlxeTable->setItem(i+8,index+1,new QTableWidgetItem("���1��"));
            rotateAlxeTable->item(i+8,index+1)->setBackgroundColor(QColor(255,85,127));
            rotateAlxeTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0") && (str4 =="0") && (str3 =="0"))
        {
            rotateAlxeTable->setItem(i+8,index+1,new QTableWidgetItem("����"));
            rotateAlxeTable->item(i+8,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateAlxeTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����������[8-11]��*************/
        /**
         **/
        /************�����������[12-15]��*************/
        if(str00=="1")
        {
            rotateAlxeTable->setItem(i+12,index+1,new QTableWidgetItem("�񶯹���"));
            rotateAlxeTable->item(i+12,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateAlxeTable->item(i+12,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str44 =="1"))
        {
            rotateAlxeTable->setItem(i+12,index+1,new QTableWidgetItem("���2��"));
            rotateAlxeTable->item(i+12,index+1)->setBackgroundColor(QColor(255,0,255));
            rotateAlxeTable->item(i+12,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str44 =="0") && (str33 =="1"))
        {
            rotateAlxeTable->setItem(i+12,index+1,new QTableWidgetItem("���1��"));
            rotateAlxeTable->item(i+12,index+1)->setBackgroundColor(QColor(255,85,127));
            rotateAlxeTable->item(i+12,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0") && (str44 =="0") && (str33 =="0"))
        {
            rotateAlxeTable->setItem(i+12,index+1,new QTableWidgetItem("����"));
            rotateAlxeTable->item(i+12,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateAlxeTable->item(i+12,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************�����������[12-15]��*************/
/***************************����ǰ�ô�����ǰ�ĸ�������***************************/
    }
}
void Widget::rotateNavigationGearboxButtonClicked()
{
    navigationButtonRelease();
    rotateNavigationGearboxButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->show();
    stackedWidget->setCurrentIndex(2);
    releaseRotateSingleTable();
    rotateGearboxTable->show();
}
void Widget::displayGearboxSheet(int index)
{
    if((index == 0)||(index == 2)||(index == 5)||(index == 7)){
        return;
    }
    int i=0;
    for(i=0;i<8;i++)
    {
        QString str0 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+4].shockStatue.b_isFault);
        QString str1 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+4].shockStatue.b_ZCAlarm1);
        QString str2 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+4].shockStatue.b_ZCAlarm2);

        QString str00 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+4].shockStatue.b_isFault);
        QString str11 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+4].shockStatue.b_ZCAlarm1);
        QString str22 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+4].shockStatue.b_ZCAlarm2);
        /************���³����������[0-7]��*************/
        if(str0 == "1")
        {
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("�񶯹���"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0")&&(str2 == "1"))
        {
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("���2��"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(255,0,255));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0")&&(str2=="0")&&(str1 == "1"))
        {
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("���1��"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(255,85,127));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0")&&(str2=="0")&&(str1 == "0"))
        {
            rotateGearboxTable->setItem(i,index+1,new QTableWidgetItem("����"));
            rotateGearboxTable->item(i,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateGearboxTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************���³����������[0-7]��*************/
        /**
         **/
        /************���³��������[7-15]��*************/
        if(str00 == "1")
        {
            rotateGearboxTable->setItem(i+8,index+1,new QTableWidgetItem("�񶯹���"));
            rotateGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0")&&(str22 == "1"))
        {
            rotateGearboxTable->setItem(i+8,index+1,new QTableWidgetItem("���2��"));
            rotateGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(255,0,255));
            rotateGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0")&&(str22=="0")&&(str11 == "1"))
        {
            rotateGearboxTable->setItem(i+8,index+1,new QTableWidgetItem("���1��"));
            rotateGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(255,85,127));
            rotateGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0")&&(str22=="0")&&(str11 == "0"))
        {
            rotateGearboxTable->setItem(i+8,index+1,new QTableWidgetItem("����"));
            rotateGearboxTable->item(i+8,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateGearboxTable->item(i+8,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************���³��������[7-15]��*************/
    }
}
void Widget::rotateNavigationMotorButtonClicked()
{
    navigationButtonRelease();
    rotateNavigationMotorButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->show();
    stackedWidget->setCurrentIndex(2);
    releaseRotateSingleTable();
    rotateMotorTable->show();
}
void Widget::displayMotorSheet(int index)
{
    if((index == 0)||(index == 2)||(index == 5)||(index == 7)){
        return;
    }
    int i=0;
    for(i=0;i<4;i++)
    {
        QString str0 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+12].shockStatue.b_isFault);
        QString str1 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+12].shockStatue.b_ZCAlarm1);
        QString str2 =QString::number(udpSocket->coacheList[index].processor[0].preProcessorSensor[i+12].shockStatue.b_ZCAlarm2);
        QString str00 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+12].shockStatue.b_isFault);
        QString str11 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+12].shockStatue.b_ZCAlarm1);
        QString str22 =QString::number(udpSocket->coacheList[index].processor[1].preProcessorSensor[i+12].shockStatue.b_ZCAlarm2);
        /************���µ������[0-3]��*************/
        if(str0=="1")
        {
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("�񶯹���"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0")&&(str2 == "1"))
        {
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("���2��"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(255,0,255));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0")&&(str2=="0")&&(str1 == "1"))
        {
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("���1��"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(255,85,127));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str0=="0")&&(str2=="0")&&(str1 == "0"))
        {
            rotateMotorTable->setItem(i,index+1,new QTableWidgetItem("����"));
            rotateMotorTable->item(i,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateMotorTable->item(i,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************���µ������[0-3]��*************/
        /**
         **/
        /************���µ������[4-7]��*************/
        if(str00=="1")
        {
            rotateMotorTable->setItem(i+4,index+1,new QTableWidgetItem("�񶯹���"));
            rotateMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(255,0,0));
            rotateMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0")&&(str22== "1"))
        {
            rotateMotorTable->setItem(i+4,index+1,new QTableWidgetItem("���2��"));
            rotateMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(255,0,255));
            rotateMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0")&&(str22=="0")&&(str11 == "1"))
        {
            rotateMotorTable->setItem(i+4,index+1,new QTableWidgetItem("���1��"));
            rotateMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(255,85,127));
            rotateMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        else if((str00=="0")&&(str22=="0")&&(str11 == "0"))
        {
            rotateMotorTable->setItem(i+4,index+1,new QTableWidgetItem("����"));
            rotateMotorTable->item(i+4,index+1)->setBackgroundColor(QColor(0,255,0));
            rotateMotorTable->item(i+4,index+1)->setFlags(Qt::NoItemFlags);
        }
        /************���µ������[4-7]��*************/
    }
}
void Widget::rotateNavigationReturnButtonClicked()
{
    navigationButtonRelease();
    rotateNavigationReturnButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidgetNavigation->setCurrentIndex(0);
    mainNavigationMainInterfaceButtonClicked();
}
//temperatureNavigation PushButton
void Widget::temperatureNavigationAlxeboxButtonClicked()
{
    navigationButtonRelease();
    temperatureNavigationAlxeboxButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(6);
    stackedWidget->show();
    releaseTemperatureTable();
    temperatureAlxeTable->show();
}
void Widget::temperatureNavigationGearboxButtonClicked()
{
    navigationButtonRelease();
    temperatureNavigationGearboxButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(6);
    stackedWidget->show();
    releaseTemperatureTable();
    temperatureGearboxTable->show();
}
void Widget::temperatureNavigationMotorButtonClicked()
{
    navigationButtonRelease();
    temperatureNavigationMotorButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(6);
    stackedWidget->show();
    releaseTemperatureTable();
    temperatureMotorTable->show();
}
void Widget::temperatureNavigationMotorAndDiningCoacheButtonClicked()
{
    navigationButtonRelease();
    temperatureNavigationMotorAndDiningCoacheButton->setStyleSheet(navigationButtonClickedStyle);
    stackedWidget->setCurrentIndex(6);
    stackedWidget->show();
    releaseTemperatureTable();
    temperatureMotorAndDiningTable->show();
}
