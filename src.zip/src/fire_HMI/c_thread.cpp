#include "c_thread.h"
#include "widget.h"




C_THREAD::C_THREAD()
{
    OwnerType = C_THREAD::RefreshSocket;
    iswait = false;
    this->Owner = NULL;
    WaitTime = 1000;
    ThreadCheck = 0;
}

C_THREAD::~C_THREAD()
{

}
//
void C_THREAD::delaymsec(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    QTime NowTime = QTime::currentTime();
    while( QTime::currentTime() < dieTime )
    {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        if( QTime::currentTime()<NowTime)
            break;
    }
}
//
void C_THREAD::Sleep(int stime)
{
    QThread::msleep(stime);
}
//
bool C_THREAD::Wait(int stime)
{
    bool res =false;

    iswait = true;
    res = wait.wait(&mutex,stime);
    iswait = false;

    return res;
}
//
void C_THREAD::Set()
{
    wait.wakeAll();
    iswait = false;
}
//
bool C_THREAD::IsWaiting()
{
    return iswait;
}
//
void C_THREAD::run()
{
    Widget *Hy =(Widget*)this->Owner;
    stop = false;
    QThread::msleep(3000);//�߳̿�ʼ��ʱ3���������ȴ����߳��ȶ�
    while(true)
    {
        if (stop)
        {
            emit    cThreadWriteLog("C_THREAD Thread End ! ");
#if Debug
            qDebug("C_THREAD Thread End !");
#endif
            break;
        }
        if (this->Owner == NULL)
        {
            break;
        }
        if (this->OwnerType == C_THREAD::RefreshSocket)
        {
            Hy->refreshTimeout();
        }
        else if(this->OwnerType == C_THREAD::MonitorSocket)
        {
            Hy->udpSocket->monitorTimeout();
        }
        //QThread::msleep(WaitTime);
        delaymsec(WaitTime);
        ThreadCheck++;
        if(ThreadCheck >= 20)//20 -> 2
        {
#if Debug
            qDebug("C_THREAD Thread is Work");
#endif
            ThreadCheck = 0;
        }
    }
}
