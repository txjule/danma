#ifndef C_SQLITE_H
#define C_SQLITE_H

#include <QObject>
#include <QWidget>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMutex>
#include <QDateTime>
#include "udpsocket.h"
#include <QDir>
#include <QCoreApplication>




#define FaultQuery                  11 //���ϲ�ѯ
#define FaultHistory                71 //������ʷ




struct M_SQLLinkData
{
    int ErrorType;  //�� ���ϱ�������
    int SensorType; //��������
    int deviceType; //�豸��
    int CarNo; //����
    QString StarTime; //��ʼʱ��
    QString EndTime; //����ʱ��
    QString Message; //��Ϣ
    bool Reset; //�Ƿ�λ
};
struct R_SQLData
{
    QString ErrorType; //�𾯱������� �ַ���
    QString deviceType; //�豸��
    QString SensorType; //��������ַ �ַ���
    int CarNo; //����
    QString StarTime; //��ʼʱ��
    QString EndTime; //����ʱ��
    QString Message; //��Ϣ
    bool Reset; //�Ƿ�λ
    int i_SersorNo; //�豸��
    int i_ErrorNo; //������
};





class C_Sqlite : public QObject
{
    Q_OBJECT
public:
    explicit C_Sqlite(QObject *parent = nullptr);
    bool            SQL_isOpen;
    QSqlDatabase    db;

    bool            OpenSQL();
    bool            PRAGMA_OFF();
    void            CloseSQL();
    void            TestSQL();
    bool            insert_Error(M_SQLLinkData SqlData);
    QMutex          sqliteMutex;
    bool            DoHaveBJ_Again(int CarNo,int DeviceNo,int SersorNo,int Error);
    bool            Auto_Reset_Data(int CarNun,int DeviceNum,int SersorNum,int ErrorNum);
    bool            Reset_GZAll();
    bool            Clean_Check();
    void            GetSQLData(int Type);
    R_SQLData       updateHistoryTable(int CarNun, int DeviceNum, int SersorNum, int ErrorNum , QString endTime);
    R_SQLData       updateFaultTable(int CarNun, int DeviceNum, int SersorNum, int ErrorNum , QString startTime);

    QList<M_SQLLinkData>    m_Data;
    QList<R_SQLData>        R_Data;

    QString         GetErrorString(int iError);
    QString         GetDeviceString(int iDevice);
    QString         GetSersorString(int Type,int SersorNo,int CarNo);



signals:
    //updateFaultHistory
    void            updateFaultHistory(int CarNun, int DeviceNum, int SersorNum, int ErrorNum , QString endTime);

    //updateFault
    void            updateFault(int CarNun, int DeviceNum, int SersorNum, int ErrorNum , QString startTime);

    //write log
    void            cSqliteWriteLog(QString strLog);

public slots:
};

#endif // C_SQLITE_H
