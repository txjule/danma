#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPainter>
#include <QPen>
#include <QBrush>
#include <QTimer>
#include <QThread>
#include <QString>
#include <QCloseEvent>
#include <QDateTime>
#include <QNetworkInterface>
#include <QSqlTableModel>
#include <QScrollBar>
#include <QMessageBox>
#include <QLabel>
#include <QDebug>
#include <QFont>
#include <QPalette>
#include <QDir>
#include <QFile>
#include <QDomDocument>
#include <QStackedWidget>
#include <QWidget>
#include <QTableWidget>
#include <QPushButton>
#include "udpsocket.h"
#include <QFontDatabase>
#include <QGroupBox>
#include <QSettings>
#include <QTimeEdit>
#include <QDateEdit>
#include "c_sqlite.h"
#include "c_thread.h"
#include <QMutex>





#define                 HOSTIP                      "10.0.1.16"













namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    //time
    void        refreshTimeout();

    //ˢ�½���
    C_THREAD    RefreshThread;
    //��������
    C_THREAD    MonitorErrorThread;
    //UdpSocket
    UdpSocket   *udpSocket;
    //mainUI mutex
    QMutex          mainUIMutex;

private:
    Ui::Widget *ui;

    //init parameter
    void                                initParameter();

    //init Udpsocket
    void        initSecurityUdpsocket();
    void        initConnectUdpsocket();

    //init sqlLink
    C_Sqlite    *sqlLink;
    void        initSqlLink();

    //init ui
    void initMainWindows();
    void initDiaplayLabel();
    void initStackedWidget();
    void initWidget();
    void initWidgetNacigation();

    //paint line
    void paintEvent(QPaintEvent *);

    //log file
    void    setFilePath();
    QString pathLogFile;

    //config file
    QString pathConfig;
    QString pathSysConfig;
    void    readSystemConfig(QString fileName);

    //lable
    QFont       ft;
    QPalette    pa;
    QLabel      *labelDateYear;
    QLabel      *labelDateMonthDay;
    QLabel      *labelHoursMiniter;
    QLabel      *labelSecond;
//    QLabel      *labelTemperature;
//    QLabel      *labelTemperatureUnit;
    QLabel      *labelCarName;
//    QLabel      *labelCarNumber;
//    QLabel      *labelSpeed;
//    QLabel      *labelSpeedUnit;
    QPushButton *warnButton;

    //StackedWidget
    QStackedWidget *stackedWidget;
    QStackedWidget *stackedWidgetNavigation;

    //mainPage
    QWidget         *mainPage;
    QLabel          *labelCurrentAlarm;
    QTableWidget    *mainTable;
    QStringList     mainTableHeader;
    QString         mainPageButtonStyle;
    QPushButton     *mainPageUpPageButton;
    QPushButton     *mainPageDownPageButton;
    QLabel          *mainPageSumItem;
    QLabel          *mainPageSumPage;
    QLabel          *mainPageCurrentPage;
    QString         getSumPage();
    int             currentPageCount;

    //alarmRecordPage
    QWidget         *alarmRecordPage;
    QLabel          *alarmRecordPageHeader;
    QTableWidget    *alarmRecordTable;
    QStringList     alarmRecordTableHeader;
    QString         alarmRecordPageButtonStyle;
    QPushButton     *alarmRecordUpPageButton;
    QPushButton     *alarmRecordDownPageButton;
    QLabel          *recordPageSumItem;
    QLabel          *recordPageSumPage;
    QLabel          *recordPageCurrentPage;
    QString         getRecordSumPage();
    int             recordCurrentPageCount;

    //rotateAllPage
    QWidget         *rotateAllPage;
    QLabel          *coacheSelectHeader;
    QTableWidget    *rotateAll1CoacheTable;
    QTableWidget    *rotateAll2CoacheTable;
    QTableWidget    *rotateAll3CoacheTable;
    QTableWidget    *rotateAll4CoacheTable;
    QTableWidget    *rotateAll5CoacheTable;
    QTableWidget    *rotateAll6CoacheTable;
    QTableWidget    *rotateAll7CoacheTable;
    QTableWidget    *rotateAll8CoacheTable;
    QStringList     rotateAllTableHeader;
    QStringList     rotateAllTableColunm;
    QPushButton     *rotateAllButton1;
    QPushButton     *rotateAllButton2;
    QPushButton     *rotateAllButton3;
    QPushButton     *rotateAllButton4;
    QPushButton     *rotateAllButton5;
    QPushButton     *rotateAllButton6;
    QPushButton     *rotateAllButton7;
    QPushButton     *rotateAllButton8;
    int             currentRotateCoache;
    void            displayrotateAllTable(int coacheNumber);
    QString         rotateAllButtonStyle ;
    QString         rotateAllButtonClickedStyle;
    void            rotateAllButtonUnclickedRelease();
    bool            rotateCoacheClickedStatue;
    void            rotateAllTableRelease();

    //ratateSinglePage
    QWidget         *rotateSinglePage;
    QTableWidget    *rotateAlxeTable;
    QTableWidget    *rotateGearboxTable;
    QTableWidget    *rotateMotorTable;
    QStringList     rotateSignleTableHeader;
    QStringList     rotateAlxeboxTableColunm;
    QStringList     rotateGearboxTableColunm;
    QStringList     rotateMotorTableColunm;
    void            releaseRotateSingleTable();

    //fireWorkPage
    QWidget         *fireWorkPage;
    QLabel          *fireWorkHeader;
    QTableWidget    *fireWorkCoache1Table;
    QTableWidget    *fireWorkCoache2Table;
    QTableWidget    *fireWorkCoache3Table;
    QTableWidget    *fireWorkCoache4Table;
    QTableWidget    *fireWorkCoache5Table;
    QTableWidget    *fireWorkCoache6Table;
    QTableWidget    *fireWorkCoache7Table;
    QTableWidget    *fireWorkCoache8Table;
    QStringList     fireWorkTableHeader;
    QStringList     fireWorkCoache1;
    QStringList     fireWorkCoache2;
    QStringList     fireWorkCoache3;
    QStringList     fireWorkCoache4;
    QStringList     fireWorkCoache5;
    QStringList     fireWorkCoache6;
    QStringList     fireWorkCoache7;
    QStringList     fireWorkCoache8;
    void            releaseFireWorkTable();

    //balanceInstabilityPage
    QWidget         *balanceInstabilityPage;
    QLabel          *balanceInstabilityHeader;
    QTableWidget    *balanceInstabilityTable;
    QStringList     balanceInstabilityTableHeader;
    QStringList     balanceInstabilityColumn;

    //fireLinkagePage
    QWidget         *fireLinkagePage;
    QLabel          *fireLinkageHeader;
    QTableWidget    *fireLinkageTable;
    QStringList     fireLinkageTableHeader;
    QStringList     fireLinkageColumn;

    //temperaturePage
    QWidget         *temperaturePage;
    QTableWidget    *temperatureAlxeTable;
    QTableWidget    *temperatureGearboxTable;
    QTableWidget    *temperatureMotorTable;
    QTableWidget    *temperatureMotorAndDiningTable;
    QStringList     temperatureAlxeboxTableHeader;
    QStringList     temperatureGearboxTableHeader;
    QStringList     temperatureMotorTableHeader;
    QStringList     temperatureMotorAndDiningTableHeader;
    QStringList     temperatureAlxeboxTableColunm;
    QStringList     temperatureGearboxTableColunm;
    QStringList     temperatureMotorTableColunm;
    QStringList     temperatureMotorAndDiningTableColunm;
    void            releaseTemperatureTable();

    //sysSettingPage
    QWidget         *sysSettingPage;
    QLabel          *sysSettingHeader;
    QGroupBox       *lightSetting;
    QString         sysSettingStyle;
    QPushButton     *addLightButon;
    QPushButton     *reduceLightButon;
    QLabel          *lightValueLable;
    int             brightValue;
    QGroupBox       *timingSetting;
    QTimeEdit       *timingEdit;
    QDateEdit       *datingEdit;
    QPushButton     *readSystimeButon;
    QPushButton     *settingSystimeButon;

    //main Navigation Page
    QWidget         *mainNavigationPage;
    QPushButton     *mainNavigationMainInterfaceButton;
    QPushButton     *mainNavigationRotateButton;
    QPushButton     *mainNavigationFireworksButton;
    QPushButton     *mainNavigationBalanceButton;
    QPushButton     *mainNavigationFireLinkageButton;
    QPushButton     *mainNavigationTemperatureButton;
    QPushButton     *mainNavigationAlarmRecordButton;
    QPushButton     *mainNavigationSystemSetButton;

    //rotate Navigation Page
    QWidget         *rotateNavigationPage;
    QPushButton     *rotateNavigationAllCoacheButton;
    QPushButton     *rotateNavigationAlxeboxButton;
    QPushButton     *rotateNavigationGearboxButton;
    QPushButton     *rotateNavigationMotorButton;
    QPushButton     *rotateNavigationReturnButton;

    //firework Navigation Page
    QWidget         *fireworkNavigationPage;
    QLabel          *fireWorkCoacheSelectQLabel;
    QPushButton     *fireWorkButton1;
    QPushButton     *fireWorkButton2;
    QPushButton     *fireWorkButton3;
    QPushButton     *fireWorkButton4;
    QPushButton     *fireWorkButton5;
    QPushButton     *fireWorkButton6;
    QPushButton     *fireWorkButton7;
    QPushButton     *fireWorkButton8;
    int             currentFireWorkCoache;
    bool            fireWorkCoacheClickedStatue;
    void            fireWorkButtonUnclickedRelease();
    QLabel          *fireWorkCurrentCoache;
    QLabel          *fireWorkCurrentCoacheNum;
    QPushButton     *fireWorkReturn;

    //temperature Navigation Page
    QWidget         *temperatureNavigationPage;
    QPushButton     *temperatureNavigationAlxeboxButton;
    QPushButton     *temperatureNavigationGearboxButton;
    QPushButton     *temperatureNavigationMotorButton;
    QPushButton     *temperatureNavigationMotorAndDiningCoacheButton;
    QPushButton     *temperatureNavigationReturnButton;

    //navigation PushButtion StyleSheet
    QString         navigationButtonStyle;
    QString         navigationButtonClickedStyle;
    void            navigationButtonRelease();

    //time
    QDateTime   curTime;
    QString     dateYear;
    QString     dateMonthDay;
    QString     timeHoursMinite;
    QString     timeSecond;
    void        doTime1();
    QTimer      *time1;
    QThread     *time1Thread;

    //temperature
    QString temperature;
    QString temperatureUnit;

    //car
    QString carName;
    QString carNumber;
    QString carSpeed;
    QString carSpeedUnit;

    //QMutex
    QMutex  Sql_mutex;
    bool    bHavedata;//�Ƿ�������
    int     iCount;

private slots:
    //time
    void time1out();

    //writeLog
    void writeLog(QString str);

    //rotateAllPushButton
    void rotateCoache1PushButtonClicked();
    void displayRotateAllCoache1Sheet(int index);
    void rotateCoache2PushButtonClicked();
    void displayRotateAllCoache2Sheet(int index);
    void rotateCoache3PushButtonClicked();
    void displayRotateAllCoache3Sheet(int index);
    void rotateCoache4PushButtonClicked();
    void displayRotateAllCoache4Sheet(int index);
    void rotateCoache5PushButtonClicked();
    void displayRotateAllCoache5Sheet(int index);
    void rotateCoache6PushButtonClicked();
    void displayRotateAllCoache6Sheet(int index);
    void rotateCoache7PushButtonClicked();
    void displayRotateAllCoache7Sheet(int index);
    void rotateCoache8PushButtonClicked();
    void displayRotateAllCoache8Sheet(int index);

    //mainNavigation PushButton
    void mainNavigationMainInterfaceButtonClicked();
    void mainNavigationRotateButtonClicked();
    void mainNavigationFireworksButtonClicked();
    void mainNavigationBalanceButtonClicked();
    void mainNavigationFireLinkageButtonClicked();
    void mainNavigationTemperatureButtonClicked();
    void mainNavigationAlarmRecordButtonClicked();
    void mainNavigationSystemSetButtonClicked();

    //rotateNavigation PushButton
    void rotateNavigationAllCoacheButtonClicked();
    void rotateNavigationAlxeboxButtonClicked();
    void displayAlxeboxSheet(int index);
    void rotateNavigationGearboxButtonClicked();
    void displayGearboxSheet(int index);
    void rotateNavigationMotorButtonClicked();
    void displayMotorSheet(int index);
    void rotateNavigationReturnButtonClicked();

    //temperatureNavigation PushButton
    void temperatureNavigationAlxeboxButtonClicked();
    void temperatureNavigationGearboxButtonClicked();
    void temperatureNavigationMotorButtonClicked();
    void temperatureNavigationMotorAndDiningCoacheButtonClicked();
    void temperatureNavigationReturnButtonClicked();
    void displayTemperatureAlxeTable(int index);
    void displayTemperatureGearTable(int index);
    void displayTemperatureMotorTable(int index);
    void displayTemperatureMotorAndDiningTable(int index);

    //mainpage display
    void mainPageDisplayFaultAndAlarm(int Type);

    //fireworkPushButton
    void fireWorkCoache1PushButtonClicked();
    void fireWorkCoache2PushButtonClicked();
    void fireWorkCoache3PushButtonClicked();
    void fireWorkCoache4PushButtonClicked();
    void fireWorkCoache5PushButtonClicked();
    void fireWorkCoache6PushButtonClicked();
    void fireWorkCoache7PushButtonClicked();
    void fireWorkCoache8PushButtonClicked();
    void fireWorkReturnPushButtonClicked();
    void fireWorkCoache1TableReceiveData(int index);
    void fireWorkCoache2TableReceiveData(int index);
    void fireWorkCoache3TableReceiveData(int index);
    void fireWorkCoache4TableReceiveData(int index);
    void fireWorkCoache5TableReceiveData(int index);
    void fireWorkCoache6TableReceiveData(int index);
    void fireWorkCoache7TableReceiveData(int index);
    void fireWorkCoache8TableReceiveData(int index);

    //displayBalanceSheet
    void displayBalanceSheet(int index);

    //displayFireLinkageSheet
    void displayFireLinkageSheet(int index);

    //cleanCoacheNumData
    void cleanCoacheNumDataSlot(int index);

    //sysSettingPage
    void addLightButtonClicked();
    void reduceLightButtonClicked();
    void systemTimingSlot(int year,int month,int day,int hour,int minute,int second);
    void readSystimeButtonClicked();
    void settingSystimeButtonClicked();

    //mainPage
    void mainPageUpPageButtonClicked();
    void mainPagedownPageButtonClicked();

    //mainPage
    void alarmRecordPageUpPageButtonClicked();
    void alarmRecordPagedownPageButtonClicked();

    //insetSqlData
    void        insetSqlData(int iError,int Sersor,int device,int NumCar,QString Time,QString Message);
    //resetTrueMessage
    void        resetTrueMessage(int iError,int Sersor,int device,int NumCar);
    //updateFaultHistorySlot
    void        updateFaultHistorySlot(int CarNun, int DeviceNum, int SersorNum, int ErrorNum , QString endTime);
    //updateFaultSlot
    void        updateFaultSlot(int CarNun, int DeviceNum, int SersorNum, int ErrorNum , QString startTime);

signals:
    //initOffLineTimerSignal
    void        initOffLineSignal();
};

#endif // WIDGET_H
