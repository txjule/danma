#include "c_sqlite.h"
#define _T(s) (QString::fromUtf8(s))
#define Debug 1





C_Sqlite::C_Sqlite(QObject *parent) : QObject(parent)
{
    SQL_isOpen = false;
}
//�����ݿ�
bool C_Sqlite::OpenSQL()
{
    QDir dir(QCoreApplication::applicationDirPath());
    db = QSqlDatabase::addDatabase("QSQLITE","A");
    db.setDatabaseName(dir.path()+"/400DataBase");
    SQL_isOpen = db.open();
    if(!db.isOpen())
    {
#if Debug
        qDebug("db open error");
#endif
        emit    cSqliteWriteLog("400DataBase Open Error!");
    }
    PRAGMA_OFF();
#if Debug
        qDebug("db open succeed");
#endif
        emit    cSqliteWriteLog("400DataBase Open Succeed!");
    return SQL_isOpen;
}
//journal_mode
bool C_Sqlite::PRAGMA_OFF()
{
    //int i;
    bool ok;
    if(!SQL_isOpen)
        return false;
    QSqlQuery query(db);
    ok = query.exec(_T("PRAGMA journal_mode = OFF"));
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
       return false;
    }
    return true;
}
//�ر����ݿ�
void C_Sqlite::CloseSQL()
{
    if(!SQL_isOpen)
        return;
    //db.removeDatabase("qt_sql_default_connection");
    db.close();
    SQL_isOpen = false;
}
//���ݿ��ȡ����
void C_Sqlite::TestSQL()
{
    OpenSQL();
    if(!SQL_isOpen)
        return;
    QSqlQuery query(db);
    query.exec(_T("select ID,coach1 from YHSENSORTYPE"));
    if(!query.isActive())
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
        CloseSQL();
        return;
    }
    while(query.next())
    {
        int id = query.value(0).toInt();
        QString Type = query.value(1).toString();
#if Debug
        qDebug()<<"id = "<<id<<",Type = "<<Type;
#endif
    }
}
//�����豸������Ϣ
bool C_Sqlite::insert_Error(M_SQLLinkData SqlData)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    bool ok = false;
    QString str,str1;
    if(!SQL_isOpen)
        return false;
    QSqlQuery query(db);
    str = _T("insert into SYSTEMALARM(ERRORID,SENSORNUM,DEVICENUM,CARNUM,RESET,STARTTIME,ENDTIME,MESSAGE) Values");
    str1.sprintf("(%d,%d,%d,%d,%d,",SqlData.ErrorType,SqlData.SensorType,SqlData.deviceType,SqlData.CarNo,SqlData.Reset);
    str1 = str1 + "\"" + SqlData.StarTime + "\"" + ",\"" + SqlData.EndTime + "\"" + ",\"" + SqlData.Message + "\""+ ")";
    str = str + str1;
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
        CloseSQL();
    }else{
        emit    updateFault(SqlData.CarNo,SqlData.deviceType,SqlData.SensorType,SqlData.ErrorType,SqlData.StarTime);
    }
    return ok;
}
//
bool C_Sqlite::DoHaveBJ_Again(int CarNo, int DeviceNo, int SersorNo, int Error)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    bool ok = false;
    QString str;
    if(!SQL_isOpen)
        return false;
    QSqlQuery query(db);
    str.sprintf("select * from SYSTEMALARM where RESET = 0 and CARNUM = %d and DEVICENUM = %d and SENSORNUM = %d and ERRORID = %d",CarNo,DeviceNo,SersorNo,Error);
    //str = QString::fromUtf8(str.toAscii().data(),str.size());
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
        CloseSQL();
        return false;
    }
    int i = 0;
    while(query.next())
    {
        i++;
    }
    if(i>0)
        ok = true;
    else
        ok = false;
    return ok;
}
//
bool C_Sqlite::Auto_Reset_Data(int CarNun, int DeviceNum, int SersorNum, int ErrorNum)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    QString endTime;
    bool ok = false;
    QString str,str1;
    QDateTime time = QDateTime::currentDateTime();
    str=time.toString("yyyy-MM-dd hh:mm:ss");
    endTime =str;
    if(!SQL_isOpen)
        return false;
    QSqlQuery query(db);
    str1 = _T("update SYSTEMALARM SET RESET = 1,ENDTIME = ") + "\"" + str + "\"";
    str.sprintf(" where ERRORID = %d and DEVICENUM = %d and CARNUM = %d and SENSORNUM = %d and RESET= 0",ErrorNum,DeviceNum,CarNun,SersorNum);
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    str = str1 + str;
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
       qDebug()<<"Query Error!"<<query.lastError().text();
#endif
       emit     cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
    }else{
        emit    updateFaultHistory(CarNun,DeviceNum,SersorNum,ErrorNum,endTime);
    }
    return ok;
}
//
bool C_Sqlite::Reset_GZAll()
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    bool ok = false;
    if(!SQL_isOpen)
        return false;
    QSqlQuery query(db);
    QString str,str1;
    QDateTime time = QDateTime::currentDateTime();
    str=time.toString("yyyy-MM-dd hh:mm:ss");
    //
    str1 = _T("update SYSTEMALARM SET RESET = 1,ENDTIME = ") + "\"" + str + "\"";
    str.sprintf("where ERRORID != 0 and RESET = 0");
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    str = str1 + str;
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
       qDebug()<<"Query Error!"<<query.lastError().text();
#endif
       emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
    };
    return ok;
}
//
bool C_Sqlite::Clean_Check()
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    int i;
    if(!SQL_isOpen)
        return false;
    QSqlQuery query(db);
    sqliteMutex.lock();
    query.exec(_T("select Count(*) from SYSTEMALARM"));
    sqliteMutex.unlock();
    if(!query.isActive())
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
        CloseSQL();
        return false;
    }
    while(query.next())
    {
        i = query.value(0).toInt();
#if Debug
        qDebug()<<"Lenght = "<<i;
#endif
        emit    cSqliteWriteLog("SYSTEMALARM Have HistoryData : "+QString::number(i,10));
    }
    if(i > 600)
    {
      sqliteMutex.lock();
      query.exec(_T("delete from SYSTEMALARM where ID in(select ID from SYSTEMALARM order by STARTTIME asc limit 0,300)"));
      sqliteMutex.unlock();
    }
    return true;
}
//
void C_Sqlite::GetSQLData(int Type)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    M_SQLLinkData data;
    R_SQLData Rdata;
    m_Data.clear();
    R_Data.clear();
    if(!SQL_isOpen)
        return;
    QSqlQuery query(db);
    sqliteMutex.lock();
    if(Type == FaultQuery)
        query.exec(_T("select ID,ERRORID,SENSORNUM,DEVICENUM,CARNUM,STARTTIME,RESET,MESSAGE,ENDTIME from SYSTEMALARM where ERRORID != 0 and RESET = 0 order by ID asc"));
    else if(Type == FaultHistory)
        //query.exec(_T("select ID,ERRORID,SENSORNUM,DEVICENUM,CARNUM,STARTTIME,RESET,MESSAGE,ENDTIME from SYSTEMALARM where ERRORID != 0 and RESET = 1 order by ID asc  limit 0,1000"));        
        query.exec(_T("select ID,ERRORID,SENSORNUM,DEVICENUM,CARNUM,STARTTIME,RESET,MESSAGE,ENDTIME from SYSTEMALARM where ERRORID != 0 and RESET = 1 order by ID asc"));
    sqliteMutex.unlock();
    if(!query.isActive())
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
        CloseSQL();
        return;
    }
    while(query.next())
    {
        data.ErrorType = query.value(1).toInt();
        data.SensorType = query.value(2).toInt();
        data.deviceType = query.value(3).toInt();
        data.CarNo = query.value(4).toInt();
        data.StarTime = query.value(5).toString();
        data.Reset = query.value(6).toBool();
        data.Message = query.value(7).toString();
        data.EndTime = query.value(8).toString();
        m_Data.append(data);
    }
    for(int i = 0; i < m_Data.count(); i++)
    {
        Rdata.CarNo         = m_Data.at(i).CarNo;
        Rdata.Message       = m_Data.at(i).Message;
        Rdata.StarTime      = m_Data.at(i).StarTime;
        Rdata.EndTime       = m_Data.at(i).EndTime;
        Rdata.ErrorType     = GetErrorString(m_Data.at(i).ErrorType);
        Rdata.i_ErrorNo     = m_Data.at(i).ErrorType;
        Rdata.deviceType    = GetDeviceString(m_Data.at(i).deviceType);
        Rdata.SensorType    = GetSersorString(m_Data.at(i).deviceType,m_Data.at(i).SensorType,m_Data.at(i).CarNo);
        Rdata.i_SersorNo    = m_Data.at(i).SensorType; //miao add 20160321
        Rdata.Reset         = m_Data.at(i).Reset;
        R_Data.append(Rdata);
    }
}
//update History Table
R_SQLData C_Sqlite::updateHistoryTable(int CarNun, int DeviceNum, int SersorNum, int ErrorNum, QString endTime)
{
    bool ok = false;
    M_SQLLinkData data;
    R_SQLData Rdata;
    QString str ="";
    QString str1 ="";
    if(!SQL_isOpen)
        return Rdata;
    QSqlQuery query(db);
    str.sprintf("select ID,ERRORID,SENSORNUM,DEVICENUM,CARNUM,STARTTIME,RESET,MESSAGE,ENDTIME from SYSTEMALARM where CARNUM = %d and DEVICENUM = %d and SENSORNUM = %d and ERRORID = %d ",CarNun,DeviceNum,SersorNum,ErrorNum);
    str1    =   QString("and ENDTIME = ")+"\"" + endTime + "\"";
    str = str + str1;
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
       return Rdata;
    }
    while(query.next())
    {
        data.ErrorType = query.value(1).toInt();
        data.SensorType = query.value(2).toInt();
        data.deviceType = query.value(3).toInt();
        data.CarNo = query.value(4).toInt();
        data.StarTime = query.value(5).toString();
        data.Reset = query.value(6).toBool();
        data.Message = query.value(7).toString();
        data.EndTime = query.value(8).toString();

        Rdata.CarNo         = data.CarNo;
        Rdata.Message       = data.Message;
        Rdata.StarTime      = data.StarTime;
        Rdata.EndTime       = data.EndTime;
        Rdata.ErrorType     = GetErrorString(data.ErrorType);
        Rdata.i_ErrorNo     = data.ErrorType;
        Rdata.deviceType    = GetDeviceString(data.deviceType);
        Rdata.SensorType    = GetSersorString(data.deviceType,data.SensorType,data.CarNo);
        Rdata.i_SersorNo    = data.SensorType; //miao add 20160321
        Rdata.Reset         = data.Reset;
    }
    return Rdata;
}
//update Fault Table
R_SQLData C_Sqlite::updateFaultTable(int CarNun, int DeviceNum, int SersorNum, int ErrorNum, QString startTime)
{
    bool ok = false;
    M_SQLLinkData data;
    R_SQLData Rdata;
    QString str ="";
    QString str1 ="";
    if(!SQL_isOpen)
        return Rdata;
    QSqlQuery query(db);
    str.sprintf("select ID,ERRORID,SENSORNUM,DEVICENUM,CARNUM,STARTTIME,RESET,MESSAGE,ENDTIME from SYSTEMALARM where CARNUM = %d and DEVICENUM = %d and SENSORNUM = %d and ERRORID = %d ",CarNun,DeviceNum,SersorNum,ErrorNum);
    str1    =   QString("and STARTTIME = ")+"\"" + startTime + "\"";
    str = str + str1;
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
       return Rdata;
    }
    while(query.next())
    {
        data.ErrorType = query.value(1).toInt();
        data.SensorType = query.value(2).toInt();
        data.deviceType = query.value(3).toInt();
        data.CarNo = query.value(4).toInt();
        data.StarTime = query.value(5).toString();
        data.Reset = query.value(6).toBool();
        data.Message = query.value(7).toString();
        data.EndTime = query.value(8).toString();

        Rdata.CarNo         = data.CarNo;
        Rdata.Message       = data.Message;
        Rdata.StarTime      = data.StarTime;
        Rdata.EndTime       = data.EndTime;
        Rdata.ErrorType     = GetErrorString(data.ErrorType);
        Rdata.i_ErrorNo     = data.ErrorType;
        Rdata.deviceType    = GetDeviceString(data.deviceType);
        Rdata.SensorType    = GetSersorString(data.deviceType,data.SensorType,data.CarNo);
        Rdata.i_SersorNo    = data.SensorType; //miao add 20160321
        Rdata.Reset         = data.Reset;
    }
    return Rdata;
}
//
QString C_Sqlite::GetErrorString(int iError)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    bool ok = false;
    QString str;
    if(!SQL_isOpen)
        return "";
    QSqlQuery query(db);
    str.sprintf("select ID,TYPE from ALARMTYPE where ID = %d",iError);
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
       return "";
    }
    str = "";
    while(query.next())
    {
        str = query.value(1).toString();
    }
    return str;
}
//
QString C_Sqlite::GetDeviceString(int iDevice)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    bool ok = false;
    QString str;
    if(!SQL_isOpen)
        return "";
    QSqlQuery query(db);
    str.sprintf("select ID,TYPE from DEVICETYPE where ID = %d",iDevice);
    str = QString::fromUtf8(str.toLatin1().data(),str.size());
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
        qDebug()<<"Query Error!"<<query.lastError().text();
#endif
        emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
       return "";
    }
    str = "";
    while(query.next())
    {
        str = query.value(1).toString();
    }
    return str;
}
//
QString C_Sqlite::GetSersorString(int Type,int SersorNo, int CarNo)
{
    //QMutexLocker locker(&sqliteMutex);//miao 20180504
    bool ok = false;
    QString str;
    if(!SQL_isOpen)
        return "";
    QSqlQuery query(db);
    if(Type == DEVICE_YHZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from YHSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_QZCLQ1){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from QZ1SENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_QZCLQ2){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from QZ2SENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_SWZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from SWSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_PWZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from PWSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_XFZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from XFXSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_YJZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from YJSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_DJDZZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from DJDZSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_DJLQZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from DJLQSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_CFZJ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from CFSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }else if(Type == DEVICE_KZQ){
        str.sprintf("select ID,coach1,coach2,coach3,coach4,coach5,coach6,coach7,coach8 from KZQSENSORTYPE where ID = %d",SersorNo);
        str = QString::fromUtf8(str.toLatin1().data(),str.size());
    }
    sqliteMutex.lock();
    ok = query.exec(str);
    sqliteMutex.unlock();
    if(!ok)
    {
#if Debug
       qDebug()<<"Query Error!"<<query.lastError().text();
#endif
       emit    cSqliteWriteLog("400DataBase Query Error!"+query.lastError().text());
       CloseSQL();
       return "";
    }
    str = "";
    while(query.next())
    {
        str = query.value(CarNo).toString();
    }
    return str;
}
