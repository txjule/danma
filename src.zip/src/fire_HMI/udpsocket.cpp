#include "udpsocket.h"

UdpSocket::UdpSocket(QObject *parent) :
    QObject(parent)
{
    udpsocket       =   new QUdpSocket(this);
    initOffLineTimer     =   new QTimer(this);
    doHeartBeatTimer();
    coacheList.clear();
    connect(initOffLineTimer, SIGNAL(timeout()), this, SLOT(initOffLineTimerSlot()));
}

UdpSocket::~UdpSocket()
{

}
//mappingCoachIP
QString UdpSocket::mappingCoachIP(QString originalIP)
{
    QString newIP = "";
    if(originalIP == "10.0.1.214"){
        newIP = "10.128.129.214";
    }else if(originalIP == "10.0.2.214"){
        newIP = "10.128.130.214";
    }else if(originalIP == "10.0.3.214"){
        newIP = "10.128.131.214";
    }else if(originalIP == "10.0.4.214"){
        newIP = "10.128.132.214";
    }else {
        return originalIP;
    }
    return newIP;
}
//init coacheInformation
void UdpSocket::initCoacheInformation(int offLineTime)
{
    QString originalIP ="";
    coacheList.clear();
    for(int i = 0;i<TRAINNUM;i++) //ѭ����COACHE�ṹ�帳ֵ
    {
        COACHE                                                  coache;                                                         //����һ���ṹ��
        coache.Number                               =           i + 1;                                                          //����
        originalIP                                  =           "10.0." + QString::number(coache.Number,10)+".214";
        coache.IP                                   =           mappingCoachIP(originalIP);             //����ÿһ������ip
        coache.Port                                 =           6666;                                                           //���ö˿ں�
        coache.receiveLastTime                      =           QDateTime::fromString(QString(INITIAL_TIME), "yyyyMMddHHmmss"); //��ǰʱ���ȥ5000sQDateTime::currentDateTime().addMSecs(-5000);
        coache.offlineTime                          =           offLineTime;                                                    //������ֵ
        coache.isOnline                             =           false;                                                          //�Ƿ�����
        coache.ADDIOVersion                         =           "";                                                             //����IO�汾
        coache.PTVersion                            =           "";                                                             //����PT�汾
        coache.sensorfhld.xiaoFangXiangFHLDSS       =           "";
        coache.sensorfhld.mieHuoYaoJiFHLDSS         =           "";
        coache.sensorfhld.pressureWatcher           =           0;
        coache.kzqFault                             =           false;
        for(int j=0;j<2;j++)
        {
            for(int k =0;k<16;k++)
            {
                coache.processor[j].preProcessorSensor[k].shockStatue.b_isFault                         =           false;
                coache.processor[j].preProcessorSensor[k].shockStatue.b_TMAlarm1                        =           false;
                coache.processor[j].preProcessorSensor[k].shockStatue.b_TMAlarm2                        =           false;
                coache.processor[j].preProcessorSensor[k].shockStatue.b_ZCAlarm1                        =           false;
                coache.processor[j].preProcessorSensor[k].shockStatue.b_ZCAlarm2                        =           false;

                coache.processor[j].preProcessorSensor[k].temperatureStatue.i_temperature               =           0;
                coache.processor[j].preProcessorSensor[k].temperatureStatue.b_DLFault                   =           false;
                coache.processor[j].preProcessorSensor[k].temperatureStatue.b_KLFault                   =           false;
            }
            coache.sensorsp[j].b_faultPWDL          =       false;
            coache.sensorsp[j].b_faultPWKL          =       false;
            coache.sensorsp[j].b_faultSWDL          =       false;
            coache.sensorsp[j].b_faultSWKL          =       false;
        }
        for(int m=0;m<4;m++)//��Ȼÿ��������,����ֻ��2,4,6,8������
        {
            coache.sensordongcar[m].dongCarDZSS         =       "";
            coache.sensordongcar[m].dongCarLQSS         =       "";
            coache.sensordongcar[m].i_dongCarDZWD       =       0;
            coache.sensordongcar[m].i_dongCarLQWD       =       0;
        }
        for(int l=0;l<3;l++)//��Ȼÿ����������,��ֻ��5������
        {
            coache.sensorcancarwd[l].canCarWDSS         =       "";
            coache.sensorcancarwd[l].i_canCarWD         =       0;
        }
        for(int n=0;n<16;n++)
        {
            coache.sensoryh[n].yanHuoTCQSS              =       "";
            coache.sensoryh[n].yanHuoLHDSS              =       "";
            coache.sensoryh[n].i_yanWuNongDu            =       0;
            coache.sensoryh[n].i_LHD                    =       0;
            coache.sensoryh[n].i_SDWD                   =       0;
            coache.sensoryh[n].YHVersion                =       "";                 //̽�����汾
        }
        coacheList.append(coache);//���ӵ�coacheList
    }
}
//initUdpsocket
void UdpSocket::initUdpsocket(QString hostip)
{
    //��������IP���˿ڣ������������������ͬһ����ַ����ʹ�˿ں͵�ַ�Ѿ����ҲӦ�ó������°
    udpsocket = new QUdpSocket;
    bool ret = udpsocket->bind(QHostAddress(hostip), 6666, QUdpSocket::ShareAddress|QUdpSocket::ReuseAddressHint);
    if(ret==true)
    {
        emit udpWriteLog("UDPSOCKET Bind IP=10.0.1.16;PORT=6666 Succeed !");
        udpsocket->setSocketOption(QAbstractSocket::MulticastTtlOption,64);
        connect(this,SIGNAL(reciveData(int,QByteArray)),this,SLOT(udpsocketAnalysis(int,QByteArray)));
        connect(udpsocket, SIGNAL(readyRead()), this, SLOT(udpSocketReadData()));
    }
    else
    {
        emit udpWriteLog("UDPSOCKET Bind Fault!Please Check Your IP!");
    }
}
//sendHeartBeatData
void UdpSocket::sendHeartBeatData()
{
    QString LogInfo;
    LogInfo.sprintf("%p", QThread::currentThread());
    emit udpWriteLog("heartBeatTimerThread --- "+LogInfo);
#ifdef udpDebug
    qDebug()<<"heartBeatTimerThread : "+LogInfo;
#endif

    U8 smsg[36] = {0};
    smsg[0] = 0x5A;                         //Byte[0]	֡ͷ 	�̶�Ϊ0x5a
    smsg[1] = 0xA5;                         //Byte[1]	֡ͷ 	�̶�Ϊ0xa5
    smsg[2] = 0x2A;                         //Byte[2]	�豸����ע��������豸����0x2a	0x2a
    smsg[3] = 0x20;                         //Byte[3]	������ע��ʵʱ�������̶�Ϊ0x20	0x20
    smsg[34] = 0xAA;                        //Byte[34]	֡β	�̶�Ϊ0xaa
    smsg[35] = 0xAB;                        //Byte[35]	֡β	�̶�Ϊ0xab

    for(int i = 0;i<TRAINNUM;i++)           //��ѵ���������ᷢ������
    {
        smsg[4] = i + 1;                    //Byte[4]	���󳵺�ע��1~8�����ֱ�Ϊ1~8	0x00

        smsg[33] = 0;

        for(int j = 0;j<33;j++)
        {
            smsg[33] = smsg[33] ^ smsg[j];     //Byte[33]	byte0~byte32�����У��ֵ	FCS
        }
        //�������ݸ�ÿһ������
        udpsocket->writeDatagram((const char *)smsg, 36, QHostAddress(coacheList[i].IP), coacheList[i].Port);
    }

    //�жϸ������������
    for(int k =0;k<TRAINNUM;k++)
    {
        bool nowIsOnline = false;
        if((coacheList[k].receiveLastTime).addMSecs(coacheList[k].offlineTime) > QDateTime::currentDateTime())
        {
            nowIsOnline = true;
        }
        else
        {
            nowIsOnline = false;
        }
        if(nowIsOnline != coacheList[k].isOnline)
        {
            coacheList[k].isOnline = nowIsOnline;
            QString onoff = coacheList[k].isOnline?" ON":" OFF";
            emit udpWriteLog("Online Changed : Coach "+QString::number(k+1,10)+onoff);
            coacheList[k].kzqFault = !nowIsOnline;
            if(nowIsOnline == true){
                emit TrueMessage(Fault_KZQGZ,1,DEVICE_KZQ,k+1);
            }else {
                QDateTime   time        =   QDateTime::currentDateTime();
                QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
                //�������������
                emit ErrorMessage(Fault_KZQGZ,1,DEVICE_KZQ,k+1,strtime,"");
                //�����������(����)
                emit cleanCoacheNumData(k);
            }
        }
    }
}
//initOffLineSlot
void UdpSocket::initOffLineTimerSlot()
{
    emit udpWriteLog("10s Is Not Reveice Data , Init OffLineDevice !");
#ifdef udpDebug
    qDebug()<<"10s Is Not Reveice Data , Init OffLineDevice !";
#endif
    for(int k =0;k<TRAINNUM;k++){
        if(coacheList[k].isOnline == false)
        {
            QDateTime   time        =   QDateTime::currentDateTime();
            QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
            //�������������
            emit ErrorMessage(Fault_KZQGZ,1,DEVICE_KZQ,k+1,strtime,"");
            //�����������(����)
            emit cleanCoacheNumData(k);
        }
    }
}
//reveiceInitOffLineSignal
void UdpSocket::reveiceInitOffLineSignal()
{
    emit udpWriteLog("initOffLineTime Start SingleShot! ");
#ifdef udpDebug
    qDebug()<<"initOffLineTime Start SingleShot! ";
#endif
    initOffLineTimer->setSingleShot(true);
    initOffLineTimer->start(10000);
}
//analysisADDIOData
void UdpSocket::analysisADDIOData(QByteArray byteData, int index)
{
    emit    udpWriteLog("ADDIOD Analysis Ddata Start Analysis!");
    /*------------0x100����IO��״̬�͸�λ����-----------*/
    //�����汾��������
    int i_softWareVerdion_Z = byteData.at(6);
    //�����汾С������
    int i_softWareVerdion_X = byteData.at(7);
    coacheList[index].ADDIOVersion = QString::number(i_softWareVerdion_Z,10) + "." + QString::number(i_softWareVerdion_X,10);
    emit    udpWriteLog("ADDIOD Analysis Ddata Succeed!");
}
//analysisZXBData
void UdpSocket::analysisZXBData(QByteArray byteData, int index)
{
    emit    udpWriteLog("ZXB Analysis Ddata Start Analysis!");
    QDateTime   time    =   QDateTime::currentDateTime();
    QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
    //�жϴ������Ƿ����,�Լ����ϵȼ�
    //ǰ�ô�����1��2��ÿһ������16���������������ж��Ƿ����
    for(int k=0;k<8;k++)
    {
        //ǰ�ô�����1�Ƿ����
        if(coacheList[index].processor[0].preProcessorSensor[k].shockStatue.b_isFault == true && b_readBit(byteData.at(757),k)==false){
            emit TrueMessage(Fault_ZDGZ,k+1,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[8+k].shockStatue.b_isFault == true && b_readBit(byteData.at(758),k)==false){
           emit TrueMessage(Fault_ZDGZ,k+9,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[k].shockStatue.b_isFault          =       b_readBit(byteData.at(757),k);
        coacheList[index].processor[0].preProcessorSensor[8+k].shockStatue.b_isFault        =       b_readBit(byteData.at(758),k);
        //ǰ�ô�����2�Ƿ����
        if(coacheList[index].processor[1].preProcessorSensor[k].shockStatue.b_isFault == true && b_readBit(byteData.at(765),k)==false){
            emit TrueMessage(Fault_ZDGZ,k+1,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[8+k].shockStatue.b_isFault == true && b_readBit(byteData.at(766),k)==false){
            emit TrueMessage(Fault_ZDGZ,k+9,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[k].shockStatue.b_isFault          =       b_readBit(byteData.at(765),k);
        coacheList[index].processor[1].preProcessorSensor[8+k].shockStatue.b_isFault        =       b_readBit(byteData.at(766),k);
        //ǰ�ô�����1�¶ȿ�·����
        if(coacheList[index].processor[0].preProcessorSensor[k].temperatureStatue.b_KLFault  == true && b_readBit(byteData.at(773),k)==false){
            emit TrueMessage(Fault_XZBJKLGZ,k+1,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[8+k].temperatureStatue.b_KLFault == true && b_readBit(byteData.at(774),k)==false){
           emit TrueMessage(Fault_XZBJKLGZ,k+9,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[k].temperatureStatue.b_KLFault    =       b_readBit(byteData.at(773),k);
        coacheList[index].processor[0].preProcessorSensor[k+8].temperatureStatue.b_KLFault  =       b_readBit(byteData.at(774),k);
        //ǰ�ô�����2�¶ȿ�·����
        if(coacheList[index].processor[1].preProcessorSensor[k].temperatureStatue.b_KLFault  == true && b_readBit(byteData.at(777),k)==false){
            emit TrueMessage(Fault_XZBJKLGZ,k+1,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[8+k].temperatureStatue.b_KLFault == true && b_readBit(byteData.at(778),k)==false){
           emit TrueMessage(Fault_XZBJKLGZ,k+9,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[k].temperatureStatue.b_KLFault    =       b_readBit(byteData.at(777),k);
        coacheList[index].processor[1].preProcessorSensor[k+8].temperatureStatue.b_KLFault  =       b_readBit(byteData.at(778),k);
        //ǰ�ô�����1�¶ȶ�·����
        if(coacheList[index].processor[0].preProcessorSensor[k].temperatureStatue.b_DLFault  == true && b_readBit(byteData.at(775),k)==false){
            emit TrueMessage(Fault_XZBJDLGZ,k+1,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[8+k].temperatureStatue.b_DLFault == true && b_readBit(byteData.at(776),k)==false){
           emit TrueMessage(Fault_XZBJDLGZ,k+9,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[k].temperatureStatue.b_DLFault    =       b_readBit(byteData.at(775),k);
        coacheList[index].processor[0].preProcessorSensor[k+8].temperatureStatue.b_DLFault  =       b_readBit(byteData.at(776),k);
        //ǰ�ô�����2�¶ȶ�·����
        if(coacheList[index].processor[1].preProcessorSensor[k].temperatureStatue.b_DLFault  == true && b_readBit(byteData.at(779),k)==false){
            emit TrueMessage(Fault_XZBJDLGZ,k+1,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[8+k].temperatureStatue.b_DLFault == true && b_readBit(byteData.at(780),k)==false){
           emit TrueMessage(Fault_XZBJDLGZ,k+9,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[k].temperatureStatue.b_DLFault    =       b_readBit(byteData.at(779),k);
        coacheList[index].processor[1].preProcessorSensor[k+8].temperatureStatue.b_DLFault  =       b_readBit(byteData.at(780),k);
    }
    //[0-3]������Ϊ�����䴫��������̤�桢�����״̬
    //[4-11]������Ϊ�������䴫������ֻ�������״̬
    //[12-15]������Ϊ�������������ֻ�������״̬
    for(int l=0;l<4;l++)
    {
        /***************************ǰ�ô�����1��[0-3]������̤�桢��о������***************************/
        int m =2*l;
        if(coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_TMAlarm1 == true && b_readBit(byteData.at(759),m) == false){
            emit TrueMessage(Fault_TM1BJ,l+1,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_TMAlarm2 == true && b_readBit(byteData.at(759),m+1) == false){
            emit TrueMessage(Fault_TM2BJ,l+1,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(760),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+1,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(760),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+1,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_TMAlarm1 = b_readBit(byteData.at(759),m);
        coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_TMAlarm2 = b_readBit(byteData.at(759),m+1);
        coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(760),m);
        coacheList[index].processor[0].preProcessorSensor[l].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(760),m+1);
        /***************************ǰ�ô�����1��[0-3]������̤�桢��о������***************************/
        /***************************ǰ�ô�����2��[0-3]������̤�桢��о������***************************/
        if(coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_TMAlarm1 == true && b_readBit(byteData.at(767),m) == false){
            emit TrueMessage(Fault_TM1BJ,l+1,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_TMAlarm2 == true && b_readBit(byteData.at(767),m+1) == false){
            emit TrueMessage(Fault_TM2BJ,l+1,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(768),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+1,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(768),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+1,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_TMAlarm1 = b_readBit(byteData.at(767),m);
        coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_TMAlarm2 = b_readBit(byteData.at(767),m+1);
        coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(768),m);
        coacheList[index].processor[1].preProcessorSensor[l].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(768),m+1);
        /***************************ǰ�ô�����2��[0-3]������̤�桢��о������***************************/
        /***************************ǰ�ô�����1��[4-7]������**********************************/
        if(coacheList[index].processor[0].preProcessorSensor[l+4].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(761),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+5,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[l+4].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(761),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+5,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[l+4].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(761),m);
        coacheList[index].processor[0].preProcessorSensor[l+4].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(761),m+1);
        /***************************ǰ�ô�����1��[4-7]������**********************************/
        /***************************ǰ�ô�����2��[4-7]������**********************************/
        if(coacheList[index].processor[1].preProcessorSensor[l+4].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(769),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+5,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[l+4].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(769),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+5,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[l+4].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(769),m);
        coacheList[index].processor[1].preProcessorSensor[l+4].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(769),m+1);
        /***************************ǰ�ô�����2��[4-7]������**********************************/
        /***************************ǰ�ô�����1��[8-11]������**********************************/
        if(coacheList[index].processor[0].preProcessorSensor[l+8].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(762),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+9,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[l+8].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(762),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+9,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[l+8].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(762),m);
        coacheList[index].processor[0].preProcessorSensor[l+8].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(762),m+1);
        /***************************ǰ�ô�����1��[8-11]������**********************************/
        /***************************ǰ�ô�����2��[8-11]������**********************************/
        if(coacheList[index].processor[1].preProcessorSensor[l+8].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(770),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+9,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[l+8].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(770),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+9,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[l+8].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(770),m);
        coacheList[index].processor[1].preProcessorSensor[l+8].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(770),m+1);
        /***************************ǰ�ô�����2��[8-11]������**********************************/
        /***************************ǰ�ô�����1��[12-15]������**********************************/
        if(coacheList[index].processor[0].preProcessorSensor[l+12].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(763),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+13,DEVICE_QZCLQ1,index+1);
        }
        if(coacheList[index].processor[0].preProcessorSensor[l+12].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(763),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+13,DEVICE_QZCLQ1,index+1);
        }
        coacheList[index].processor[0].preProcessorSensor[l+12].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(763),m);
        coacheList[index].processor[0].preProcessorSensor[l+12].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(763),m+1);
        /***************************ǰ�ô�����1��[12-15]������**********************************/
        /***************************ǰ�ô�����1��[12-15]������**********************************/
        if(coacheList[index].processor[1].preProcessorSensor[l+12].shockStatue.b_ZCAlarm1 == true && b_readBit(byteData.at(771),m) == false){
            emit TrueMessage(Fault_ZC1BJ,l+13,DEVICE_QZCLQ2,index+1);
        }
        if(coacheList[index].processor[1].preProcessorSensor[l+12].shockStatue.b_ZCAlarm2 == true && b_readBit(byteData.at(771),m+1) == false){
            emit TrueMessage(Fault_ZC2BJ,l+13,DEVICE_QZCLQ2,index+1);
        }
        coacheList[index].processor[1].preProcessorSensor[l+12].shockStatue.b_ZCAlarm1 = b_readBit(byteData.at(771),m);
        coacheList[index].processor[1].preProcessorSensor[l+12].shockStatue.b_ZCAlarm2 = b_readBit(byteData.at(771),m+1);
        /***************************ǰ�ô�����1��[12-15]������**********************************/
    }
    //��ȡ����
    for(int m=0;m<7;m++)
    {
        coacheList[index].processor[0].preProcessorSensor[m].temperatureStatue.i_temperature            =       byteData.at(790+m);
        coacheList[index].processor[0].preProcessorSensor[m+7].temperatureStatue.i_temperature          =       byteData.at(798+m);
        coacheList[index].processor[1].preProcessorSensor[m].temperatureStatue.i_temperature            =       byteData.at(814+m);
        coacheList[index].processor[1].preProcessorSensor[m+7].temperatureStatue.i_temperature          =       byteData.at(822+m);
    }
    coacheList[index].processor[0].preProcessorSensor[14].temperatureStatue.i_temperature               =       byteData.at(806);
    coacheList[index].processor[0].preProcessorSensor[15].temperatureStatue.i_temperature               =       byteData.at(807);
    coacheList[index].processor[1].preProcessorSensor[14].temperatureStatue.i_temperature               =       byteData.at(830);
    coacheList[index].processor[1].preProcessorSensor[15].temperatureStatue.i_temperature               =       byteData.at(831);

    //�����汨��
    /*****��ѯ��ת��������*****/
    for(int j = 0; j < 16; j++)
    {
        //DEVICE_QZCLQ1
        if(coacheList[index].processor[0].preProcessorSensor[j].shockStatue.b_isFault)
        {
            emit ErrorMessage(Fault_ZDGZ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }
        if(coacheList[index].processor[0].preProcessorSensor[j].shockStatue.b_TMAlarm1){
            emit ErrorMessage(Fault_TM1BJ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }
        if(coacheList[index].processor[0].preProcessorSensor[j].shockStatue.b_TMAlarm2){
            emit ErrorMessage(Fault_TM2BJ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }
        if(coacheList[index].processor[0].preProcessorSensor[j].shockStatue.b_ZCAlarm1){
            emit ErrorMessage(Fault_ZC1BJ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }
        if(coacheList[index].processor[0].preProcessorSensor[j].shockStatue.b_ZCAlarm2){
            emit ErrorMessage(Fault_ZC2BJ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }
        //DEVICE_QZCLQ1
        if(coacheList[index].processor[0].preProcessorSensor[j].temperatureStatue.b_DLFault)
        {
            emit ErrorMessage(Fault_XZBJDLGZ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }
        if(coacheList[index].processor[0].preProcessorSensor[j].temperatureStatue.b_KLFault){
            emit ErrorMessage(Fault_XZBJKLGZ,j+1,DEVICE_QZCLQ1,index+1,strtime,"");
        }

        //DEVICE_QZCLQ2
        if(coacheList[index].processor[1].preProcessorSensor[j].shockStatue.b_isFault)
        {
            emit ErrorMessage(Fault_ZDGZ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
        if(coacheList[index].processor[1].preProcessorSensor[j].shockStatue.b_TMAlarm1){
            emit ErrorMessage(Fault_TM1BJ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
        if(coacheList[index].processor[1].preProcessorSensor[j].shockStatue.b_TMAlarm2){
            emit ErrorMessage(Fault_TM2BJ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
        if(coacheList[index].processor[1].preProcessorSensor[j].shockStatue.b_ZCAlarm1){
            emit ErrorMessage(Fault_ZC1BJ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
        if(coacheList[index].processor[1].preProcessorSensor[j].shockStatue.b_ZCAlarm2){
            emit ErrorMessage(Fault_ZC2BJ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
        //DEVICE_QZCLQ2
        if(coacheList[index].processor[1].preProcessorSensor[j].temperatureStatue.b_DLFault)
        {
            emit ErrorMessage(Fault_XZBJDLGZ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
        if(coacheList[index].processor[1].preProcessorSensor[j].temperatureStatue.b_KLFault){
            emit ErrorMessage(Fault_XZBJKLGZ,j+1,DEVICE_QZCLQ2,index+1,strtime,"");
        }
    }
    emit    udpWriteLog("ZXB Analysis Ddata Succeed!");
}
//analysisMVBData
void UdpSocket::analysisMVBData(QByteArray byteData, int index)
{
    emit    udpWriteLog("MVB Analysis Ddata Start Analysis!");
    QDateTime   time    =   QDateTime::currentDateTime();
    QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
    //Уʱ
    int     year        =   0;
    int     month       =   0;
    int     day         =   0;
    int     hour        =   0;
    int     minute      =   0;
    int     second      =   0;
    year                =   byteData.at(21);
    month               =   byteData.at(22);
    day                 =   byteData.at(23);
    hour                =   byteData.at(24);
    minute              =   byteData.at(25);
    second              =   byteData.at(26);
    emit    systemTiming(year,month,day,hour,minute,second);

    //��������
    bool fhldUpP = b_readBit(byteData.at(51),0);
    bool fhldDownP = b_readBit(byteData.at(51),1);
    bool nhyj = b_readBit(byteData.at(51),2);
    //ѹ����״̬
    if(coacheList[index].sensorfhld.xiaoFangXiangFHLDSS == "ѹ������" && b_readBit(byteData.at(51),0)==false){
        emit TrueMessage(Fault_XFXYLGZ,1,DEVICE_XFZJ,index+1);

    }
    if(coacheList[index].sensorfhld.xiaoFangXiangFHLDSS == "ѹ��Ƿ��" && b_readBit(byteData.at(51),1)==false){
        emit TrueMessage(Fault_XFXYLQZ,1,DEVICE_XFZJ,index+1);
    }
    if((fhldUpP==0) && (fhldDownP==0))
    {
        coacheList[index].sensorfhld.xiaoFangXiangFHLDSS ="ѹ������";
    }
    else if((fhldUpP==1) && (fhldDownP==0))
    {
        coacheList[index].sensorfhld.xiaoFangXiangFHLDSS ="ѹ������";
    }
    else if((fhldUpP==0) && (fhldDownP==1))
    {
        coacheList[index].sensorfhld.xiaoFangXiangFHLDSS ="ѹ��Ƿ��";
    }
    //ҩ��
    if(coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS == "ҩ��Ƿȱ" && b_readBit(byteData.at(51),2)==false){
        emit TrueMessage(Fault_MHYJQQ,1,DEVICE_YJZJ,index+1);
    }
    if(nhyj==0)
    {
        coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS ="ҩ������";
    }
    else
    {
        coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS ="ҩ��Ƿȱ";
    }

    //XF
    if(coacheList[index].sensorfhld.xiaoFangXiangFHLDSS == "ѹ������")
    {
        emit ErrorMessage(Fault_XFXYLGZ,1,DEVICE_XFZJ,index+1,strtime,"");
    }
    if(coacheList[index].sensorfhld.xiaoFangXiangFHLDSS == "ѹ��Ƿ��")
    {
        emit ErrorMessage(Fault_XFXYLQZ,1,DEVICE_XFZJ,index+1,strtime,"");
    }
    //MHYJ
    if(coacheList[index].sensorfhld.mieHuoYaoJiFHLDSS == "ҩ��Ƿȱ")
    {
        emit ErrorMessage(Fault_MHYJQQ,1,DEVICE_YJZJ,index+1,strtime,"");
    }
    //ѹ��������
    coacheList[index].sensorfhld.pressureWatcher = byteData.at(52);
    emit    sendRecieveCoacheNum(index);
    emit    udpWriteLog("MVB Analysis Data Succeed!");
}
//analysisSPData
void UdpSocket::
analysisSPData(QByteArray byteData, int index)
{
    emit    udpWriteLog("SP Analysis Ddata Start Analysis!");
    QDateTime   time    =   QDateTime::currentDateTime();
    QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
    //��ȡʧ��ƽ����ֵ
    if(coacheList[index].sensorsp[0].b_faultSWKL == true && b_readBit(byteData.at(849),0) == false){
        emit TrueMessage(Fault_SWKLGZ,1,DEVICE_SWZJ,index+1);
    }
    if(coacheList[index].sensorsp[0].b_faultSWDL == true && b_readBit(byteData.at(849),1) == false){
        emit TrueMessage(Fault_SWDLGZ,1,DEVICE_SWZJ,index+1);
    }
    if(coacheList[index].sensorsp[1].b_faultSWKL == true && b_readBit(byteData.at(849),2) == false){
        emit TrueMessage(Fault_SWKLGZ,2,DEVICE_SWZJ,index+1);
    }
    if(coacheList[index].sensorsp[1].b_faultSWDL == true && b_readBit(byteData.at(849),3) == false){
        emit TrueMessage(Fault_SWDLGZ,2,DEVICE_SWZJ,index+1);
    }
    //��ȡʧ��ƽ����ֵ
    if(coacheList[index].sensorsp[0].b_faultPWKL == true && b_readBit(byteData.at(849),4) == false){
        emit TrueMessage(Fault_PWKLGZ,1,DEVICE_SWZJ,index+1);
    }
    if(coacheList[index].sensorsp[0].b_faultPWDL == true && b_readBit(byteData.at(849),5) == false){
        emit TrueMessage(Fault_PWDLGZ,1,DEVICE_SWZJ,index+1);
    }
    if(coacheList[index].sensorsp[1].b_faultPWKL == true && b_readBit(byteData.at(849),6) == false){
        emit TrueMessage(Fault_PWKLGZ,2,DEVICE_SWZJ,index+1);
    }
    if(coacheList[index].sensorsp[1].b_faultPWDL == true && b_readBit(byteData.at(849),7) == false){
        emit TrueMessage(Fault_PWDLGZ,2,DEVICE_SWZJ,index+1);
    }
    coacheList[index].sensorsp[0].b_faultSWKL=b_readBit(byteData.at(849),0);
    coacheList[index].sensorsp[0].b_faultSWDL=b_readBit(byteData.at(849),1);
    coacheList[index].sensorsp[1].b_faultSWKL=b_readBit(byteData.at(849),2);
    coacheList[index].sensorsp[1].b_faultSWDL=b_readBit(byteData.at(849),3);
    coacheList[index].sensorsp[0].b_faultPWKL=b_readBit(byteData.at(849),4);
    coacheList[index].sensorsp[0].b_faultPWDL=b_readBit(byteData.at(849),5);
    coacheList[index].sensorsp[1].b_faultPWKL=b_readBit(byteData.at(849),6);
    coacheList[index].sensorsp[1].b_faultPWDL=b_readBit(byteData.at(849),7);
    /**********************��ȡʧ��ƽ����ֵ********************************/

    //�����汨��
    for(int j = 0; j < 2; j++){
        //SW
        if(coacheList[index].sensorsp[j].b_faultSWDL)
        {
            emit ErrorMessage(Fault_SWDLGZ,j+1,DEVICE_SWZJ,index+1,strtime,"");
        }
        if(coacheList[index].sensorsp[j].b_faultSWKL)
        {
            emit ErrorMessage(Fault_SWKLGZ,j+1,DEVICE_SWZJ,index+1,strtime,"");
        }
        //PW
        if(coacheList[index].sensorsp[j].b_faultPWDL)
        {
            emit ErrorMessage(Fault_PWDLGZ,j+1,DEVICE_PWZJ,index+1,strtime,"");
        }
        if(coacheList[index].sensorsp[j].b_faultPWKL)
        {
            emit ErrorMessage(Fault_PWKLGZ,j+1,DEVICE_PWZJ,index+1,strtime,"");
        }
    }
    emit    udpWriteLog("SP Analysis Data Succeed!");
}
//analysisPTData
void UdpSocket::analysisPTData(QByteArray byteData, int index)
{
    emit    udpWriteLog("PT Analysis Ddata Start Analysis!");
    QDateTime   time    =   QDateTime::currentDateTime();
    QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
    /**********************��ȡ�������ӡ���ȴ����������״̬********************************/
    char state[11] ={0};
    state[0]=byteData.at(901)&0x0c;//�������1
    state[1]=(byteData.at(902)>>4)&0x0c;//�������2
    state[2]=byteData.at(902)&0x0c;//�������3
    state[3]=byteData.at(909)&0x0c;//�������4
    state[4]=(byteData.at(910)>>4)&0x0c;//��ȴ1
    state[5]=byteData.at(910)&0x0c;//��ȴ2
    state[6]=byteData.at(917)&0x0c;//��ȴ3
    state[7]=(byteData.at(918)>>4)&0x0c;//��ȴ4
    state[8]=byteData.at(925)&0x0c;//�ͳ�1
    state[9]=(byteData.at(926)>>4)&0x0c;//�ͳ�2
    state[10]=byteData.at(926)&0x0c;//�ͳ�3

    for(int n=0;n<4;n++)
    {
        if(coacheList[index].sensordongcar[n].dongCarDZSS=="��·" && (state[n] == 0x00)){
            emit TrueMessage(Fault_DJDZDL,n+1,DEVICE_DJDZZJ,index+1);
        }
        if(coacheList[index].sensordongcar[n].dongCarDZSS=="��·" && (state[n] == 0x00)){
            emit TrueMessage(Fault_DJDZKL,n+1,DEVICE_DJDZZJ,index+1);
        }
        //������ӵ�״̬
        if(state[n]==0x00)
        {
            coacheList[index].sensordongcar[n].dongCarDZSS="����";
        }
        else if(state[n]==0x04)
        {
            coacheList[index].sensordongcar[n].dongCarDZSS="��·";
        }
        else if(state[n]==0x08)
        {
            coacheList[index].sensordongcar[n].dongCarDZSS="��·";
        }
        //�����ȴ��״̬
        if(coacheList[index].sensordongcar[n].dongCarLQSS=="��·" && (state[n+4] == 0x00)){
            emit TrueMessage(Fault_DJLQDL,n+1,DEVICE_DJLQZJ,index+1);
        }
        if(coacheList[index].sensordongcar[n].dongCarLQSS=="��·" && (state[n+4] == 0x00)){
            emit TrueMessage(Fault_DJLQKL,n+1,DEVICE_DJLQZJ,index+1);
        }
        if(state[n+4]==0x00)
        {
            coacheList[index].sensordongcar[n].dongCarLQSS="����";
        }
        else if(state[n+4]==0x04)
        {
            coacheList[index].sensordongcar[n].dongCarLQSS="��·";
        }
        else if(state[n+4]==0x08)
        {
            coacheList[index].sensordongcar[n].dongCarLQSS="��·";
        }
    }
    //�ͳ���״̬
    for(int o=0;o<3;o++)
    {
        if(coacheList[index].sensordongcar[o].dongCarLQSS=="��·" && (state[o+8] == 0x00)){
            emit TrueMessage(Fault_CCBYQDL,o+1,DEVICE_CFZJ,index+1);
        }
        if(coacheList[index].sensordongcar[o].dongCarLQSS=="��·" && (state[o+8] == 0x00)){
            emit TrueMessage(Fault_CCBYQKL,o+1,DEVICE_CFZJ,index+1);
        }
        if(state[8+o]==0x00)
        {
            coacheList[index].sensorcancarwd[o].canCarWDSS="����";
        }
        else if(state[8+o]==0x04)
        {
            coacheList[index].sensorcancarwd[o].canCarWDSS="��·";
        }
        else if(state[8+o]==0x08)
        {
            coacheList[index].sensorcancarwd[o].canCarWDSS="��·";
        }
    }
    /**********************�������ӡ���ȴ���ͳ��¶�********************************/
    char wenDu[11]={0};
    wenDu[0]=byteData.at(903)&0x0f;//�������1�¶�
    wenDu[1]=byteData.at(905)&0x0f;//�������2�¶�
    wenDu[2]=byteData.at(907)&0x0f;//�������3�¶�
    wenDu[3]=byteData.at(910)&0x0f;//�������4�¶�
    wenDu[4]=byteData.at(912)&0x0f;//��ȴ1�¶�
    wenDu[5]=byteData.at(914)&0x0f;//��ȴ2�¶�
    wenDu[6]=byteData.at(917)&0x0f;//��ȴ3�¶�
    wenDu[7]=byteData.at(919)&0x0f;//��ȴ4�¶�
    wenDu[8]=byteData.at(927)&0x0f;//������ѹ��1�¶�
    wenDu[9]=byteData.at(929)&0x0f;//������ѹ��2�¶�
    wenDu[10]=byteData.at(931)&0x0f;//������ѹ��3�¶�
    int djdz1 = wenDu[0];
    int djdz2 = wenDu[1];
    int djdz3 = wenDu[2];
    int djdz4 = wenDu[3];
    int lq1 = wenDu[4];
    int lq2 = wenDu[5];
    int lq3 = wenDu[6];
    int lq4 = wenDu[7];
    int cfbyq1 =wenDu[8];
    int cfbyq2 =wenDu[9];
    int cfbyq3 =wenDu[10];
    int djdz11 =byteData.at(904);
    int djdz22 =byteData.at(906);
    int djdz33 =byteData.at(908);
    int djdz44 =byteData.at(911);
    int lq11 =byteData.at(913);
    int lq22 =byteData.at(915);
    int lq33 =byteData.at(918);
    int lq44 =byteData.at(920);
    int cfbyq11 =byteData.at(928);
    int cfbyq22 =byteData.at(930);
    int cfbyq33 =byteData.at(932);
    coacheList[index].sensordongcar[0].i_dongCarDZWD=djdz1*256+djdz11-60;
    coacheList[index].sensordongcar[0].i_dongCarLQWD=lq1*256+lq11-60;
    coacheList[index].sensordongcar[1].i_dongCarDZWD=djdz2*256+djdz22-60;
    coacheList[index].sensordongcar[1].i_dongCarLQWD=lq2*256+lq22-60;
    coacheList[index].sensordongcar[2].i_dongCarDZWD=djdz3*256+djdz33-60;
    coacheList[index].sensordongcar[2].i_dongCarLQWD=lq3*256+lq33-60;
    coacheList[index].sensordongcar[3].i_dongCarDZWD=djdz4*256+djdz44-60;
    coacheList[index].sensordongcar[3].i_dongCarLQWD=lq4*256+lq44-60;
    coacheList[index].sensorcancarwd[0].i_canCarWD=cfbyq1*256+cfbyq11-60;
    coacheList[index].sensorcancarwd[1].i_canCarWD=cfbyq2*256+cfbyq22-60;
    coacheList[index].sensorcancarwd[2].i_canCarWD=cfbyq3*256+cfbyq33-60;
    /**********************��ȡ�������ӡ���ȴ�������¶�********************************/
    /**********************��ȡPT���Ӱ汾״̬********************************/
    char versionpt;
    versionpt = (byteData.at(903)>>4)&0x0f;
    int i_versionpt = versionpt;
    coacheList[index].PTVersion = QString::number(i_versionpt,10);
    /**********************��ȡPT���Ӱ汾״̬********************************/


    //DC
    for(int j = 0; j < 4; j++){
        //DCDZ
        if(coacheList[index].sensordongcar[j].dongCarDZSS == "��·")
        {
            emit ErrorMessage(Fault_DJDZDL,j+1,DEVICE_DJDZZJ,index+1,strtime,"");
        }
        if(coacheList[index].sensordongcar[j].dongCarDZSS == "��·")
        {
            emit ErrorMessage(Fault_DJDZKL,j+1,DEVICE_DJDZZJ,index+1,strtime,"");
        }
        //DCLQ
        if(coacheList[index].sensordongcar[j].dongCarLQSS == "��·")
        {
            emit ErrorMessage(Fault_DJLQDL,j+1,DEVICE_DJLQZJ,index+1,strtime,"");
        }
        if(coacheList[index].sensordongcar[j].dongCarLQSS == "��·")
        {
            emit ErrorMessage(Fault_DJLQKL,j+1,DEVICE_DJLQZJ,index+1,strtime,"");
        }
    }
    //CC
    for(int j = 0; j < 3; j++){
        //DCDZ
        if(coacheList[index].sensorcancarwd[j].canCarWDSS == "��·")
        {
            emit ErrorMessage(Fault_CCBYQDL,j+1,DEVICE_CFZJ,index+1,strtime,"");
        }
        if(coacheList[index].sensorcancarwd[j].canCarWDSS == "��·")
        {
            emit ErrorMessage(Fault_CCBYQKL,j+1,DEVICE_CFZJ,index+1,strtime,"");
        }
    }
    emit    udpWriteLog("PT Aanalysis Data Succeed!");
}
//analysisCANData
void UdpSocket::analysisCANData(QByteArray byteData, int index)
{
    emit    udpWriteLog("CAN Analysis Ddata Start Analysis!");
    QDateTime   time    =   QDateTime::currentDateTime();
    QString     strtime     =   time.toString("yyyy-MM-dd hh:mm:ss");
    for(int p=0;p<16;p++)
    {
        //��ȡ̽����״̬״̬
        bool tcqPB=b_readBit(byteData.at(90+p*8),3);
        bool tcqWR=b_readBit(byteData.at(90+p*8),2);
        bool tcqBJ=b_readBit(byteData.at(90+p*8),1);
        bool tcqGZ=b_readBit(byteData.at(90+p*8),0);

        if(coacheList[index].sensoryh[p].yanHuoTCQSS == "����" && tcqPB==false){
            emit TrueMessage(Fault_TCQPB,p+1,DEVICE_YHZJ,index+1);
        }
        if(coacheList[index].sensoryh[p].yanHuoTCQSS == "��Ⱦ" && tcqWR==false){
            emit TrueMessage(Fault_TCQWR,p+1,DEVICE_YHZJ,index+1);
        }
        if(coacheList[index].sensoryh[p].yanHuoTCQSS == "����" && tcqBJ==false){
            emit TrueMessage(Fault_TCQBJ,p+1,DEVICE_YHZJ,index+1);
        }
        if(coacheList[index].sensoryh[p].yanHuoTCQSS == "����" && tcqGZ==false){
            emit TrueMessage(Fault_TCQGZ,p+1,DEVICE_YHZJ,index+1);
        }
        if(tcqPB==0 && tcqWR==0 && tcqBJ==0 && tcqGZ==0)
        {
            coacheList[index].sensoryh[p].yanHuoTCQSS="����";
        }
        if(tcqPB==1 && tcqWR==0 && tcqBJ==0 && tcqGZ==0)
        {
            coacheList[index].sensoryh[p].yanHuoTCQSS="����";
        }
        if(tcqPB==0 && tcqWR==1 && tcqBJ==0 && tcqGZ==0)
        {
            coacheList[index].sensoryh[p].yanHuoTCQSS="��Ⱦ";
        }
        if(tcqPB==0 && tcqWR==0 && tcqBJ==1 && tcqGZ==0)
        {
            coacheList[index].sensoryh[p].yanHuoTCQSS="����";
        }
        if(tcqPB==0 && tcqWR==0 && tcqBJ==0 && tcqGZ==1)
        {
            coacheList[index].sensoryh[p].yanHuoTCQSS="����";
        }
        //��ȡ����Ũ��
        coacheList[index].sensoryh[p].i_yanWuNongDu=byteData.at(213+p*8);
        //��ȡSD�¶�Ũ��
        coacheList[index].sensoryh[p].i_SDWD=byteData.at(219+p*8);
        //��ȡLHD��ֵ
        int lhdgw = byteData.at(345+p*8);
        int lhddw = byteData.at(346+p*8);
        coacheList[index].sensoryh[p].i_LHD=lhdgw*256+lhddw;
        //��ȡLHD״̬
        bool lhdPB=b_readBit(byteData.at(91+p*8),5);
        bool lhdKL=b_readBit(byteData.at(91+p*8),4);
        bool lhdRVDL=b_readBit(byteData.at(91+p*8),3);
        bool lhdDZCW=b_readBit(byteData.at(91+p*8),2);
        bool lhdYDDL=b_readBit(byteData.at(91+p*8),1);
        bool lhdBJ=b_readBit(byteData.at(91+p*8),0);

        //LHD2coach
        if((index == 1) && (p == 0)){
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdPB==false){
                emit TrueMessage(Fault_LHDPB,9,DEVICE_YHZJ,index+1);
            }
            if((coacheList[index].sensoryh[p].yanHuoLHDSS == "����") && (lhdKL==false) && (lhdRVDL == false)&& (lhdDZCW == false)&& (lhdYDDL== false)){
                emit TrueMessage(Fault_LHDGZ,9,DEVICE_YHZJ,index+1);
            }
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdBJ == false){
                emit TrueMessage(Fault_LHDBJ,9,DEVICE_YHZJ,index+1);
            }
        }
        //LHD4coach
        if((index == 3) && (p == 0)){
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdPB==false){
                emit TrueMessage(Fault_LHDPB,9,DEVICE_YHZJ,index+1);
            }
            if((coacheList[index].sensoryh[p].yanHuoLHDSS == "����") && (lhdKL==false) && (lhdRVDL == false)&& (lhdDZCW == false)&& (lhdYDDL== false)){
                emit TrueMessage(Fault_LHDGZ,9,DEVICE_YHZJ,index+1);
            }
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdBJ == false){
                emit TrueMessage(Fault_LHDBJ,9,DEVICE_YHZJ,index+1);
            }
        }
        //LHD7coach
        if((index == 6) && (p == 0)){
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdPB==false){
                emit TrueMessage(Fault_LHDPB,9,DEVICE_YHZJ,index+1);
            }
            if((coacheList[index].sensoryh[p].yanHuoLHDSS == "����") && (lhdKL==false) && (lhdRVDL == false)&& (lhdDZCW == false)&& (lhdYDDL== false)){
                emit TrueMessage(Fault_LHDGZ,9,DEVICE_YHZJ,index+1);
            }
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdBJ == false){
                emit TrueMessage(Fault_LHDBJ,9,DEVICE_YHZJ,index+1);
            }
        }
        //LHD5coach
        if((index == 4) && (p == 0)){
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdPB==false){
                emit TrueMessage(Fault_LHDPB,8,DEVICE_YHZJ,index+1);
            }
            if((coacheList[index].sensoryh[p].yanHuoLHDSS == "����") && (lhdKL==false) && (lhdRVDL == false)&& (lhdDZCW == false)&& (lhdYDDL== false)){
                emit TrueMessage(Fault_LHDGZ,8,DEVICE_YHZJ,index+1);
            }
            if(coacheList[index].sensoryh[p].yanHuoLHDSS == "����" && lhdBJ == false){
                emit TrueMessage(Fault_LHDBJ,8,DEVICE_YHZJ,index+1);
            }
        }

        if(lhdPB==0 && lhdKL==0 && lhdRVDL==0 && lhdDZCW==0 && lhdYDDL==0 && lhdBJ==0)
        {
            coacheList[index].sensoryh[p].yanHuoLHDSS="����";
        }
        if(lhdPB==1 && lhdKL==0 && lhdRVDL==0 && lhdDZCW==0 && lhdYDDL==0 && lhdBJ==0)
        {
            coacheList[index].sensoryh[p].yanHuoLHDSS="����";
        }
        if(lhdPB==0 && (lhdKL==1 || lhdRVDL==1 || lhdDZCW==1 || lhdYDDL==1) && lhdBJ==0)
        {
            coacheList[index].sensoryh[p].yanHuoLHDSS="����";
        }
        if(lhdPB==0 && lhdKL==0 && lhdRVDL==0 && lhdDZCW==0 && lhdYDDL==0 && lhdBJ==1)
        {
            coacheList[index].sensoryh[p].yanHuoLHDSS="����";
        }
        //��ȡCAN���Ӱ汾״̬
        int yhZS = byteData.at(475+p*8);
        int yhXS = byteData.at(476+p*8);
        coacheList[index].sensoryh[p].YHVersion =QString::number(yhZS)+"."+QString::number(yhXS);
    }

    //�����汨��
    /*****��ѯ�̻����*****/
    for(int j = 0; j < 16; j++)
    {
        if(coacheList[index].sensoryh[j].yanHuoTCQSS == "����")
        {
            emit ErrorMessage(Fault_TCQGZ,j+1,DEVICE_YHZJ,index+1,strtime,"");
        }else if(coacheList[index].sensoryh[j].yanHuoTCQSS == "����"){
            emit ErrorMessage(Fault_TCQPB,j+1,DEVICE_YHZJ,index+1,strtime,"");
        }else if(coacheList[index].sensoryh[j].yanHuoTCQSS == "��Ⱦ"){
            emit ErrorMessage(Fault_TCQWR,j+1,DEVICE_YHZJ,index+1,strtime,"");
        }else if(coacheList[index].sensoryh[j].yanHuoTCQSS == "����"){
            emit ErrorMessage(Fault_TCQBJ,j+1,DEVICE_YHZJ,index+1,strtime,"");
        }
    }

    //LHD 2
    if(coacheList[1].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDGZ,9,DEVICE_YHZJ,2,strtime,"");
    }else if(coacheList[1].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDPB,9,DEVICE_YHZJ,2,strtime,"");
    }else if(coacheList[1].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDBJ,9,DEVICE_YHZJ,2,strtime,"");
    }
    //LHD 4
    if(coacheList[3].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDGZ,9,DEVICE_YHZJ,4,strtime,"");
    }else if(coacheList[3].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDPB,9,DEVICE_YHZJ,4,strtime,"");
    }else if(coacheList[3].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDBJ,9,DEVICE_YHZJ,4,strtime,"");
    }
    //LHD 7
    if(coacheList[6].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDGZ,9,DEVICE_YHZJ,7,strtime,"");
    }else if(coacheList[6].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDPB,9,DEVICE_YHZJ,7,strtime,"");
    }else if(coacheList[6].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDBJ,9,DEVICE_YHZJ,7,strtime,"");
    }
    //LHD 5
    if(coacheList[4].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDGZ,8,DEVICE_YHZJ,5,strtime,"");
    }else if(coacheList[4].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDPB,8,DEVICE_YHZJ,5,strtime,"");
    }else if(coacheList[4].sensoryh[0].yanHuoLHDSS == "����"){
        emit ErrorMessage(Fault_LHDBJ,8,DEVICE_YHZJ,5,strtime,"");
    }

    emit    udpWriteLog("CAN Analysis Data Succeed!");
}
//b_readBit
bool UdpSocket::b_readBit(char ad, int bit)
{
    ad = ad & 0xff;
    if(((ad>>bit)&1) == 1)
        return true;
    else
        return false;
}
//b_readBit_F
bool UdpSocket::b_readBit_F(char ad, int bit)
{
    ad = ad & 0xff;
    if(((ad>>bit)&1) == 1)
        return false;
    else
        return true;
}
//monitor
void UdpSocket::monitorTimeout()
{

}
//do Heart Beat Timer
void UdpSocket::doHeartBeatTimer()
{
    heartBeatTimer = new QTimer;
    heartBeatTimerThread = new QThread;
    heartBeatTimer->start(1000);
    heartBeatTimer->moveToThread(heartBeatTimerThread);
    connect(heartBeatTimer, SIGNAL(timeout()), this, SLOT(sendHeartBeatData()));
}
//udpSocketReadData
void UdpSocket::udpSocketReadData()
{
    QByteArray   recvData;
    QHostAddress sourceHost;
    quint16      sourcePort;
    recvData.resize(udpsocket->pendingDatagramSize());
    udpsocket->readDatagram(recvData.data(),recvData.size(),&sourceHost,&sourcePort);
    QString strIP = sourceHost.toString();
    for(int index=0; index < coacheList.size(); index++)
    {
        //�ж�IP��ַ�Ƿ�Ϊ����IP��ַ
        if(strIP == coacheList[index].IP)
        {
            emit reciveData(index,recvData);
            emit udpWriteLog("ReciveData Current Coach IP : " + strIP);
            qDebug()<<"ReciveData Current Coach IP : " + strIP;
            break;
        }
    }
}
//udpsocketAnalysis
void UdpSocket::udpsocketAnalysis(int index,QByteArray recvData)
{
    QByteArray  byteData;
    byteData.clear();
    int         i           =   0;
    int         j           =   0;
    bool        b_lenghtCk  =   false;
    //ˢ�³������ʱ��
    if(index<coacheList.size())
    {
        coacheList[index].receiveLastTime = QDateTime::currentDateTime();
    }
    if(recvData.isEmpty() == 1)//������������Ϊ������������
    {
        emit udpWriteLog("Coach "+QString::number(index+1,10)+" : The RecvData Is Empty!");
        return;
    }
    //�ж�֡ͷ֡β�Ƿ����
    if(!recvData.contains(0x5A)||!recvData.contains(0xA5)||!recvData.contains(0xAA)||!recvData.contains(0xAB))
    {
        emit udpWriteLog("Coach "+QString::number(index+1,10)+" : The RecvData NO Header Oor Tail!");
        return;
    }
    //�жϽ������ݳ���
    for(i=0;i<recvData.count();i++)
    {
        if((((U8)recvData.at(i) & 0xFF))==0x5A && (recvData.count()>=(i+5)))
        {
            for(j=0;j<recvData.count();j++)
            {
                if(((U8)(recvData.at(j)) & 0xFF) == 0xAB)
                {
                    if(i>j)
                    {
                        continue;
                    }
                    else
                    {
                        if(j-i+1==1000)
                        {
                           b_lenghtCk=true;
                           break;
                        }
                    }
                }
            }
        }
        if(b_lenghtCk==1)
        {
            break;
        }
    }
    if(b_lenghtCk==0)
    {
        emit udpWriteLog("Coach "+QString::number(index+1,10)+" : The RecvData Lenght Is Wrong!");
        return;
    }
    byteData = recvData.mid(i,j-i+1);
    //check 997
//    unsigned char xorResult = 0x00;
//    for(int i=0;i<997;i++)
//    {
//        xorResult ^=byteData.at(i);
//    }
//    if(byteData.at(997) != xorResult)
//    {
//        emit udpWriteLog("Coach "+QString::number(index+1,10)+" : The recvData Check is worng!");
//        return;
//    }

    //�������ݽ���
    if(coacheList[index].isOnline == true)
    {
        coacheList[index].Number = byteData.at(4);
        emit udpWriteLog("Coach "+QString::number(coacheList[index].Number,10) + " Analysis Data Beginning��");
        qDebug()<<"Coach "+QString::number(coacheList[index].Number,10) + " Analysis Data Beginning��";
        //����ADDIO��
        analysisADDIOData(byteData,index);
        //����MVB��
        analysisMVBData(byteData,index);
        //����ZXB��
        analysisZXBData(byteData,index);
        //����SP��
        analysisSPData(byteData,index);
        //����PT��
        analysisPTData(byteData,index);
        //����CAN��
        analysisCANData(byteData,index);
        //���½���
        emit    sendRecieveCoacheNum(index);
    }
}
