#ifndef C_THREAD_H
#define C_THREAD_H

#include <QObject>
#include <QThread>
#include <QWaitCondition>
#include <QMutex>
#include <QTextEdit>
#include <QCoreApplication>
#include <QMetaType>


#define Debug   1


class C_THREAD : public QThread
{
    Q_OBJECT
public:
    C_THREAD();
    ~C_THREAD();


    QObject     *Owner;
    bool        stop;
    enum        {RefreshSocket = 0,MonitorSocket};
    int         OwnerType;//��������
    int         WaitTime;
    void        delaymsec(int msec);


    static      void Sleep(int stime);
    bool        Wait(int stime);
    void        Set();
    bool        IsWaiting();    //�ȴ���
    int         ThreadCheck;


private :
    QWaitCondition  wait;       //�߳�ͬ��
    QMutex          mutex;

    bool            iswait;

protected:
    void            run();             //����

signals:
    void        cThreadWriteLog(QString str);

public slots:
};

#endif // C_THREAD_H
