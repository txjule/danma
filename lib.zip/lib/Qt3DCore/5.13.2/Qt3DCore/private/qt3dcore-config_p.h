#define QT_FEATURE_assimp 1
#define QT_FEATURE_qt3d_profile_gl -1
#define QT_FEATURE_qt3d_profile_jobs -1
#define QT_FEATURE_qt3d_simd_avx2 -1
#define QT_FEATURE_qt3d_simd_sse2 1
#define QT_FEATURE_system_assimp -1
